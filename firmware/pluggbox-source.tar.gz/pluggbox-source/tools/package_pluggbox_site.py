#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Assemble the beginner Pluggbox website; this never publishes or flashes.

The current FM-1 release is deliberately unavailable. Device identification
uses only the read-only checker; no firmware payload or installer is shipped.
"""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import tarfile
import tempfile
import zipfile

from build_pluggbox import input_hashes
from package_pluggbox import source_paths
import package_pluggbox_device as device

ROOT = Path(__file__).resolve().parents[1]
AUDITION = ROOT / 'build/pluggbox'
OUTPUT = ROOT / 'build/pluggbox-site'
ZIP = ROOT / 'build/pluggbox-site.zip'
PLAY_FILES = ('index.html', 'style.css', 'app.js', 'worklet.js', 'pluggbox.wasm', 'build-receipt.json')
INSTALL_FILES = ('index.html', 'style.css', 'app.js')
DEVICE_MODULES = ('plugg-device-policy.js', 'plugg-install-controller.js')
READ_ONLY_MODULES = ('fm1ota.js', 'fm1pkg.js', 'jam-device-policy.js')
ROOT_FILES = ('LICENSE.txt', 'LICENSING.md', 'pluggbox-source.tar.gz')
AUDIO_FILES = ('glass-starter-jam.wav', 'glass-harder-take.wav', 'metrics.json')
RELEASE = {
    'schema_version': 1,
    'family': 'pluggbox',
    'status': 'blocked',
    'install_available': False,
    'source_firmware': 'jamboxfm',
    'reason': 'target-build-pending',
    'message': 'FM-1 installer is being prepared. You can play Pluggbox in your browser now.',
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def copy(source, target):
    if source.is_symlink() or not source.is_file():
        raise ValueError(f'Missing or linked site input: {source}')
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def validate(directory):
    directory = Path(directory)
    release = json.loads((directory / 'firmware/pluggbox-release.json').read_text())
    enabled = release.get('install_available') is True
    if enabled:
        device.read_package(directory / 'firmware')
    elif release != RELEASE:
        raise ValueError('Unknown release state')
    expected = {
        'index.html', '.nojekyll', 'README.txt', 'site-manifest.json', 'SHA256SUMS',
        'firmware/pluggbox-release.json', *ROOT_FILES, *READ_ONLY_MODULES,
        *('play/' + name for name in PLAY_FILES),
        *('install/' + name for name in INSTALL_FILES),
        *('audio/' + name for name in AUDIO_FILES),
    }
    if enabled:
        expected.update(DEVICE_MODULES)
        expected.update('firmware/' + name for name in device.FILES)
    actual = set()
    for path in directory.rglob('*'):
        if path.is_symlink():
            raise ValueError('Linked website output refused')
        if path.is_file():
            actual.add(path.relative_to(directory).as_posix())
    if actual != expected:
        raise ValueError(f'Unexpected site membership: {actual ^ expected}')
    if not enabled and any(name.endswith('.fwsc') or 'jam-trial-install' in name for name in actual):
        raise ValueError('A pending site must contain no firmware/write controller')
    for line in (directory / 'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        if name not in actual or sha(directory / name) != digest:
            raise ValueError(f'Site checksum mismatch: {name}')
    return actual


def assemble(with_device=False):
    candidate = device.read_package() if with_device else None
    modules = READ_ONLY_MODULES + (DEVICE_MODULES if with_device else ())
    receipt = json.loads((AUDITION / 'build-receipt.json').read_text())
    if receipt.get('inputs_sha256') != input_hashes():
        raise ValueError('Browser build is stale; rebuild before assembling the site')
    for name, expected in receipt['outputs_sha256'].items():
        if sha(AUDITION / name) != expected:
            raise ValueError(f'Browser output differs from its receipt: {name}')
    before = input_hashes()
    site_inputs = [*(ROOT / 'web/plugg-install' / name for name in INSTALL_FILES),
                   *(ROOT / 'web' / name for name in modules)]
    site_before = {path: sha(path) for path in site_inputs}
    # The guided page is not a WASM input, so separately verify that the
    # corresponding source archive contains the current page/packager too.
    with tarfile.open(AUDITION / 'pluggbox-source.tar.gz', 'r:gz') as source:
        for path in source_paths():
            name = 'pluggbox-source/' + path.relative_to(ROOT).as_posix()
            member = source.getmember(name)
            if not member.isfile() or source.extractfile(member).read() != path.read_bytes():
                raise ValueError(f'Corresponding source is stale: {name}')
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    if OUTPUT.is_symlink():
        raise ValueError('Refusing linked website output')
    with tempfile.TemporaryDirectory(prefix='.pluggbox-site-', dir=OUTPUT.parent) as folder:
        stage = Path(folder) / 'site'
        stage.mkdir()
        for name in PLAY_FILES:
            copy(AUDITION / name, stage / 'play' / name)
        # In the standalone audition these downloads share its root; on the
        # combined website they live one level above /play/. The site manifest
        # records the transformed HTML separately from the original receipt.
        play_index = stage / 'play/index.html'
        play_index.write_text(play_index.read_text().replace(
            'href="pluggbox-source.tar.gz"', 'href="../pluggbox-source.tar.gz"').replace(
            'href="LICENSE.txt"', 'href="../LICENSE.txt"'))
        for name in INSTALL_FILES:
            copy(ROOT / 'web/plugg-install' / name, stage / 'install' / name)
        for name in modules:
            copy(ROOT / 'web' / name, stage / name)
        for name in ROOT_FILES:
            copy(AUDITION / name, stage / name)
        for name in AUDIO_FILES:
            copy(AUDITION / 'audio' / name, stage / 'audio' / name)
        (stage / 'firmware').mkdir()
        if candidate:
            for name, data in candidate.items():
                target = stage / 'firmware' / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(data)
        else:
            (stage / 'firmware/pluggbox-release.json').write_text(json.dumps(RELEASE, indent=2) + '\n')
        (stage / '.nojekyll').write_text('')
        (stage / 'index.html').write_text(
            '<!doctype html><html lang="en"><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1">'
            '<meta http-equiv="refresh" content="0;url=./install/">'
            '<title>Get Pluggbox</title><p><a href="./install/">Open Pluggbox</a></p></html>\n')
        (stage / 'README.txt').write_text(
            'PLUGGBOX WEBSITE\n\n'
            'Publish this directory to an HTTPS static host. Open the site root\n'
            'for the guided page, /play/ for the browser instrument, or either\n'
            'WAV in /audio/ to listen. The current FM-1 section identifies an\n'
            'instrument only; installation is unavailable pending a verified\n'
            'Pluggbox target build. No device firmware is in this package.\n\n'
            'Local development requires an HTTP server; opening index.html as a\n'
            'file does not provide AudioWorklet or Web MIDI browser support.\n'
            'No command here publishes the site. GPL source and notices are\n'
            'included; SHA256SUMS covers the packaged website.\n')
        if with_device:
            (stage / 'README.txt').write_text('PLUGGBOX EXPERIMENTAL INSTALLER\nServe over HTTPS. Open install/ in desktop Chrome or Edge.\nOnly the supported Jambox normal firmware is eligible. Back up first.\nSoftware checks passed; physical hardware validation is pending.\nPluggbox sessions are temporary. GPL source and licenses are included.\n')
        files = sorted(path for path in stage.rglob('*') if path.is_file())
        manifest = {
            'product': 'Pluggbox', 'target': 'guided-browser-and-read-only-device-page',
            'install_available': with_device, 'firmware_payload_included': with_device,
            'runtime_wasm_sha256': sha(stage / 'play/pluggbox.wasm'),
            'play_html_download_links_adjusted': True,
            'files': {path.relative_to(stage).as_posix(): {
                'sha256': sha(path), 'size_bytes': path.stat().st_size,
            } for path in files},
        }
        (stage / 'site-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
        files = sorted(path for path in stage.rglob('*') if path.is_file())
        (stage / 'SHA256SUMS').write_text(''.join(
            f'{sha(path)}  {path.relative_to(stage).as_posix()}\n' for path in files))
        validate(stage)
        if before != input_hashes():
            raise ValueError('Browser inputs changed while packaging the site; rebuild')
        if site_before != {path: sha(path) for path in site_inputs}:
            raise ValueError('Guided-page inputs changed while packaging; rerun')
        if OUTPUT.exists():
            shutil.rmtree(OUTPUT)
        stage.rename(OUTPUT)
    names = validate(OUTPUT)
    temporary = ZIP.with_suffix('.tmp')
    with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in sorted(names):
            info = zipfile.ZipInfo('pluggbox-site/' + name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, (OUTPUT / name).read_bytes())
    temporary.replace(ZIP)
    print(f'Guided site: {OUTPUT} ({len(names)} files; device trial: {with_device})')
    print(f'Website ZIP: {ZIP} ({ZIP.stat().st_size:,} bytes)')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--no-build', action='store_true', help='Use a current verified browser build')
    parser.add_argument('--with-device', action='store_true', help='Include the verified experimental owner-trial firmware')
    args = parser.parse_args()
    if args.with_device:
        subprocess.run([sys.executable, str(ROOT / 'tools/package_pluggbox_device.py'), '--no-build'], cwd=ROOT, check=True)
    command = [sys.executable, str(ROOT / 'tools/package_pluggbox.py')]
    if args.no_build:
        command.append('--no-build')
    subprocess.run(command, cwd=ROOT, check=True)
    assemble(args.with_device)


if __name__ == '__main__':
    main()
