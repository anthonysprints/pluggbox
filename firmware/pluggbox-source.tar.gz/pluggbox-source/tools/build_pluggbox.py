#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Build Pluggbox's shared-C browser instrument without the FM-1 toolchain.

Source tools/cloud/activate_pluggbox.sh first. Generated headers and website
files stay under ignored build/; no SDK, device or installation is involved.
"""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
GEN = ROOT / "build/pluggbox-gen"
OUT = ROOT / "build/pluggbox"
WEB_FILES = ("index.html", "app.js", "worklet.js", "style.css")
EXPORTS = (
    "preview_frames", "preview_rate", "preview_render", "jam_preview_init",
    "jam_preview_key", "jam_preview_release", "jam_preview_panic",
    "jam_preview_select", "jam_preview_play", "jam_preview_toggle_play",
    "jam_preview_record", "jam_preview_tempo", "jam_preview_swing",
    "jam_preview_octave", "jam_preview_mute", "jam_preview_sound",
    "jam_preview_setting", "jam_preview_drum_step", "jam_preview_value",
    "jam_preview_pad_name", "jam_preview_lane_name", "jam_role_track",
    "jam_role_name", "jam_sound_name", "jam_sound_count", "jam_sound_index",
    "jam_macro_set", "jam_macro_get", "jam_macro_name", "plugg_preview_demo",
    "plugg_preview_demo_active", "plugg_preview_reset",
)


def input_hashes():
    """Bind the browser artifact to sources/assets, without Git or build caches."""
    paths = []
    for directory in ("firmware", "assets", "web/plugg"):
        paths.extend(path for path in (ROOT / directory).rglob("*")
                     if path.is_file() and "__pycache__" not in path.parts)
    # Packaging, audition rendering and publication scripts do not participate
    # in compilation. Keep their edits from forcing unnecessary DSP rebuilds.
    paths.extend(ROOT / "tools" / name for name in (
        "build_pluggbox.py", "gen_tables.py", "gen_samples.py", "gen_waves.py",
        "sampleio.py", "gen_drumkits.py", "drumkit_levels.json",
        "gen_pluggbox_drums.py", "gen_fm6_patches.py", "cloud/packages.json",
    ))
    result = {}
    for path in sorted(set(paths)):
        if path.is_symlink():
            raise ValueError(f"Linked build input refused: {path}")
        result[path.relative_to(ROOT).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result


def main():
    emcc = os.environ.get("EMCC") or shutil.which("emcc")
    if not emcc:
        raise SystemExit("Emscripten is required; source tools/cloud/activate_pluggbox.sh first.")
    adapter = ROOT / "firmware/host/plugg_preview.c"
    inputs = [adapter, *(ROOT / "web/plugg" / name for name in WEB_FILES)]
    for path in inputs:
        if not path.is_file():
            raise SystemExit(f"Missing Pluggbox source: {path.relative_to(ROOT)}")
    GEN.mkdir(parents=True, exist_ok=True)
    OUT.mkdir(parents=True, exist_ok=True)
    before = input_hashes()
    # Match the host's twelve-engine configuration even in a shell previously
    # used for a device build. The optional SLICE demo is intentionally absent.
    build_env = dict(os.environ, FELUCCA_SLICE="0")
    for script, header in (
        ("gen_tables.py", "felucca_tables.h"),
        ("gen_samples.py", "felucca_samples.h"),
        ("gen_drumkits.py", "felucca_drumkits.h"),
        ("gen_pluggbox_drums.py", "pluggbox_drums.h"),
        ("gen_fm6_patches.py", "felucca_fm6.h"),
    ):
        subprocess.run(
            [sys.executable, str(ROOT / "tools" / script), str(GEN / header)],
            cwd=ROOT, env=build_env, check=True,
        )
    subprocess.run(
        [emcc, str(adapter), "-O2", "-fwrapv", "-fno-strict-aliasing",
         "-Wno-unused-function", "-Wno-int-to-pointer-cast", "-I" + str(GEN),
         "-I" + str(ROOT / "firmware/src"), "--no-entry",
         "-sSTANDALONE_WASM=1", "-sFILESYSTEM=0", "-sINITIAL_MEMORY=16777216",
         "-sSTACK_SIZE=131072",
         "-sEXPORTED_FUNCTIONS=" + str(["_" + name for name in EXPORTS]),
         "-o", str(OUT / "pluggbox.wasm")],
        cwd=ROOT, env=build_env, check=True,
    )
    for name in WEB_FILES:
        shutil.copy2(ROOT / "web/plugg" / name, OUT / name)
    if input_hashes() != before:
        raise SystemExit("Build inputs changed during compilation; rebuild before packaging.")
    receipt = {
        "target": "pluggbox-browser",
        "feature_flags": {"FELUCCA_SLICE": 0},
        "inputs_sha256": before,
        "outputs_sha256": {name: hashlib.sha256((OUT / name).read_bytes()).hexdigest()
                           for name in (*WEB_FILES, "pluggbox.wasm")},
    }
    (OUT / "build-receipt.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    print(f"Pluggbox browser instrument built: {OUT}")


if __name__ == "__main__":
    main()
