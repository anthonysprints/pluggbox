#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Package a local Pluggbox audition website with its corresponding source.

This creates build/pluggbox-audition.zip; it never publishes or flashes a
device. Serve the extracted directory over HTTP for AudioWorklet support.
"""
from pathlib import Path
import argparse
import gzip
import hashlib
import io
import json
import os
import shutil
import stat
import subprocess
import sys
import tarfile
import zipfile

from build_pluggbox import input_hashes


ROOT = Path(__file__).resolve().parents[1]
SITE = ROOT / "build/pluggbox"
WEB_FILES = ("index.html", "app.js", "worklet.js", "style.css", "pluggbox.wasm")
AUDIO_FILES = ("glass-starter-jam.wav", "glass-harder-take.wav")
SOURCE_DIRS = ("assets", "docs", "firmware", "LICENSES", "tests", "tools", "web")
SOURCE_ROOT_FILES = ("README.md", "AGENTS.md", "LICENSE", "LICENSING.md", "UPSTREAM.json", "build.sh", ".gitignore")
EXCLUDED_DIRS = {".git", "build", "node_modules", "__pycache__", ".pytest_cache"}
EXCLUDED_FILES = {".DS_Store"}


def source_paths():
    """Use a source allowlist, never the workspace, environment, or Git metadata."""
    for name in SOURCE_ROOT_FILES:
        path = ROOT / name
        if path.exists():
            if path.is_symlink() or not path.is_file():
                raise ValueError(f"Unexpected source root entry: {path}")
            yield path
    for name in SOURCE_DIRS:
        directory = ROOT / name
        if directory.is_symlink() or not directory.is_dir():
            raise ValueError(f"Missing or linked source directory: {directory}")
        for current, dirs, files in os.walk(directory, followlinks=False):
            dirs[:] = sorted(d for d in dirs if d not in EXCLUDED_DIRS)
            for entry in dirs:
                if (Path(current) / entry).is_symlink():
                    raise ValueError(f"Linked source directory refused: {Path(current) / entry}")
            for filename in sorted(files):
                path = Path(current) / filename
                if filename in EXCLUDED_FILES or path.suffix in {".pyc", ".pyo"}:
                    continue
                if path.is_symlink() or not path.is_file():
                    raise ValueError(f"Non-regular source entry refused: {path}")
                yield path


def source_archive():
    target = SITE / "pluggbox-source.tar.gz"
    temporary = target.with_suffix(".tmp")
    with temporary.open("wb") as output:
        with gzip.GzipFile(filename="", mode="wb", fileobj=output, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w|", format=tarfile.PAX_FORMAT) as archive:
                for path in sorted(source_paths()):
                    info = tarfile.TarInfo("pluggbox-source/" + path.relative_to(ROOT).as_posix())
                    data = path.read_bytes()
                    info.size = len(data)
                    info.mode = 0o755 if path.stat().st_mode & stat.S_IXUSR else 0o644
                    info.mtime = info.uid = info.gid = 0
                    archive.addfile(info, io.BytesIO(data))
    temporary.replace(target)
    return target


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--no-build", action="store_true", help="Package the current browser build without recompiling")
    args = parser.parse_args()
    if not args.no_build:
        subprocess.run([sys.executable, str(ROOT / "tools/build_pluggbox.py")], cwd=ROOT, check=True)
    for name in WEB_FILES:
        if not (SITE / name).is_file():
            raise SystemExit(f"Missing browser build file: {name}; run tools/build_pluggbox.py first.")
    receipt_path = SITE / "build-receipt.json"
    if not receipt_path.is_file():
        raise SystemExit("Missing build receipt; run tools/build_pluggbox.py before packaging.")
    receipt = json.loads(receipt_path.read_text())
    if receipt.get("inputs_sha256") != input_hashes():
        raise SystemExit("Browser build is stale relative to its sources/assets; rebuild before packaging.")
    if receipt.get("outputs_sha256") != {name: digest(SITE / name) for name in WEB_FILES}:
        raise SystemExit("Browser artifacts differ from the build receipt; rebuild before packaging.")
    # Always refresh auditions through the deliverable engine, including when
    # --no-build reuses verified runtime bytes. No browser/hardware is needed.
    renderer = ROOT / "tools/render_pluggbox_audio.mjs"
    subprocess.run(["node", str(renderer)], cwd=ROOT, check=True)
    audio_output = ROOT / "build/pluggbox-audio"
    audio_metrics = json.loads((audio_output / "metrics.json").read_text())
    if (audio_metrics.get("wasmSha256") != digest(SITE / "pluggbox.wasm") or
            audio_metrics.get("rendererSha256") != digest(renderer)):
        raise SystemExit("Audio metrics do not match the current WASM and renderer.")
    (SITE / "audio").mkdir(exist_ok=True)
    included_renders = []
    for name in AUDIO_FILES:
        matches = [entry for entry in audio_metrics["renders"] if entry["file"] == name]
        if len(matches) != 1 or matches[0]["peak"] <= 0.001 or matches[0]["clippedSamples"]:
            raise SystemExit(f"Audition failed its audible/non-clipping check: {name}")
        included_renders.extend(matches)
        shutil.copy2(audio_output / name, SITE / "audio" / name)
    packaged_metrics = dict(audio_metrics, renders=included_renders)
    (SITE / "audio/metrics.json").write_text(json.dumps(packaged_metrics, indent=2) + "\n")
    (SITE / "LICENSE.txt").write_bytes((ROOT / "LICENSE").read_bytes())
    (SITE / "LICENSING.md").write_bytes((ROOT / "LICENSING.md").read_bytes())
    source_archive()
    if receipt.get("inputs_sha256") != input_hashes():
        raise SystemExit("Build inputs changed while archiving source; rebuild before packaging.")
    (SITE / "README.txt").write_text(
        "PLUGGBOX — GLASS / FIRST AUDITION\n\n"
        "Extract this ZIP, then serve the pluggbox directory over HTTP with:\n"
        "    python3 -m http.server --bind 127.0.0.1 8766 --directory pluggbox\n"
        "Open that server in a current browser, then click Start audio.\n"
        "Hear starter jam plays the matching four-part phrase. Play beat plays\n"
        "the drum groove; use the pads to play or record your own parts.\n"
        "Changes stay in this browser session. Reset palette starts fresh.\n\n"
        "To listen without running the instrument, open either WAV file:\n"
        "    audio/glass-starter-jam.wav — original GLASS starting sounds\n"
        "    audio/glass-harder-take.wav — harder sound variations\n"
        "audio/metrics.json binds these renders to the packaged WASM and\n"
        "reports their measured levels and clipping counts.\n\n"
        "AudioWorklet requires HTTP(S); opening index.html as a local file\n"
        "does not provide the required browser context.\n\n"
        "Matching GPL source: pluggbox-source.tar.gz. Notices: LICENSE.txt\n"
        "and LICENSING.md. Artifact hashes are listed in SHA256SUMS.\n"
        "This is a browser audition; it includes no FM-1 firmware installer.\n"
    )
    files = (*WEB_FILES, "build-receipt.json", "LICENSE.txt", "LICENSING.md", "README.txt", "pluggbox-source.tar.gz",
             *("audio/" + name for name in AUDIO_FILES), "audio/metrics.json")
    manifest = {
        "product": "Pluggbox",
        "target": "browser-audition",
        "upstream": json.loads((ROOT / "UPSTREAM.json").read_text()),
        "files": {name: {"sha256": digest(SITE / name), "bytes": (SITE / name).stat().st_size} for name in files},
        "instructions": "Serve this directory over HTTP. Start audio requires a user gesture. No FM-1 installation is included.",
    }
    (SITE / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    all_files = (*files, "manifest.json")
    (SITE / "SHA256SUMS").write_text("".join(f"{digest(SITE / name)}  {name}\n" for name in sorted(all_files)))
    target = ROOT / "build/pluggbox-audition.zip"
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in sorted((*all_files, "SHA256SUMS")):
            info = zipfile.ZipInfo("pluggbox/" + name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, (SITE / name).read_bytes())
    print(f"Local audition package: {target} ({target.stat().st_size:,} bytes)")
    print(f"Website and matching source: {SITE}")


if __name__ == "__main__":
    main()
