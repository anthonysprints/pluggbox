#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Package the exact verified Pluggbox FM-1 owner-trial build and its source.

No device is contacted and nothing is published. --no-build still checks the
actual target receipt, pinned compiler/SDK, canonical firmware and ELF budgets.
The separate installer limits this candidate to a normal Jambox source.
"""
from pathlib import Path, PurePosixPath
import argparse
import gzip
import io
import json
import os
import shutil
import stat
import subprocess
import sys
import tarfile
import tempfile

import build_pluggbox_device as device
import plugg_device_build_receipt as receipt
from package_jam_emu import NOTICES

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "build/pluggbox-device"
FIRMWARE = f"pluggbox-{receipt.VERSION}.fwsc"
SOURCE = "pluggbox-source.tar.gz"
TRANSITIONS = ["jambox-normal-to-pluggbox"]
TARGET = {"model": "M-VAVE FM-1", "soc": "AC791N", "platform": "WL82", "flash_bytes": 1048576,
          "flash_jedec": "0x856014", "chip_key": "0x980f"}
SOURCE_DIRS = ("assets", "docs", "firmware", "LICENSES", "tests", "tools", "web")
SOURCE_FILES = ("README.md", "AGENTS.md", "LICENSE", "LICENSING.md", "UPSTREAM.json", "build.sh", ".gitignore")
BLOCKED_PARTS = {".git", ".aws", ".ssh", ".env", ".npmrc", ".netrc", "node_modules", "__pycache__",
                 ".cache", ".venv", "build", "private", "secrets", "credentials", ".pytest_cache"}
BLOCKED_SUFFIXES = {".pyc", ".pyo", ".fwsc", ".bin", ".elf", ".wasm", ".pem", ".key", ".p12", ".pfx"}
LICENSE_FILES = frozenset(NOTICES.values()) | {"licenses/phys_dsp.c-notice.txt", "licenses/phys_symp.c-notice.txt",
    "licenses/AC79-SDK-LICENSE.txt", "licenses/AC79-SDK-README.md"}
FILES = frozenset({FIRMWARE, SOURCE, "manifest.json", "build-receipt.json", "memory.json", "trial.json",
                   "pluggbox-release.json", "README.txt", "SHA256SUMS", *LICENSE_FILES})
require = receipt.require


def descriptor(name, data):
    return {"file": name, "sha256": receipt.sha(data), "size_bytes": len(data)}


def json_object(data, label):
    def unique(pairs):
        result = {}
        for name, value in pairs:
            require(name not in result, f"Duplicate field in {label}: {name}")
            result[name] = value
        return result
    try:
        result = json.loads(data, object_pairs_hook=unique)
    except (ValueError, UnicodeError) as error:
        raise ValueError(f"Invalid {label}: {error}") from error
    require(isinstance(result, dict), f"{label} must be an object")
    return result


def source_files(root=ROOT):
    root = Path(root).resolve()
    selected = []
    for name in SOURCE_FILES:
        path = root / name
        require(path.is_file() and not path.is_symlink(), f"Missing or linked source root file: {name}")
        selected.append(path)
    for name in SOURCE_DIRS:
        directory = root / name
        require(directory.is_dir() and not directory.is_symlink(), f"Missing or linked source directory: {name}")
        for current, dirs, names in os.walk(directory, followlinks=False):
            dirs[:] = sorted(d for d in dirs if d.lower() not in BLOCKED_PARTS and not d.lower().startswith(".env."))
            for entry in dirs:
                require(not (Path(current) / entry).is_symlink(), f"Linked source directory refused: {entry}")
            for filename in sorted(names):
                path = Path(current) / filename
                if filename.lower() in BLOCKED_PARTS or filename.lower().startswith(".env.") or filename == ".DS_Store" or path.suffix.lower() in BLOCKED_SUFFIXES:
                    continue
                require(path.is_file() and not path.is_symlink(), f"Non-regular source file refused: {path}")
                require(path.stat().st_size <= 16 * 1024 * 1024, f"Source file too large: {path}")
                selected.append(path)
    require(len(selected) <= 10000, "Too many source files")
    return sorted(selected)


def source_archive(record, root=ROOT):
    root = Path(root).resolve()
    entries = {path.relative_to(root).as_posix(): path.read_bytes() for path in source_files(root)}
    for name, digest in record["inputs_sha256"].items():
        require(name in entries and receipt.sha(entries[name]) == digest,
                f"Corresponding source missing or changed since compilation: {name}")
    hashes = {name: receipt.sha(data) for name, data in sorted(entries.items())}
    entries["SOURCE-MANIFEST.json"] = receipt.json_bytes(hashes)
    result = io.BytesIO()
    with gzip.GzipFile(filename="", mode="wb", fileobj=result, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w|", format=tarfile.PAX_FORMAT) as archive:
            for name, data in sorted(entries.items()):
                info = tarfile.TarInfo("pluggbox-source/" + name)
                info.size = len(data)
                info.mode = 0o755 if name != "SOURCE-MANIFEST.json" and (root / name).stat().st_mode & stat.S_IXUSR else 0o644
                info.uid = info.gid = info.mtime = 0
                archive.addfile(info, io.BytesIO(data))
    require(receipt.hashes(root, hashes) == hashes, "Source changed while archiving; rerun packaging")
    return result.getvalue(), hashes


def source_contents(data):
    require(len(data) <= 32 * 1024 * 1024, "Source archive is too large")
    entries, total = {}, 0
    try:
        with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as archive:
            for index, item in enumerate(archive):
                require(index < 10000 and item.isfile(), "Unsupported source archive member")
                require(item.name.startswith("pluggbox-source/"), "Unexpected source prefix")
                name = item.name.removeprefix("pluggbox-source/")
                parts = PurePosixPath(name).parts
                require(name and not name.startswith("/") and "\\" not in name and all(p not in ("", ".", "..") for p in name.split("/")), "Unsafe source path")
                require(not (set(p.lower() for p in parts) & BLOCKED_PARTS) and not any(p.lower().startswith(".env.") for p in parts), "Private path in source")
                require((len(parts) == 1 and name in {*SOURCE_FILES, "SOURCE-MANIFEST.json"}) or
                        (len(parts) > 1 and parts[0] in SOURCE_DIRS), "Unexpected source root")
                require(PurePosixPath(name).suffix.lower() not in BLOCKED_SUFFIXES and name not in entries and 0 <= item.size <= 16 * 1024 * 1024, "Invalid source entry")
                total += item.size
                require(total <= 128 * 1024 * 1024, "Expanded source archive too large")
                entries[name] = archive.extractfile(item).read()
    except (tarfile.TarError, OSError, EOFError) as error:
        raise ValueError("Cannot read corresponding source archive") from error
    expected = json_object(entries.get("SOURCE-MANIFEST.json", b""), "source manifest")
    require(set(expected) == set(entries) - {"SOURCE-MANIFEST.json"}, "Source manifest membership mismatch")
    require(all(receipt.sha(entries[name]) == digest for name, digest in expected.items()), "Source archive checksum mismatch")
    required = {"LICENSE", "LICENSING.md", "firmware/src/plugg_palette.c", "firmware/src/plugg_identity.h",
                "firmware/loader/loader.c", "tools/build_pluggbox_device.py", "tools/plugg_device_build_receipt.py"}
    require(required <= entries.keys(), "Incomplete Pluggbox corresponding source")
    return entries


def license_files(sdk, root=ROOT):
    files = {target: (root / original).read_bytes() for original, target in NOTICES.items()}
    for name in ("phys_dsp.c", "phys_symp.c"):
        text = (root / "firmware/src" / name).read_text()
        files["licenses/" + name + "-notice.txt"] = (text[:text.index("*/") + 2] + "\n").encode()
    for name, target in (("LICENSE", "licenses/AC79-SDK-LICENSE.txt"), ("README.md", "licenses/AC79-SDK-README.md")):
        files[target] = (sdk / name).read_bytes()
    return files


def validate_files(files):
    require(set(files) == FILES, "Pluggbox device bundle membership mismatch")
    checksums = {}
    for line in files["SHA256SUMS"].decode("ascii").splitlines():
        digest, name = line.split("  ", 1)
        require(name not in checksums, "Duplicate bundle checksum")
        checksums[name] = digest
    require(set(checksums) == FILES - {"SHA256SUMS"} and
            all(receipt.sha(files[name]) == digest for name, digest in checksums.items()), "Device bundle checksums mismatch")
    manifest = json_object(files["manifest.json"], "device manifest")
    require(set(manifest) == {"schema_version", "family", "version", "release_enabled", "hardware_validated",
        "target", "identities", "firmware", "source", "build", "transitions", "licenses"}, "Unexpected device manifest fields")
    require(type(manifest["schema_version"]) is int and manifest["schema_version"] == 1 and manifest["family"] == "pluggbox" and manifest["version"] == receipt.VERSION and
            manifest["release_enabled"] is False and manifest["hardware_validated"] is False and
            manifest["target"] == TARGET and manifest["identities"] == receipt.IDENTITIES, "Wrong Pluggbox candidate profile")
    require(manifest["firmware"] == descriptor(FIRMWARE, files[FIRMWARE]), "Firmware descriptor mismatch")
    record = json_object(files["build-receipt.json"], "device receipt")
    require(record.get("schema_version") == 1 and record.get("kind") == "pluggbox-device-build", "Wrong device receipt")
    device.check_configuration(record["configuration"])
    require(record["artifacts"]["felucca.fwsc"] == {"sha256": receipt.sha(files[FIRMWARE]), "size_bytes": len(files[FIRMWARE])}, "Receipt does not describe bundled firmware")
    require(manifest["source"] == {**descriptor(SOURCE, files[SOURCE]), **{key: record["source"][key] for key in ("revision", "dirty")}}, "Source descriptor mismatch")
    require(manifest["build"] == {"receipt_file": "build-receipt.json", "receipt_sha256": receipt.sha(files["build-receipt.json"]),
            "flags": record["configuration"]["app"]["flags"], "memory_report_file": "memory.json", "memory_report_sha256": receipt.sha(files["memory.json"])}, "Build evidence descriptor mismatch")
    require(manifest["transitions"] == {"mode": "owner-trial", "approved": [], "simulated": TRANSITIONS}, "Wrong trial transition")
    require(manifest["licenses"] == [descriptor(name, files[name]) for name in sorted(LICENSE_FILES)], "License descriptors mismatch")
    memory = json_object(files["memory.json"], "memory report")
    require(memory.get("schema_version") == 1 and memory.get("ok") is True and memory.get("errors") == [] and memory.get("app") and memory.get("loader") and
            memory.get("ota", {}).get("headers_crc_body_crc_and_loader_match") is True, "Target memory/ELF report failed")
    for field, name in {"app_bin": "felucca.bin", "app_elf": "felucca.elf", "loader_bin": "loader/loader.bin",
                        "loader_elf": "loader/loader.elf", "ota_bin": "loader/ota.bin"}.items():
        require(memory["sha256"][field] == record["artifacts"][name]["sha256"], "Memory report/receipt artifact mismatch")
    source = source_contents(files[SOURCE])
    require(record.get("inputs_sha256") and all(name in source and receipt.sha(source[name]) == digest
            for name, digest in record["inputs_sha256"].items()), "Corresponding source differs from compiler receipt")
    require(source["LICENSE"] == files["LICENSE"] and source["LICENSING.md"] == files["LICENSING.md"], "Source/license mismatch")
    trial = {"schema_version": 1, "kind": "pluggbox-owner-trial", "hardware_validated": False, "transitions": TRANSITIONS,
             "manifest_sha256": receipt.sha(files["manifest.json"]), "firmware_sha256": manifest["firmware"]["sha256"]}
    require(json_object(files["trial.json"], "trial") == trial, "Trial metadata binding mismatch")
    release = {"schema_version": 1, "family": "pluggbox", "status": "experimental", "install_available": True,
               "hardware_validated": False, "version": receipt.VERSION, "manifest_sha256": trial["manifest_sha256"],
               "firmware_sha256": trial["firmware_sha256"]}
    require(json_object(files["pluggbox-release.json"], "release") == release, "Release metadata binding mismatch")
    return manifest


def read_package(directory=OUTPUT):
    directory = Path(directory)
    require(directory.is_dir() and not directory.is_symlink(), "Missing or linked Pluggbox device bundle")
    files = {}
    for path in directory.rglob("*"):
        require(not path.is_symlink(), "Linked device bundle entry refused")
        name = path.relative_to(directory).as_posix()
        if path.is_dir():
            require(name == "licenses", "Unexpected device bundle directory")
        else:
            require(name in FILES and path.is_file() and path.stat().st_size <= 64 * 1024 * 1024, "Unexpected device bundle file")
            files[name] = path.read_bytes()
    validate_files(files)
    return files


def package(toolchain, sdk, output=OUTPUT):
    record, memory = device.verify_build(toolchain, sdk)
    source, source_hashes = source_archive(record)
    memory["build_dir"] = "build"
    licenses = license_files(sdk)
    files = {FIRMWARE: (ROOT / "build/felucca.fwsc").read_bytes(), SOURCE: source,
             "build-receipt.json": receipt.json_bytes(record), "memory.json": receipt.json_bytes(memory), **licenses}
    manifest = {"schema_version": 1, "family": "pluggbox", "version": receipt.VERSION,
        "release_enabled": False, "hardware_validated": False, "target": TARGET, "identities": receipt.IDENTITIES,
        "firmware": descriptor(FIRMWARE, files[FIRMWARE]),
        "source": {**descriptor(SOURCE, source), **{key: record["source"][key] for key in ("revision", "dirty")}},
        "build": {"receipt_file": "build-receipt.json", "receipt_sha256": receipt.sha(files["build-receipt.json"]),
                  "flags": record["configuration"]["app"]["flags"], "memory_report_file": "memory.json",
                  "memory_report_sha256": receipt.sha(files["memory.json"])},
        "transitions": {"mode": "owner-trial", "approved": [], "simulated": TRANSITIONS},
        "licenses": [descriptor(name, data) for name, data in sorted(licenses.items())]}
    files["manifest.json"] = receipt.json_bytes(manifest)
    bindings = {"manifest_sha256": receipt.sha(files["manifest.json"]), "firmware_sha256": manifest["firmware"]["sha256"]}
    files["trial.json"] = receipt.json_bytes({"schema_version": 1, "kind": "pluggbox-owner-trial", "hardware_validated": False,
        "transitions": TRANSITIONS, **bindings})
    files["pluggbox-release.json"] = receipt.json_bytes({"schema_version": 1, "family": "pluggbox", "status": "experimental",
        "install_available": True, "hardware_validated": False, "version": receipt.VERSION, **bindings})
    files["README.txt"] = ("PLUGGBOX " + receipt.VERSION + " — EXPERIMENTAL OWNER TRIAL\n\n"
        "The exact firmware, corresponding source, pinned build receipt, target memory\n"
        "report and notices are bound by manifest.json and SHA256SUMS. trial.json permits\n"
        "only the separately validated normal-Jambox-to-Pluggbox installer transition.\n"
        "Hardware validation remains false. These software checks do not prove power-loss\n"
        "recovery, physical audio deadlines or every hardware control.\n\n"
        "This prototype replaces the running instrument with Pluggbox. Its musical\n"
        "sessions are temporary; it does not import or overwrite Jambox checkpoints.\n"
        "Use the guided Chrome/Edge page, not an arbitrary firmware flashing tool.\n"
        "Nothing in the packaging command connects to, installs on or resets a device.\n\n"
        "Rebuild: python3 tools/build_pluggbox_device.py\n"
        "Repackage: python3 tools/package_pluggbox_device.py --no-build\n").encode()
    files["SHA256SUMS"] = "".join(f"{receipt.sha(data)}  {name}\n" for name, data in sorted(files.items())).encode()
    validate_files(files)
    require(receipt.hashes(ROOT, source_hashes) == source_hashes, "Source changed while packaging; retry")
    require(receipt.external_inputs(toolchain, sdk, strict=False) == {"compiler": record["toolchain"], "sdk": record["sdk"]}, "Compiler/SDK changed while packaging")
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    require(not output.is_symlink(), "Refusing linked device bundle output")
    with tempfile.TemporaryDirectory(prefix=".pluggbox-device-", dir=output.parent) as temporary:
        stage = Path(temporary) / "bundle"
        stage.mkdir()
        for name, data in files.items():
            target = stage / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        read_package(stage)
        if output.exists():
            require(output.is_dir(), "Existing bundle output is not a directory")
            shutil.rmtree(output)
        stage.rename(output)
    print(f"Pluggbox owner-trial bundle: {output}; {len(files[FIRMWARE]):,} firmware bytes; SHA256 {manifest['firmware']['sha256']}")
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--no-build", action="store_true", help="Verify and package the existing real Pluggbox target")
    parser.add_argument("--toolchain", type=Path, default=Path(os.environ.get("JIELI_TOOLCHAIN", "/workspace/toolchains/jieli/toolchain")))
    parser.add_argument("--sdk", type=Path, default=Path(os.environ.get("AC79_SDK", "/workspace/deps/ac79-sdk")))
    args = parser.parse_args()
    try:
        toolchain, sdk = args.toolchain.resolve(), args.sdk.resolve()
        if not args.no_build:
            subprocess.run([sys.executable, "tools/build_pluggbox_device.py"], cwd=ROOT,
                env={**os.environ, "JIELI_TOOLCHAIN": str(toolchain), "AC79_SDK": str(sdk)}, check=True)
        package(toolchain, sdk)
    except (ValueError, KeyError, OSError, subprocess.SubprocessError) as error:
        parser.exit(1, f"Pluggbox device packaging refused: {error}\n")


if __name__ == "__main__":
    main()
