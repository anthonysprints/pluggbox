#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Original Pluggbox drum recipes in Hz/ms/dB; uses the shared FM-1 encoder."""
import copy
from pathlib import Path
import sys
from gen_drumkits import S, enc, LANES

# The tone/noise recipes here are original; no recordings or factory kits copied.
PLUGG = {
    'KICK': S('sine', 54, bend=22, bt=18, decay=150, tlev=114, click=32, drive=18, level=-8),
    'SNARE': S('tri', 185, decay=65, tlev=40, src='white', nlev=105, ndec=95, filt=('bp', 2350, .18), hpf=650, level=-13),
    'CLAP': S(src='clap', nlev=112, ndec=90, filt=('bp', 1700, .2), hpf=850, level=-13),
    'CHH': S(hz=245, src='metal', nlev=92, ndec=30, filt=('hp', 8200, .1), hpf=6400, level=-21),
    'OHH': S(hz=245, src='cym', nlev=86, ndec=220, filt=('hp', 7100, .12), hpf=5600, level=-23),
    'TOMLO': S('sine', 118, bend=7, bt=25, decay=110, tlev=90, click=14, level=-15),
    'TOMHI': S('sine', 178, bend=9, bt=20, decay=90, tlev=88, click=18, level=-17),
    'CRASH': S(hz=260, src='cym', nlev=86, ndec=620, filt=('hp', 6500, .12), hpf=4700, level=-24),
    'RIDE': S('bell', 580, decay=240, tlev=40, src='metal', nlev=48, ndec=190, hpf=3900, level=-24),
    'SHAKER': S(src='white', nlev=80, ndec=38, filt=('hp', 9000, .1), level=-23),
    'CONGA': S('sine', 310, bend=8, bt=14, decay=85, tlev=80, click=12, level=-19),
    'RIM': S('bell', 490, decay=35, tlev=68, click=42, filt=('bp', 1900, .25, 'all'), level=-19),
    'COWBELL': S('bell', 720, decay=90, tlev=62, filt=('bp', 2300, .12, 'all'), level=-22),
    'CLAVE': S('tri', 1350, decay=20, tlev=54, click=28, level=-22),
    'KICK2': S('sine', 62, bend=28, bt=14, decay=95, tlev=100, click=54, drive=40, level=-10),
    'SNARE2': S(src='white', nlev=98, ndec=55, filt=('bp', 3400, .22), hpf=1200, level=-17),
}
HARD = copy.deepcopy(PLUGG)
HARD.update({
    'KICK': S('sine', 53, bend=32, bt=14, decay=135, tlev=118, click=65, drive=64, level=-10),
    'SNARE': S('tri', 210, decay=70, tlev=56, src='white', nlev=117, ndec=125, filt=('bp', 2600, .26), hpf=700, drive=25, level=-15),
    'CLAP': S(src='clap', nlev=122, ndec=130, filt=('bp', 2050, .28), hpf=950, drive=28, level=-16),
    'CHH': S(hz=290, src='cym', nlev=106, ndec=35, filt=('hp', 7900, .18), hpf=5900, drive=10, level=-23),
    'OHH': S(hz=290, src='cym', nlev=98, ndec=280, filt=('hp', 6800, .2), hpf=5100, level=-24),
})

def main(path):
    lines = ['/* SPDX-License-Identifier: GPL-3.0-only */',
             '/* Generated from tools/gen_pluggbox_drums.py; original Pluggbox synthesis. */',
             'static const dsnd_t plugg_drum_recipes[2][DS_LANES] = {']
    for kit in (PLUGG, HARD):
        lines.append('    {')
        for lane in LANES:
            values = enc(kit[lane])
            assert len(values) == 22
            lines.append('        {' + ', '.join(map(str, values)) + '}, /* ' + lane + ' */')
        lines.append('    },')
    lines.append('};')
    Path(path).write_text('\n'.join(lines) + '\n')
    print('Pluggbox: two original synthesized kits ->', path)

if __name__ == '__main__':
    main(sys.argv[1])
