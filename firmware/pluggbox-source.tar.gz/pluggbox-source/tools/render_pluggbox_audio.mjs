// SPDX-License-Identifier: GPL-3.0-only
// Offline auditions through the deliverable WASM engine, at browser output gain.
import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { JamEngine } from '../web/plugg/worklet.js';

const root = resolve(new URL('..', import.meta.url).pathname);
const wasmBytes = await readFile(resolve(root, 'build/pluggbox/pluggbox.wasm'));
const module = await WebAssembly.compile(wasmBytes);
const output = resolve(root, 'build/pluggbox-audio');
await mkdir(output, { recursive: true });
const rate = 44100, gain = 0.6, metrics = [];

function render(engine, frames) {
  const left = new Float32Array(frames), right = new Float32Array(frames);
  engine.render(left, right);
  return [left, right];
}
async function wav(name, segments, detail) {
  const frames = segments.reduce((count, [left]) => count + left.length, 0);
  const bytes = Buffer.alloc(44 + frames * 4);
  bytes.write('RIFF', 0); bytes.writeUInt32LE(bytes.length - 8, 4); bytes.write('WAVEfmt ', 8);
  bytes.writeUInt32LE(16, 16); bytes.writeUInt16LE(1, 20); bytes.writeUInt16LE(2, 22);
  bytes.writeUInt32LE(rate, 24); bytes.writeUInt32LE(rate * 4, 28);
  bytes.writeUInt16LE(4, 32); bytes.writeUInt16LE(16, 34);
  bytes.write('data', 36); bytes.writeUInt32LE(frames * 4, 40);
  let offset = 44, peak = 0, sum = 0, clipped = 0;
  for (const [left, right] of segments) for (let i = 0; i < left.length; i++) {
    for (const value of [left[i], right[i]]) {
      assert(Number.isFinite(value) && Math.abs(value) <= 1, 'bounded production audio');
      const sample = value * gain;
      peak = Math.max(peak, Math.abs(sample)); sum += sample * sample;
      if (Math.abs(value) >= 0.999) clipped++;
      bytes.writeInt16LE(Math.round(sample * 32767), offset); offset += 2;
    }
  }
  assert(peak > 0.001, `${name} must contain actual audio`);
  await writeFile(resolve(output, name), bytes);
  metrics.push({ file: name, seconds: frames / rate, peak, rms: Math.sqrt(sum / (frames * 2)), clippedSamples: clipped, ...detail });
}

for (const variant of [0, 1]) {
  const engine = new JamEngine(module);
  for (let track = 0; track < 4; track++) engine.command({ type: 'sound', args: [track, variant] });
  engine.command({ type: 'demo', args: [1] });
  const musical = render(engine, Math.round(rate * 60 / 144 * 8 * 4));
  engine.command({ type: 'panic' });
  const tail = render(engine, rate * 3);
  await wav(variant ? 'glass-harder-take.wav' : 'glass-starter-jam.wav', [musical, tail],
    { kind: 'four-part-demo', variant, bpm: 144, scale: 'F# minor', loops: 4 });
}

const names = ['bass', 'chords', 'lead', 'kit'];
for (let track = 0; track < 4; track++) for (let variant = 0; variant < 2; variant++) {
  const engine = new JamEngine(module);
  engine.command({ type: 'select', args: [track] });
  engine.command({ type: 'sound', args: [track, variant] });
  const sound = engine.snapshot().tracks.find(part => part.track === track).sound;
  const segments = [];
  if (track === 3) {
    // Four actual panel pads: kick, clap, closed and open hi-hat.
    for (const key of [0, 6, 7, 9]) {
      engine.command({ type: 'key', args: [key, 1] });
      segments.push(render(engine, rate / 3));
      engine.command({ type: 'key', args: [key, 0] });
      segments.push(render(engine, rate / 3));
    }
  } else {
    engine.command({ type: 'key', args: [7, 1] });
    segments.push(render(engine, Math.round(rate * 0.8)));
    if (track === 0) {
      engine.command({ type: 'key', args: [11, 1] });
      segments.push(render(engine, Math.round(rate * 0.5)));
      engine.command({ type: 'key', args: [7, 0] });
      engine.command({ type: 'key', args: [11, 0] });
    } else engine.command({ type: 'key', args: [7, 0] });
  }
  segments.push(render(engine, rate * 3));
  await wav(`${names[track]}-${variant + 1}.wav`, segments, { kind: 'isolated-sound', track, variant, sound });
}
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
await writeFile(resolve(output, 'metrics.json'), JSON.stringify({
  wasmSha256: sha256(wasmBytes), rendererSha256: sha256(await readFile(new URL(import.meta.url))),
  sampleRate: rate, outputGain: gain, renders: metrics,
}, null, 2) + '\n');
console.log(`Rendered ${metrics.length} production-WASM WAV auditions in ${output}`);
for (const result of metrics) console.log(`${result.file}: peak ${result.peak.toFixed(3)}, RMS ${result.rms.toFixed(3)}, clipped ${result.clippedSamples}`);
