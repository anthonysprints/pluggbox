#!/bin/bash
# SPDX-License-Identifier: GPL-3.0-only
# Reproduce prerequisites without changing source, installing or publishing.
set -euo pipefail
cd "$(dirname "$0")/../.."
if [[ $# -gt 1 || ( $# == 1 && "$1" != --prerequisites-only ) ]]; then
    echo 'Usage: bash tools/cloud/setup_pluggbox_device.sh [--prerequisites-only]' >&2
    exit 2
fi
if [[ ! -x /workspace/deps/pluggbox-python/bin/python ]]; then
    python3 -m venv /workspace/deps/pluggbox-python
fi
/workspace/deps/pluggbox-python/bin/python -m pip install --disable-pip-version-check \
    --cache-dir /workspace/deps/pip-cache -r tools/cloud/python-requirements.txt
python3 tools/cloud/prepare_sdk.py
if [[ ${1:-} == --prerequisites-only ]]; then
    echo 'Python assets and pinned SDK prepared. A real device build still needs the pinned JieLi compiler.'
    exit 0
fi
# Retain TLS verification and the owner-verified historical archive pin.
# A moving vendor URL returning different bytes is a failure, not a new pin.
python3 tools/cloud/prepare_toolchain.py \
    --expected-sha256 a1545cddbc451a06bac43eb5cd96d831470c42a97c5c0b1f98879a20fc7647bd
python3 tools/cloud/check_device.py
