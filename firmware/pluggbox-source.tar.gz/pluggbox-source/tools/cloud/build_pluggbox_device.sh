#!/bin/bash
# SPDX-License-Identifier: GPL-3.0-only
# Isolated temporary-session target. This script never installs or publishes.
set -euo pipefail
cd "$(dirname "$0")/../.."
if [[ $# != 0 ]]; then
    echo 'Usage: bash tools/cloud/build_pluggbox_device.sh' >&2
    exit 2
fi
export AC79_SDK="${AC79_SDK:-/workspace/deps/ac79-sdk}"
export JIELI_TOOLCHAIN="${JIELI_TOOLCHAIN:-/workspace/toolchains/jieli/toolchain}"
if [[ ! -x /workspace/deps/pluggbox-python/bin/python ]]; then
    echo 'Run bash tools/cloud/setup_pluggbox_device.sh first.' >&2
    exit 1
fi
. /workspace/deps/pluggbox-python/bin/activate
python3 tools/cloud/check_device.py
export PLUGGBOX_PROTO=1 JAMBOX_PROTO=1 JAMBOX_RECOVERY=0
export FELUCCA_PERSIST=0 FELUCCA_FLASH=1 FELUCCA_OTA=1
export FELUCCA_OTA_DRYRUN=0 FELUCCA_OTA_RAMONLY=0
export FELUCCA_ICONS=0 FELUCCA_SLICE=0
exec bash build.sh
