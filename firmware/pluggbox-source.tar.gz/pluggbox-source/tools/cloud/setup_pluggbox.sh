#!/bin/bash
# SPDX-License-Identifier: GPL-3.0-only
# Browser/native workflow only. No device compiler, SDK, or repository changes.
set -euo pipefail
cd "$(dirname "$0")/../.."
for prerequisite in python3 node npm dpkg-deb; do
    command -v "$prerequisite" >/dev/null || { echo "Required tool missing: $prerequisite" >&2; exit 1; }
done
python3 tools/cloud/install_browser.py
mkdir -p /workspace/deps/pluggbox-browser
cp tools/cloud/browser/package.json tools/cloud/browser/package-lock.json /workspace/deps/pluggbox-browser/
npm_config_cache=/workspace/.npm-cache npm ci --prefix /workspace/deps/pluggbox-browser --ignore-scripts --no-audit --no-fund
. tools/cloud/activate_pluggbox.sh
emcc --version
"$CC" --version
"$CHROMIUM_PATH" --version
echo 'Pluggbox browser/native tools ready; no extra Python packages are required.'
