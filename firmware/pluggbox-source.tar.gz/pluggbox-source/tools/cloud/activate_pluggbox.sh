#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-only
# Source from any directory before builds/tests; dependencies survive in /workspace.
if [ ! -f /workspace/toolchains/debian-browser/env.sh ] || [ ! -f /workspace/deps/pluggbox-browser/node_modules/playwright-core/index.mjs ]; then
    echo 'Run bash tools/cloud/setup_pluggbox.sh from the Pluggbox checkout first.' >&2
    return 1
fi
. /workspace/toolchains/debian-browser/env.sh
export PLAYWRIGHT_MODULE=/workspace/deps/pluggbox-browser/node_modules/playwright-core/index.mjs
export CHROMIUM_PATH="${CHROMIUM_PATH:-/usr/bin/chromium}"
