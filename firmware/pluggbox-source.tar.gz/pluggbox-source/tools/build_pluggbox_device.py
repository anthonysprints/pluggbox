#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Build or verify the isolated, temporary-session Pluggbox FM-1 target.

This does not package a public release, publish a site, connect to an FM-1 or
authorize installation. A real target compiler/SDK and all ELF/memory gates are
required; a browser/native build cannot satisfy this command.
"""
import argparse
import json
import os
from pathlib import Path
import subprocess

import fm1pkg_make
import plugg_device_build_receipt as receipt
from cloud import report_device

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / "build"


def check_configuration(configuration):
    require = receipt.require
    require(set(configuration) == {"app", "loader", "package_identity"}, "Invalid Pluggbox build configuration")
    for unit in ("app", "loader"):
        item = configuration[unit]
        require(item.get("identity") == receipt.IDENTITIES[unit], f"Wrong compiled Pluggbox {unit} identity")
        require(set(item.get("flags", {})) == set(receipt.FLAGS) and
                all(type(v) is int and v in (0, 1) for v in item["flags"].values()),
                f"Incomplete compiled {unit} configuration")
    for key, value in receipt.REQUIRED_FLAGS.items():
        require(configuration["app"]["flags"][key] == value, f"Pluggbox requires {key}={value}")
    for key, value in {"PLUGGBOX_PROTO": 1, "JAMBOX_PROTO": 1, "JAMBOX_RECOVERY": 0,
                       "FELUCCA_PERSIST": 0, "FELUCCA_OTA": 1,
                       "FELUCCA_OTA_DRYRUN": 0, "FELUCCA_OTA_RAMONLY": 0}.items():
        require(configuration["loader"]["flags"][key] == value, f"Wrong Pluggbox loader flag {key}")
    require(configuration["app"].get("version") == "Pluggbox " + receipt.VERSION,
            "Wrong compiled Pluggbox version")
    require(configuration["package_identity"] == receipt.IDENTITIES["package"], "Wrong Pluggbox package identity")


def verify_build(toolchain, sdk):
    require = receipt.require
    receipt.jam_identity(ROOT)
    path = BUILD / "device-build-receipt.json"
    require(path.is_file() and not path.is_symlink(), "Missing Pluggbox device receipt; a real target build is required")
    record = json.loads(path.read_bytes())
    require(record.get("schema_version") == 1 and record.get("kind") == "pluggbox-device-build",
            "Expected a Pluggbox device build, not a Jambox or browser artifact")
    check_configuration(record["configuration"])
    dependencies = receipt.dependency_inputs(ROOT, BUILD)
    inputs = record["inputs_sha256"]
    require(set(inputs) == (dependencies - set(receipt.GENERATED)) | receipt.generator_inputs(ROOT),
            "Stale or incomplete Pluggbox source receipt")
    require(receipt.hashes(ROOT, inputs) == inputs, "Pluggbox source/build tools changed; rebuild")
    generated = record["generated_inputs_sha256"]
    require(set(generated) == dependencies & set(receipt.GENERATED) and
            receipt.hashes(ROOT, generated) == generated, "Generated Pluggbox headers changed; rebuild")
    require(set(record["artifacts"]) == {*receipt.ARTIFACTS, "felucca.fwsc"}, "Incomplete target artifact set")
    for name, item in record["artifacts"].items():
        artifact = BUILD / name
        require(artifact.is_file() and not artifact.is_symlink() and artifact.resolve().is_relative_to(BUILD.resolve()),
                f"Missing or unsafe target artifact {name}")
        require(item == {"sha256": receipt.file_sha(artifact), "size_bytes": artifact.stat().st_size},
                f"Target artifact changed since compilation: {name}")
    external = receipt.external_inputs(toolchain, sdk, strict=True)
    require(record["toolchain"] == external["compiler"] and record["sdk"] == external["sdk"],
            "Compiler/SDK provenance does not match the target build")
    require(isinstance(record.get("commands"), list) and record["commands"], "No actual compiler commands recorded")
    memory = report_device.report(BUILD, toolchain)
    require(memory["ok"], "Target memory/ELF checks failed: " + "; ".join(memory["errors"]))
    prior_sdk = fm1pkg_make.SDK
    try:
        fm1pkg_make.SDK = sdk
        app = (BUILD / "felucca.bin").read_bytes()
        loader = (BUILD / "loader/loader.bin").read_bytes()
        package = fm1pkg_make.ufw(fm1pkg_make.flash_image(app, 0x980F),
                               (BUILD / "loader/ota.bin").read_bytes(), receipt.IDENTITIES["package"])
    finally:
        fm1pkg_make.SDK = prior_sdk
    require((BUILD / "felucca.fwsc").read_bytes() == package,
            "Package differs from the exact verified Pluggbox app/loader and pinned SDK")
    require(receipt.IDENTITIES["app"].encode() in app and ("Pluggbox " + receipt.VERSION).encode() in app,
            "Pluggbox app identity/version is absent from the compiled binary")
    require(receipt.IDENTITIES["loader"].encode() in loader, "Pluggbox loader identity is absent")
    require(b"PLUGGBOX" in app and b"PLUGGBOX" in loader, "Pluggbox family response is absent")
    return record, memory


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--no-build", action="store_true", help="Verify existing real Pluggbox target artifacts")
    parser.add_argument("--check", action="store_true", help="Read-only compiler/SDK prerequisite check")
    args = parser.parse_args()
    toolchain = Path(os.environ.get("JIELI_TOOLCHAIN", "/workspace/toolchains/jieli/toolchain")).resolve()
    sdk = Path(os.environ.get("AC79_SDK", "/workspace/deps/ac79-sdk")).resolve()
    try:
        if args.check:
            receipt.jam_identity(ROOT)
            subprocess.run(["python3", "tools/cloud/check_device.py", "--toolchain", str(toolchain), "--sdk", str(sdk)],
                           cwd=ROOT, check=True)
            print("Pluggbox prerequisite files present; no build or installation performed.")
            return
        if not args.no_build:
            subprocess.run(["bash", "tools/cloud/build_pluggbox_device.sh"], cwd=ROOT, check=True)
        record, memory = verify_build(toolchain, sdk)
        result = {"target": "pluggbox-device", "version": receipt.VERSION,
                  "temporary_sessions": True, "install_enabled": False,
                  "firmware_sha256": record["artifacts"]["felucca.fwsc"]["sha256"],
                  "memory": memory}
        (BUILD / "pluggbox-device-validation.json").write_bytes(receipt.json_bytes(result))
        print(json.dumps(result, indent=2))
    except (ValueError, OSError, KeyError, subprocess.SubprocessError) as exc:
        parser.exit(1, "Pluggbox target not ready: " + str(exc) + "\n")


if __name__ == "__main__":
    main()
