#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Verify/stage the Pluggbox website and dry-run its GitHub Pages push.

The default makes only a temporary local deployment commit and a Git push
dry-run. --publish explicitly pushes to anthonysprints/pluggbox's gh-pages
branch. It does not enable GitHub Pages or establish that a URL is live.
The source checkout/index are never modified. The current package deliberately
contains no installable firmware; its FM-1 section is a read-only check.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from dataclasses import dataclass
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import tarfile
import tempfile

from package_pluggbox_site import (
    DEVICE_MODULES, PLAY_FILES, INSTALL_FILES, READ_ONLY_MODULES, ROOT_FILES, AUDIO_FILES, RELEASE,
)

import package_pluggbox_device as device

ROOT = Path(__file__).resolve().parents[1]
SITE = ROOT / 'build/pluggbox-site'
DESTINATION = 'https://github.com/anthonysprints/pluggbox.git'
BRANCH = 'refs/heads/gh-pages'
AUTHOR = ('anthonysprints', '6182444+anthonysprints@users.noreply.github.com')
EXPECTED_FILES = frozenset({
    'index.html', '.nojekyll', 'README.txt', 'site-manifest.json', 'SHA256SUMS',
    'firmware/pluggbox-release.json', *ROOT_FILES, *READ_ONLY_MODULES,
    *('play/' + name for name in PLAY_FILES),
    *('install/' + name for name in INSTALL_FILES),
    *('audio/' + name for name in AUDIO_FILES),
})
EXPECTED_DIRS = frozenset({'play', 'install', 'audio', 'firmware'})
SOURCE_ROOTS = frozenset({'assets', 'docs', 'firmware', 'LICENSES', 'tests', 'tools', 'web'})
SOURCE_FILES = frozenset({'README.md', 'AGENTS.md', 'LICENSE', 'LICENSING.md', 'UPSTREAM.json', 'build.sh', '.gitignore'})
BLOCKED_PARTS = frozenset({'.git', '.aws', '.ssh', '.env', '.npmrc', '.netrc', 'node_modules',
                          '__pycache__', '.venv', 'build', 'secrets', 'credentials'})
BLOCKED_SOURCE_SUFFIXES = frozenset({'.fwsc', '.bin', '.elf', '.wasm', '.pem', '.key', '.p12', '.pfx'})
GIT_LOCATION_ENV = frozenset({'GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE', 'GIT_COMMON_DIR',
    'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES', 'GIT_PREFIX', 'GIT_NAMESPACE',
    'GIT_SHALLOW_FILE', 'GIT_QUARANTINE_PATH', 'GIT_REPLACE_REF_BASE'})
GIT_OPTIONS = ['-c', 'core.hooksPath=/dev/null', '-c', 'core.fsmonitor=false',
               '-c', 'core.autocrlf=false', '-c', 'core.attributesFile=/dev/null']


class DeploymentError(RuntimeError):
    pass


def require(condition, message):
    if not condition:
        raise DeploymentError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def object_json(data, description):
    def unique(pairs):
        result = {}
        for name, value in pairs:
            require(name not in result, f'Duplicate field in {description}: {name}')
            result[name] = value
        return result
    try:
        result = json.loads(data, object_pairs_hook=unique)
    except (ValueError, UnicodeError) as exc:
        raise DeploymentError(f'Invalid JSON: {description}') from exc
    require(isinstance(result, dict), f'{description} must be an object')
    return result


def source_contents(data):
    """Read a bounded regular-file tar archive; never extract or execute it."""
    require(len(data) <= 32 * 1024 * 1024, 'Source archive is too large')
    result, total = {}, 0
    try:
        with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
            for index, entry in enumerate(archive):
                require(index < 10000 and entry.isfile(), 'Unsupported source archive member')
                require(entry.name.startswith('pluggbox-source/'), 'Unexpected source archive prefix')
                name = entry.name.removeprefix('pluggbox-source/')
                parts = PurePosixPath(name).parts
                require(name and not name.startswith('/') and '\\' not in name and
                        all(p not in ('', '.', '..') for p in name.split('/')), 'Unsafe source archive path')
                require(not (set(p.lower() for p in parts) & BLOCKED_PARTS) and
                        not any(p.lower().startswith('.env.') for p in parts) and
                        PurePosixPath(name).suffix.lower() not in BLOCKED_SOURCE_SUFFIXES,
                        'Private or device-binary material in source archive')
                require((len(parts) == 1 and name in SOURCE_FILES) or
                        (len(parts) > 1 and parts[0] in SOURCE_ROOTS), 'Unexpected source archive location')
                require(name not in result and 0 <= entry.size <= 16 * 1024 * 1024, 'Invalid source archive entry')
                total += entry.size
                require(total <= 128 * 1024 * 1024, 'Expanded source archive is too large')
                result[name] = archive.extractfile(entry).read()
    except (tarfile.TarError, OSError, EOFError) as exc:
        raise DeploymentError('Cannot read corresponding source archive') from exc
    required = {'LICENSE', 'LICENSING.md', 'README.md', 'firmware/src/plugg_palette.c',
                'firmware/host/plugg_preview.c', 'tools/build_pluggbox.py',
                'tools/package_pluggbox_site.py', 'web/plugg/app.js', 'web/plugg/worklet.js',
                *('web/plugg-install/' + n for n in INSTALL_FILES)}
    require(required <= result.keys(), 'Required Pluggbox corresponding source is missing')
    return result


def validate_snapshot(files):
    enabled = object_json(files['firmware/pluggbox-release.json'], 'release').get('install_available') is True
    expected = EXPECTED_FILES | set(DEVICE_MODULES) | {'firmware/' + n for n in device.FILES} if enabled else EXPECTED_FILES
    require(set(files) == expected, 'Website must contain the exact guided-site file set')
    if enabled:
        candidate = {n: files['firmware/' + n] for n in device.FILES}
        device.validate_files(candidate)
    require(set(files) == expected, 'Website must contain the exact guided-site file set')
    require(not files['.nojekyll'] and files['play/pluggbox.wasm'].startswith(b'\0asm\x01\0\0\0'),
            'Invalid Pages marker or WASM module')
    checksums = {}
    try:
        for line in files['SHA256SUMS'].decode('ascii').splitlines():
            digest, name = line.split('  ', 1)
            require(re.fullmatch('[0-9a-f]{64}', digest) and name not in checksums,
                    'Malformed or duplicate website checksum')
            checksums[name] = digest
    except (ValueError, UnicodeError) as exc:
        raise DeploymentError('Malformed website checksums') from exc
    require(set(checksums) == set(files) - {'SHA256SUMS'}, 'Checksums must cover every website file exactly once')
    require(all(sha(files[name]) == digest for name, digest in checksums.items()), 'Website checksum mismatch')
    release = object_json(files['firmware/pluggbox-release.json'], 'release')
    require(enabled or release == RELEASE,
            'This publisher accepts only the unavailable Pluggbox device release')
    manifest = object_json(files['site-manifest.json'], 'site manifest')
    require(manifest.get('product') == 'Pluggbox' and
            manifest.get('target') == 'guided-browser-and-read-only-device-page' and
            manifest.get('install_available') is enabled and manifest.get('firmware_payload_included') is enabled,
            'Unexpected guided-site profile')
    descriptors = manifest.get('files')
    require(isinstance(descriptors, dict) and set(descriptors) == set(files) - {'site-manifest.json', 'SHA256SUMS'},
            'Site manifest membership mismatch')
    for name, description in descriptors.items():
        require(description == {'sha256': sha(files[name]), 'size_bytes': len(files[name])},
                f'Site manifest binding mismatch: {name}')
    require(manifest.get('runtime_wasm_sha256') == sha(files['play/pluggbox.wasm']), 'WASM manifest binding mismatch')
    source = source_contents(files['pluggbox-source.tar.gz'])
    if enabled:
        device_source = device.source_contents(candidate[device.SOURCE])
        for name in DEVICE_MODULES + READ_ONLY_MODULES:
            require(device_source.get('web/' + name) == files[name], 'Device controller source mismatch')
    for name in INSTALL_FILES:
        require(source['web/plugg-install/' + name] == files['install/' + name], f'Installer source differs: {name}')
    for name in READ_ONLY_MODULES + (DEVICE_MODULES if enabled else ()):
        require(source.get('web/' + name) == files[name], f'Read-only transport source differs: {name}')
    for name in ('style.css', 'app.js', 'worklet.js'):
        require(source.get('web/plugg/' + name) == files['play/' + name], f'Player source differs: {name}')
    expected_html = source.get('web/plugg/index.html', b'').replace(
        b'href="pluggbox-source.tar.gz"', b'href="../pluggbox-source.tar.gz"').replace(
        b'href="LICENSE.txt"', b'href="../LICENSE.txt"')
    require(files['play/index.html'] == expected_html, 'Player HTML differs from its documented relocation')
    require(source['LICENSE'] == files['LICENSE.txt'] and source['LICENSING.md'] == files['LICENSING.md'],
            'License downloads differ from corresponding source')
    receipt = object_json(files['play/build-receipt.json'], 'browser receipt')
    require(receipt.get('target') == 'pluggbox-browser', 'Unexpected browser receipt target')
    for name, digest in receipt.get('inputs_sha256', {}).items():
        require(name in source and sha(source[name]) == digest, f'Browser source receipt mismatch: {name}')
    require(bool(receipt.get('inputs_sha256')), 'Browser receipt lacks source bindings')
    expected_outputs = {'index.html': sha(source['web/plugg/index.html']),
                        **{name: sha(files['play/' + name]) for name in ('style.css', 'app.js', 'worklet.js', 'pluggbox.wasm')}}
    require(receipt.get('outputs_sha256') == expected_outputs, 'Browser output receipt mismatch')
    return files


def validate_site(site=SITE):
    site = Path(site).absolute()
    require(all(not p.is_symlink() for p in (site, *site.parents)) and site.is_dir(), 'Website root is missing or linked')
    files = {}
    for path in site.rglob('*'):
        name = path.relative_to(site).as_posix()
        require(not path.is_symlink(), 'Linked website entry refused')
        if path.is_dir():
            require(name in EXPECTED_DIRS | {'firmware/licenses'}, f'Unexpected website directory: {name}')
        else:
            require(name in EXPECTED_FILES | set(DEVICE_MODULES) | {'firmware/' + n for n in device.FILES} and path.is_file() and path.stat().st_size <= 64 * 1024 * 1024,
                    f'Unexpected or oversized website file: {name}')
            files[name] = path.read_bytes()
    return validate_snapshot(files)


def git(directory, *arguments, input_text=None, check=True):
    # Keep proxy authentication/guard configuration, but never inherit a
    # different checkout's index or repository paths.
    environment = {name: value for name, value in os.environ.items() if name not in GIT_LOCATION_ENV}
    result = subprocess.run(['git', *GIT_OPTIONS, *arguments], cwd=directory, env=environment,
                            input=input_text, text=True, capture_output=True)
    if check and result.returncode:
        raise DeploymentError(f'Git {arguments[0]} failed: {result.stderr.strip() or result.stdout.strip()}')
    return result


def remote_tip(directory):
    lines = git(directory, 'ls-remote', '--heads', 'origin', BRANCH).stdout.splitlines()
    if not lines:
        return None
    require(len(lines) == 1 and re.fullmatch(r'[0-9a-f]{40,64}\s+refs/heads/gh-pages', lines[0]),
            'Malformed or ambiguous remote gh-pages reference')
    return lines[0].split()[0]


@dataclass
class PreparedDeployment:
    directory: Path
    parent: str | None
    commit: str
    tree: str
    changed: bool
    files: dict[str, bytes]

    def finish(self, publish=False):
        require(remote_tip(self.directory) == self.parent, 'gh-pages changed during preparation; rerun')
        if self.changed:
            git(self.directory, 'push', '--porcelain', *([] if publish else ['--dry-run']),
                'origin', f'HEAD:{BRANCH}')
        return {'action': 'unchanged' if not self.changed else 'published' if publish else 'dry-run',
                'branch': BRANCH, 'parent': self.parent, 'commit': self.commit, 'tree': self.tree,
                'files': len(self.files), 'bytes': sum(map(len, self.files.values())),
                'package_sha256': sha(self.files['SHA256SUMS']), 'firmware_install_available': object_json(self.files['firmware/pluggbox-release.json'], 'release')['install_available']}


@contextmanager
def prepare_deployment(files, remote=DESTINATION):
    """Internal remote argument permits isolated local-bare-repository tests."""
    validate_snapshot(files)
    with tempfile.TemporaryDirectory(prefix='pluggbox-pages-') as temporary:
        directory = Path(temporary)
        git(directory, 'init', '--quiet', '--template=', '--initial-branch=gh-pages')
        git(directory, 'remote', 'add', 'origin', remote)
        git(directory, 'config', 'user.name', AUTHOR[0])
        git(directory, 'config', 'user.email', AUTHOR[1])
        parent = remote_tip(directory)
        if parent:
            git(directory, 'fetch', '--quiet', '--no-tags', 'origin', BRANCH)
            require(git(directory, 'rev-parse', 'FETCH_HEAD').stdout.strip() == parent, 'gh-pages changed while fetching')
            existing = set(git(directory, 'ls-tree', '-r', '--name-only', parent).stdout.splitlines())
            require(existing <= EXPECTED_FILES | set(DEVICE_MODULES) | {'firmware/' + n for n in device.FILES}, 'Existing gh-pages has unrelated files; review before replacing it')
        for name, data in files.items():
            path = directory / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
            path.chmod(0o644)
        git(directory, 'add', '--', *sorted(files))
        tree = git(directory, 'write-tree').stdout.strip()
        changed = not parent or git(directory, 'rev-parse', parent + '^{tree}').stdout.strip() != tree
        if changed:
            message = ('Publish Pluggbox guided page and browser audition\n\n'
                       f'Package SHA256: {sha(files["SHA256SUMS"])}\n'
                       'FM-1 installation unavailable; device identification only.\n')
            commit = git(directory, '-c', 'commit.gpgsign=false', 'commit-tree', tree,
                         *(['-p', parent] if parent else []), input_text=message).stdout.strip()
        else:
            commit = parent
        git(directory, 'update-ref', BRANCH, commit)
        yield PreparedDeployment(directory, parent, commit, tree, bool(changed), files)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--publish', action='store_true', help='push the verified page (default: Git push dry-run)')
    args = parser.parse_args()
    try:
        files = validate_site()
        with prepare_deployment(files) as prepared:
            result = prepared.finish(args.publish)
        result['destination'] = DESTINATION
        result['pages_activation'] = 'not checked; branch publication does not enable GitHub Pages'
        print(json.dumps(result, indent=2, sort_keys=True))
    except (DeploymentError, OSError, ValueError) as exc:
        parser.exit(1, f'Publication preparation stopped: {exc}\n')


if __name__ == '__main__':
    main()
