/* SPDX-License-Identifier: GPL-3.0-only */
/* Pluggbox GLASS palette. Shared fixed-point FM-1 engines; all recipes below
 * are new parameter designs. No factory-preset lookup and no new recordings.
 * Include after seq.c, as with Jambox's palette module. */
#include "pluggbox_drums.h"

typedef struct {
    const char *name;
    const engine_t *engine;
    int8_t e[8];
    uint8_t env[4];
    int8_t transpose, fenv, pitch_env, trim;
    uint8_t glide, chorus, delay, room, lrate, pitch_lfo;
} plugg_patch_t;

static const plugg_patch_t plugg_patches[NPART][2] = {
    { /* Bass: phase-stable single oscillator, decaying amplitude, legato. */
        {"CLEAN SLIDE", &ENG_ANALOG, {3,0,0,0,124,0,20,0}, {0,108,0,28}, -24,0,8,-8, 61,0,0,0, 30,0},
        {"BLOWN 808", &ENG_ANALOG, {3,0,0,0,104,7,83,0}, {0,99,0,22}, -24,0,15,-15, 53,0,0,0, 30,0},
    },
    { /* Two FM stacks: a soft body and a bright, decaying tine. */
        {"GLASS EP", &ENG_DIGITAL, {4,1,1,9,39,44,3,0}, {1,86,27,49}, 0,0,0,-18, 0,32,17,34, 35,0},
        {"CLOUD BELL", &ENG_DIGITAL, {4,2,1,5,48,65,0,0}, {2,91,12,60}, 0,0,0,-20, 0,40,22,43, 28,0},
    },
    {
        {"STAR PLUCK", &ENG_DIGITAL, {4,3,1,6,46,25,2,0}, {0,78,0,39}, 12,0,0,-10, 0,12,30,32, 40,0},
        {"RUBBER LEAD", &ENG_ANALOG, {4,5,35,0,82,18,12,48}, {3,65,94,26}, 0,14,0,-14, 51,13,22,25, 84,1},
    },
};
static uint8_t plugg_sound_id[NTRK];
static uint8_t plugg_sound_valid;
static const char *const plugg_kit_names[2] = {"PLUGG KIT", "HARD KIT"};

uint32_t jam_role_track(uint32_t role)
{
    static const uint8_t map[NTRK] = {TRK_DRUM, 0, 1, 2};
    return map[role % NTRK];
}
const char *jam_role_name(uint32_t track)
{
    static const char *const names[NTRK] = {"BASS", "CHORDS", "LEAD", "DRUMS"};
    return track < NTRK ? names[track] : "";
}
uint32_t jam_sound_count(uint32_t track) { return track < NTRK ? 2u : 0u; }
uint32_t jam_sound_index(uint32_t track) { return track < NTRK ? plugg_sound_id[track] : 0u; }
int jam_sound_is_curated(uint32_t track)
{
    if (track>=NTRK || !(plugg_sound_valid & (1u<<track))) return 0;
    if (track==TRK_DRUM) return trk[track].p[P_E0]==(int16_t)(DRUM_SYN+plugg_sound_id[track]);
    return trk[track].eng_req<NENGINES &&
        ENGINES[trk[track].eng_req]==plugg_patches[track][plugg_sound_id[track]].engine;
}
const char *jam_sound_name(uint32_t track)
{
    if (track >= NTRK) return "";
    if (!jam_sound_is_curated(track)) return track==TRK_DRUM
        ? DRUM_KIT_NAMES[(uint32_t)clamp(trk[track].p[P_E0],0,DRUM_KITS-1)]
        : ENGINES[trk[track].eng_req%NENGINES]->name;
    return track == TRK_DRUM ? plugg_kit_names[plugg_sound_id[track]] : plugg_patches[track][plugg_sound_id[track]].name;
}
/* Generic device preset/engine browsing must not keep a false curated label. */
void jam_sound_invalidate(uint32_t track)
{
    if (track<NTRK) plugg_sound_valid &= (uint8_t)~(1u<<track);
}

static void plugg_param(track_t *t, uint32_t id, int32_t value)
{
    t->p[id] = (int16_t)value;
    for (uint32_t i=0; i<t->lk_n; i++) if (t->lk_param[i] == id) t->lk_base[i] = t->p[id];
}
static int plugg_keeps(uint32_t id)
{
    return id == P_LEVEL || id == P_PAN || id == P_MUTE ||
        (id >= P_SLEN && id <= P_SGATE) || (id >= P_ROOT && id <= P_QUANT) ||
        id == P_CHORD || id == P_TFLT || id == P_STRUM || id == P_VLEAD;
}
static uint32_t plugg_engine_id(const engine_t *engine)
{
    for (uint32_t i=0; i<NENGINES; i++) if (ENGINES[i] == engine) return i;
    return 0;
}
static void plugg_sound_write(uint32_t track, uint32_t sound)
{
    track_t *t = &trk[track];
    locks_restore(t);
    plugg_sound_id[track] = (uint8_t)sound;
    if (track == TRK_DRUM) {
        /* Immutable recipes copied once to otherwise existing SYN banks. */
        t->p[P_E0] = (int16_t)(DRUM_SYN + sound);
    } else {
        const plugg_patch_t *p = &plugg_patches[track][sound];
        /* Consume old note ownership now. A deferred panic would erase a new
         * key arriving later in this same browser command batch. Keep the
         * inherited crossfade to render old voices with their old recipe. */
        jam_record_finish(t);
        seq_out_track_off(t);
        memset(jam_record_hold[track],0,sizeof jam_record_hold[track]);
        memset(jam_sequence_note[track],0,sizeof jam_sequence_note[track]);
        memset(jam_live_count[track],0,sizeof jam_live_count[track]);
        key_track_forget(track);
        sound_change(t);
        strum_cancel(t,0,1);
        t->nmono=0; t->mono_note=0; t->xp_n=0;
        t->nheld=t->arp_phys=t->arp_note=0;
        memset(sus_wait[track],0,sizeof sus_wait[track]);
        sus_on[track]=0;
        panic_req &= (uint8_t)~(1u<<track);
        t->eng_req = (uint8_t)plugg_engine_id(p->engine);
        t->preset = t->user = 0;
        for (uint32_t i=0; i<P_E0; i++) if (!plugg_keeps(i)) t->p[i] = TP[i].def;
        for (uint32_t i=0; i<8u; i++) t->p[P_E0+i] = p->e[i];
        for (uint32_t i=0; i<4u; i++) t->p[P_ATK+i] = p->env[i];
        t->p[P_TRANS]=p->transpose; t->p[P_ED_FLT]=p->fenv;
        t->p[P_ED_PIT]=p->pitch_env; t->p[P_ED_FX]=p->trim;
        t->p[P_GLIDE]=p->glide; t->p[P_GLMODE]=1;
        t->p[P_CHOR]=p->chorus; t->p[P_DLY]=p->delay; t->p[P_REV]=p->room;
        t->p[P_LRATE]=p->lrate; t->p[P_LD_PIT]=p->pitch_lfo; t->p[P_LTRIG]=1;
        t->p[P_VOICE]=(track==1u || t->p[P_CHORD]) ? V_POLY : V_LEGATO;
        t->p[P_AMODE]=0;
        fm6_track_loaded(t);
    }
    plugg_sound_valid |= (uint8_t)(1u<<track);
}
int jam_sound_load(uint32_t track, uint32_t sound)
{
    if (track>=NTRK || sound>=2u) return 0;
    fm1_irq_off();
    plugg_sound_write(track,sound);
    fm1_irq_on();
    return 1;
}

const char *jam_macro_name(uint32_t track, uint32_t macro)
{
    static const char *const names[NTRK][4] = {
        {"GLIDE","BODY","GRIT","TAIL"}, {"BRIGHT","SHIMMER","CHORUS","SPACE"},
        {"BRIGHT","MOVE","ECHO","SPACE"}, {"TONE","LEVEL","ECHO","ROOM"}
    };
    return track<NTRK && macro<4u ? names[track][macro] : "";
}
int jam_macro_supported(uint32_t track)
{
    if (track==TRK_DRUM) return 1;
    if (track>=NPART || trk[track].eng_req>=NENGINES) return 0;
    const engine_t *e=ENGINES[trk[track].eng_req];
    return track==0u ? e==&ENG_ANALOG : track==1u ? e==&ENG_DIGITAL : e==&ENG_ANALOG || e==&ENG_DIGITAL;
}
uint32_t jam_macro_step(uint32_t track, uint32_t macro)
{
    if (macro>=4u || !jam_macro_supported(track)) return 0;
    /* SHIMMER has four real pitch-depth settings; a 5% detent rounds to zero. */
    return track==1u && macro==1u ? 34u : 5u;
}
/* A macro maps to actual engine parameters and useful role-specific ranges. */
static uint32_t plugg_macro_param(uint32_t track, uint32_t macro, int32_t *lo, int32_t *hi)
{
    *lo=0; *hi=100;
    if (track==0u) {
        static const uint8_t ids[4]={P_GLIDE,P_E6,P_DIST,P_DEC};
        if (macro==2u) *hi=48;
        if (macro==3u) { *lo=65; *hi=120; }
        return ids[macro];
    }
    if (track==1u) {
        static const uint8_t ids[4]={P_E4,P_LD_PIT,P_CHOR,P_REV};
        static const uint8_t lows[4]={12,0,0,0}, highs[4]={90,3,65,64};
        *lo=lows[macro]; *hi=highs[macro]; return ids[macro];
    }
    if (macro==0u) { *lo=20; *hi=112; return P_E4; }
    if (macro==1u) { *hi=24; return trk[track].eng_req==plugg_engine_id(&ENG_ANALOG) ? P_LD_SHP : P_LD_FLT; }
    *hi=macro==2u ? 52 : 62; return macro==2u ? P_DLY : P_REV;
}
void jam_macro_set(uint32_t track, uint32_t macro, int32_t percent)
{
    if (track>=NTRK || macro>=4u || !jam_macro_supported(track)) return;
    percent=clamp(percent,0,100);
    fm1_irq_off();
    if (track==TRK_DRUM) {
        if (macro==0u) plugg_param(&trk[track],P_TFLT,-32+(percent*32+50)/100);
        else { static const uint8_t ids[4]={0,G_DRLVL,G_DRDLY,G_DRREV};
            song.g[ids[macro]]=(int16_t)((percent*(macro==1u ? 110 : 24)+50)/100); }
    } else {
        int32_t lo,hi; uint32_t id=plugg_macro_param(track,macro,&lo,&hi);
        plugg_param(&trk[track],id,lo+(percent*(hi-lo)+50)/100);
        if (track==1u && macro==3u) plugg_param(&trk[track],P_DLY,(percent*30+50)/100);
    }
    fm1_irq_on();
}
uint32_t jam_macro_get(uint32_t track, uint32_t macro)
{
    if (track>=NTRK || macro>=4u || !jam_macro_supported(track)) return 0;
    int32_t lo=0, hi, value;
    if (track==TRK_DRUM) {
        if (macro==0u) { lo=-32; hi=0; value=trk[track].p[P_TFLT]; }
        else { static const uint8_t ids[4]={0,G_DRLVL,G_DRDLY,G_DRREV};
            hi=macro==1u ? 110 : 24; value=song.g[ids[macro]]; }
    } else { uint32_t id=plugg_macro_param(track,macro,&lo,&hi); value=trk[track].p[id]; }
    return (uint32_t)clamp(((value-lo)*100+(hi-lo)/2)/(hi-lo),0,100);
}

/* Release the inherited keyboard/roll/MIDI ownership before replacing a jam. */
static void plugg_inputs_reset(void)
{
    for (uint32_t k=0; k<NELEM(kb_kind); k++) {
        if (kb_kind[k]==KS_NOTE || kb_kind[k]==KS_DRUM || kb_kind[k]==KS_ROLL || kb_kind[k]==KS_FX) key_up(k);
        kb_kind[k]=KS_NONE; kb_n[k]=0;
    }
    for (uint32_t k=0; k<NROLL; k++) roll_end(k);
    kb_prev=fm1_in.notes; ly_lock=LY_PLAY; kb_grid=0;
    lk_r=lk_w; mi_r=mi_w; step_in_r=step_in_w; step_in_lost=0;
    memset((void *)pc_req,0,sizeof pc_req); memset(mi_pen,0,sizeof mi_pen);
    memset(midi_sel_on,0,sizeof midi_sel_on); memset(ch_sus,0,sizeof ch_sus);
    memset(ch_bend,0,sizeof ch_bend); memset(sus_on,0,sizeof sus_on); memset(sus_wait,0,sizeof sus_wait);
    memset(vl_n,0,sizeof vl_n); memset(er_notes,0,sizeof er_notes);
    drum_mute=er_lanes=er_mute=er_flash=0; aud_lanes=aud_lvl=dsu_aud_vel=0;
    punch.req=-1; punch.hold=0; punch.keybit=0;
    last_note=pen_note[0]=60; pen_n=1; pen_lane=0;
    for (uint32_t k=0; k<NTRK; k++) { trk[k].nheld=trk[k].arp_phys=trk[k].arp_note=0; trk[k].bend=0; }
}

int plugg_new_glass(void)
{
    if (song.playing || transport_req==1u || transport_req==3u || ft_on || ci_on) return 0;
    fm1_irq_off();
    seq_stop(); plugg_inputs_reset(); transport_req=0; rec_wait=0;
    song.rec=song.solo=song.seq_mode=0; song.octave=0;
    for (uint32_t i=G_BPM; i<=G_CDEPTH; i++) song.g[i]=GP[i].def;
    for (uint32_t i=G_DUST; i<=G_ROLL; i++) song.g[i]=GP[i].def;
    for (uint32_t i=G_TXSRC; i<=G_TXDUCK; i++) song.g[i]=GP[i].def;
#if FELUCCA_ARRANGER
    arrangement_enabled=0;
#endif
    dsu_defaults();
    for (uint32_t k=0; k<2u; k++) {
        memcpy(dsu.k[k].s,plugg_drum_recipes[k],sizeof dsu.k[k].s);
        memset(dsu.k[k].name,0,sizeof dsu.k[k].name);
        memcpy(dsu.k[k].name,k ? "HARD" : "PLUGG",k ? 4u : 5u);
        dsu.k[k].crush=0;
    }
    static const uint8_t levels[NPART]={95,84,88};
    for (uint32_t k=0; k<NTRK; k++) {
        track_t *t=&trk[k]; trk_all_off(t);
        for (uint32_t i=0; i<P_COUNT; i++) t->p[i]=TP[i].def;
        steps_clear(t); memset(t->micro,0,sizeof t->micro);
        t->p[P_SLEN]=32; t->p[P_SDIV]=2; t->p[P_ROOT]=6; t->p[P_SCALE]=2;
        if (k==1u) t->p[P_CHORD]=2;
        if (k<NPART) { t->p[P_QUANT]=1; t->p[P_LEVEL]=levels[k]; }
        plugg_sound_write(k,0);
    }
    song.g[G_BPM]=144; song.g[G_SWING]=0; song.g[G_CLOCK]=1;
    song.g[G_DTIME]=1; song.g[G_DFDBK]=30; song.g[G_DCOLOR]=68; song.g[G_DMIX]=68;
    song.g[G_RSIZE]=66; song.g[G_RDAMP]=74; song.g[G_CRATE]=25; song.g[G_CDEPTH]=32;
    song.g[G_DRLVL]=90; song.g[G_DRREV]=4; song.g[G_DRDLY]=0;
    song.g[G_DUST]=song.g[G_DUCK]=song.g[G_FILT]=song.g[G_TXSRC]=0;
    static const uint8_t kicks[]={0,6,11,16,23,26};
    for (uint32_t i=0; i<NELEM(kicks); i++) dstep_set(&TDRUM->dstep[kicks[i]],0,LV_NORM,0);
    /* Half-time clap, rim answers, thin alternating hats, brief triplet roll. */
    dstep_set(&TDRUM->dstep[8],3,LV_NORM,0); dstep_set(&TDRUM->dstep[24],3,LV_NORM,0);
    for (uint32_t i=0; i<32u; i+=2u) dstep_set(&TDRUM->dstep[i],4,(i&2u) ? LV_GHOST : LV_SOFT,0);
    dstep_set(&TDRUM->dstep[14],4,LV_SOFT,2); dstep_set(&TDRUM->dstep[30],4,LV_GHOST,3);
    dstep_set(&TDRUM->dstep[19],7,LV_SOFT,0); dstep_set(&TDRUM->dstep[29],7,LV_GHOST,0);
    dstep_set(&TDRUM->dstep[6],5,LV_SOFT,0); dstep_set(&TDRUM->dstep[22],5,LV_GHOST,0);
    song.sel=1; panic_req=0; /* old notes were synchronously released above */
    fm1_irq_on(); return 1;
}

/* The inherited hardware NEW/startup command uses this entry point. */
int jam_new_dusty(void) { return plugg_new_glass(); }
