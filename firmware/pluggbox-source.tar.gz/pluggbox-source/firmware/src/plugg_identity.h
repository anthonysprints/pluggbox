/* SPDX-License-Identifier: GPL-3.0-only */
/* Isolated Pluggbox profile. 701 is project-local, not a registered allocation.
 * Existing JAMBOX_* wire/API names are retained internally; all externally
 * reported family, version and transport identities are Pluggbox-specific.
 * Session persistence/recovery is deliberately disabled for this prototype. */
#ifndef PLUGG_IDENTITY_H
#define PLUGG_IDENTITY_H
#define JAMBOX_NAME "Pluggbox"
#define JAMBOX_FAMILY "PLUGGBOX"
#define JAMBOX_RELEASE "0.1.0-proto"
#define JAMBOX_APP_ID "FM-1_701"
#define JAMBOX_RESCUE_ID "FM-1_000"
#define JAMBOX_LOADER_ID "ota-FM-1_701"
#endif
