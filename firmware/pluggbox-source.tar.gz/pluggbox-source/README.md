# Pluggbox

A hands-on pluggnb, rage and underground-rap instrument for exploring sounds
and building loops. This first milestone is **GLASS**, a browser audition of
original presets using the same fixed-point C sound engines as Jambox/FM-1.

## Play the first palette

```sh
cd /workspace/pluggbox
bash tools/cloud/setup_pluggbox.sh
. tools/cloud/activate_pluggbox.sh
sh tests/run_pluggbox_tests.sh
python3 tools/package_pluggbox.py --no-build
python3 -m http.server 8766 --bind 127.0.0.1 --directory build/pluggbox
```

Use an HTTP static server to open the packaged website; opening index.html as
a local file does not support the AudioWorklet. The cloud onboarding interface
does not expose a public browser preview. Packaging creates
`build/pluggbox-audition.zip`, with the website, license and corresponding source.
No website is published by these commands.

Packaging also renders two full-jam WAVs and eight individual-sound auditions
to `build/pluggbox-audio/`, directly through the compiled browser engine. The
ZIP includes both complete takes. Rerender audio alone with
`node tools/render_pluggbox_audio.mjs`.

## Guided page and FM-1 installer preparation

The landing page includes browser play, audio examples, and an experimental USB installer for an FM-1 running the supported Jambox build. The real firmware build and simulated transfer checks pass. Physical hardware validation is pending; sessions are temporary and saving is disabled.

```sh
python3 tools/package_pluggbox_site.py --no-build --with-device
node tests/pluggbox_install_device_browser.mjs
```

Output: `build/pluggbox-site/` and `build/pluggbox-site.zip`. See [build prerequisites and installer status](docs/PLUGGBOX_INSTALLER.md).

`python3 tools/publish_pluggbox_site.py` validates the site and dry-runs a push
to this project's `gh-pages` branch. It does not publish or enable GitHub Pages.
An explicit `--publish` is a separate external action. Never use the inherited
Jambox publisher for this site.

Choose **Start audio**, then **Hear starter jam** for the complete two-bar
example at 144 BPM in F-sharp minor. **Back to my jam** restores your recorded
melodies and stops playback. Record automatically leaves the starter jam first.
Use **Play beat** for drums while making your own parts. Computer keys and
touch pads play the selected part. All four roles have two sound choices,
four sound controls, mute and recording. Reloading loses the temporary session.
**Reset palette** clears the session and restores GLASS.

| Part | First sound | Alternative |
| --- | --- | --- |
| Bass | CLEAN SLIDE: smooth sine-based 808 | BLOWN 808: shorter, more driven |
| Chords | GLASS EP: soft FM body with a glassy tine | CLOUD BELL: more ringing, spacious FM |
| Lead | STAR PLUCK: high FM pluck and echoes | RUBBER LEAD: hollow pulse and glide |
| Drums | PLUGG KIT: short kick, dry clap, thin hats | HARD KIT: more attack, drive and snare body |

These are original parameter recipes and drum synthesis, rather than renamed
factory patches. No new recordings are bundled. The deeper inherited engines
and recordings are retained for this prototype; storage reduction is pending.
See [sound design notes](docs/PLUGGBOX_PALETTE.md).

## Development scope

Pluggbox-specific work lives in:

- `firmware/src/plugg_palette.c`: shared sound definitions, macros and beat.
- `tools/gen_pluggbox_drums.py`: original drum recipes in Hz, ms and dB.
- `firmware/host/plugg_preview.c`: browser entry point and reversible demo.
- `web/plugg/`: the browser controls and AudioWorklet.
- `tests/pluggbox_*`: native, WASM and actual Chromium checks.

The browser and native builds use production C synthesis, effects, sequencing and recording. The real target build also passes its memory gates. Hardware audio timing and installation still need an owner trial. Inherited Jambox publication tools target Jambox; use only the Pluggbox packager and publisher here.

## Foundation and license

Derived from [anthonysprints/jamboxfm](https://github.com/anthonysprints/jamboxfm)
at the exact commit in [UPSTREAM.json](UPSTREAM.json), itself based on Sloop /
Felucca. Copyright notices and source licenses are retained. Code is
GPL-3.0-only, with component/asset notices in [LICENSING.md](LICENSING.md).
The inherited docs record Jambox's history and validation; they do not describe
Pluggbox releases. Use this README for the current prototype workflow.
