# First GLASS browser audition — validation

Executed in the current cloud machine on October 20, 2026. This is Pluggbox
evidence; historical Jambox reports elsewhere in docs are separate.

## Executed checks

From `/workspace/pluggbox`, after activating the pinned browser toolchain:

```sh
sh tests/run_pluggbox_tests.sh
node tools/render_pluggbox_audio.mjs
```

| Check | Result |
| --- | --- |
| Native production C adapter | 146 checks passed |
| Actual WASM contracts | 70 groups passed |
| Native versus WASM output | All eight sound choices matched exactly, maximum sample difference 0 |
| Real Chromium / AudioWorklet | 13 cases passed; no browser/worklet exceptions |
| Audio auditions | Two complete takes and eight isolated sounds rendered; zero clipped output samples |
| Local HTTP startup | Index returned Pluggbox, module returned WASM magic; both HTTP 200 |

The audio tests check actual nonzero output after immediate sound-change/key
commands, distinct alternatives, bounded macro endpoints, recorder and note
release, smooth overlapping 808 glide, reversible demo playback and reset.
Demo entry while recording or armed finishes/cancels capture; exiting restores
the user's patterns and independent durations. Browser tests exercise actual
keyboard, pointer, touch, recording, browsing, macros, mute, tempo/swing,
clap/open-hat/rim grid, focus loss, audio pause/resume and mobile layout.

Runtime-tested WASM SHA-256:

```text
cec9c5367944b31814817f089a1bdaf6f9e8765186d7b480a9e68d3ec0fa9a92
```

Auditions use the compiled module at the browser's output gain, 0.6. The
16.33-second starter mix has peak 0.2751 / RMS 0.0669; the harder alternative
has peak 0.2224 / RMS 0.0422. These measurements establish signal and headroom,
not perceived loudness matching or subjective musical quality. Metrics bind
their module and renderer hashes.

Current-run logs, browser results and screenshots are under
`build/pluggbox-evidence/`. Listening WAVs and metrics are under
`build/pluggbox-audio/`. Generated evidence stays ignored.

## Environment and limits

Pinned Emscripten 3.1.69 and Clang 19.1.7 are verified/extracted by the setup
script. Playwright Core 1.58.2 uses the machine's Chromium 154. No new secrets,
system packages or device SDK were required for this browser workflow.

The reusable install script and startup instructions were saved to the cloud
configuration draft. Saving that draft does not publish a snapshot or website.
At the initial browser milestone, all 771 inherited files checked against the
pinned Jambox checkout remained byte-for-byte unchanged. The later installer
preparation adds conditional device integration; see PLUGGBOX_INSTALLER.md.

No Pluggbox device firmware was built, flashed or published. Device entry-point
integration, measured flash/RAM fit, save-family compatibility and physical
listening/timing remain separate next steps after audition feedback.
