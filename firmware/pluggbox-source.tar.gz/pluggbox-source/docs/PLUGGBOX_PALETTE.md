# GLASS — first Pluggbox audition

The starting direction is melodic pluggnb, with a harder alternate for every
role and room to move toward rage / experimental underground later. References
from the owner: Prettifun, Che, Osamason, Ken Carson and Lucy Bedroque. The first
bank explores textures and playing behavior; it is not an exact reproduction
of a commercial patch, recording or artist.

## Sound construction

All six melodic patches are original settings in `plugg_patches` in
`firmware/src/plugg_palette.c`. Loading them writes their engine parameters,
envelopes, modulation and effects directly; it never resolves a factory preset
by name. Choosing another sound preserves recorded notes, key/scale, one-key
chords, timing, mix and mute. Choosing the same sound reloads its starting recipe.

| Sound | Construction | What to listen for |
| --- | --- | --- |
| CLEAN SLIDE | One sine oscillator, gentle pitch drop, decaying amplitude, moderate drive, legato glide | Stable low body, smooth overlaps, restrained transient |
| BLOWN 808 | More oscillator drive, a stronger pitch drop and shorter decay | Bass audible above the sub range without swallowing the keys |
| GLASS EP | Four-operator FM, two stacks with a higher-ratio tine, moderate index, quiet sustain, chorus | Clear upper attack over a soft body; open sevenths remain readable |
| CLOUD BELL | Different FM ratios, slower modulation decay, less sustain, longer release and sends | Ringing, spacious chords with a different articulation from GLASS EP |
| STAR PLUCK | High-register FM, quick modulation decay, short amplitude envelope, delay and room | Small bright notes that sit above the chords rather than compete with them |
| RUBBER LEAD | Pulse oscillator plus lightly detuned second oscillator, filter envelope, glide and tiny vibrato | A hollow, elastic melody with connected note changes |

The bass uses oscillator drive for BODY; track distortion (GRIT) has different
color and includes the inherited low-frequency filtering. Keep that distinction
audible and leave GRIT at zero by default to preserve low-end weight.

| Role | Controls |
| --- | --- |
| Bass | GLIDE: pitch travel time; BODY: oscillator drive; GRIT: track distortion; TAIL: amplitude decay |
| Chords | BRIGHT: FM index; SHIMMER: subtle pitch modulation; CHORUS: send amount; SPACE: room plus echo |
| Lead | BRIGHT: FM index or analog cutoff; MOVE: engine timbre modulation; ECHO: delay send; SPACE: room send |
| Drums | TONE: kit filter; LEVEL: kit level; ECHO and ROOM: sends |

## Original drums and groove

`tools/gen_pluggbox_drums.py` holds sixteen musical-unit recipes for each kit.
It reuses the existing table encoder and DSP. PLUGG KIT pairs a short sine kick,
dry burst-noise clap, short metallic hats and rim accents. HARD KIT changes the
kick, snare, clap and hats for more attack and drive. Neither kit loads a factory
kit or adds a sample recording. Existing SYN RAM banks hold the immutable starting
recipes for playback; the prototype does not save them to physical flash.

The default beat is two bars at 144 BPM, straight timing with a half-time clap,
syncopated kick, quiet alternating hats, short triplet/four-hit rolls, open hats
and rim answers. The browser grid exposes kick, clap, hat, open hat and rim.
The complete optional example adds F# minor 7 -> D major 7, low 808 notes and a
sparse upper melody. Its pattern uses the existing per-note duration sequencer.

## Evaluation and next milestone

First compare each sound alone, then all four parts together. Listen for useful
glide timing, excessive bass distortion, harsh high notes, repetitive hat color,
chord clarity and tails masking the next phrase. Check macro extremes as well
as defaults. Runtime tests establish that audio is produced and the editing
workflow works; hardware listening remains separate.

This prototype retains the complete inherited engine/sample library. The last
Jambox device report had only 1,912 bytes of application flash spare; that is
historical Jambox evidence, not a Pluggbox target measurement. Before a device
build, integrate the palette into the device entry point, measure it with the
pinned target compiler, consider removing unused recorded instruments, and
assign a separate Pluggbox save identity. Do not bypass Jambox's compatibility
guards or silently reinterpret its saved sessions.
