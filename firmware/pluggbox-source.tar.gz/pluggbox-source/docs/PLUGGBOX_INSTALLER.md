# Pluggbox experimental installer

The real pi32v2 firmware build and software checks now pass. The official compiler download works with the configured vendor domains. Physical FM-1 validation is still pending; this is an experimental owner trial.

The page verifies the firmware download, checks a single supported Jambox FM-1, requires acknowledgement, then transfers and confirms the Pluggbox identity. It rejects foreign firmware and ambiguous MIDI devices. It does not retry interrupted writes automatically.

Pluggbox 0.1.0-proto uses PLUGGBOX / FM-1_701 and ota-FM-1_701. Sessions are temporary, saving is disabled, and this replaces Jambox. Keep music and recovery backups before trying it. No save migration or return installer is included.

## Build and package

```sh
bash tools/cloud/setup_pluggbox.sh
bash tools/cloud/setup_pluggbox_device.sh
. tools/cloud/activate_pluggbox.sh
python3 tools/build_pluggbox.py
python3 tools/build_pluggbox_device.py
python3 tools/package_pluggbox_site.py --no-build --with-device
```

Output: build/pluggbox-site/ and build/pluggbox-site.zip. Serve the complete directory over HTTPS; use desktop Chrome or Edge for Web MIDI. The default without --with-device still produces the unavailable-installation page.

## Verification

The real application fits with 18,636 bytes of flash remaining. Device build receipts bind source, compiler, SDK, configuration, firmware and memory results. Native updater staging/isolation and bounded-loader fault checks passed with the actual firmware bytes. All 17 simulated transfer checks passed, including full byte transfer, wrong identities, reconnect ambiguity, cancellation and partial transfers. These simulations do not establish physical flash or audio timing.

```sh
bash tests/run_pluggbox_device_safety.sh
node --test tests/pluggbox_install_transfer_test.mjs
node tests/pluggbox_install_device_browser.mjs
python3 -m unittest discover -s tests -p 'test_*pluggbox*.py'
python3 tools/publish_pluggbox_site.py
```

The publisher defaults to validation and a Git push dry-run. --publish pushes this project’s gh-pages branch; GitHub Pages must also be configured to serve it. No live site is claimed until its HTTPS URL has been checked.
