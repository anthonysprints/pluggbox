// SPDX-License-Identifier: GPL-3.0-only
// A real Chromium AudioWorklet + WASM workflow. Tests open no user-facing preview.
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { resolve, extname, sep } from 'node:path';
import { pathToFileURL } from 'node:url';

const playwright = process.env.PLAYWRIGHT_MODULE ? pathToFileURL(resolve(process.env.PLAYWRIGHT_MODULE)).href : 'playwright-core';
const { chromium } = await import(playwright);
const root = resolve('build/pluggbox'), evidence = resolve('build/pluggbox-evidence');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.wasm': 'application/wasm' };
const server = createServer(async (request, response) => {
  try {
    const pathname = new URL(request.url, 'http://localhost').pathname;
    const path = resolve(root, '.' + (pathname === '/' ? '/index.html' : pathname));
    if (!path.startsWith(root + sep)) throw new Error('Outside packaged site');
    const data = await readFile(path);
    response.writeHead(200, { 'Content-Type': mime[extname(path)] || 'application/octet-stream' }); response.end(data);
  } catch { if (!response.headersSent) response.writeHead(404); response.end('Not found'); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const address = `http://127.0.0.1:${server.address().port}`;
let browser;
const passed = [], errors = [], testedAt = new Date().toISOString();
await mkdir(evidence, { recursive: true });
await writeFile(resolve(evidence, 'browser-results.json'), JSON.stringify({ testedAt, status: 'running', passed: [] }, null, 2) + '\n');
function done(name) { passed.push(name); }
async function settled(page) {
  await page.waitForFunction(() => !globalThis.testJam.inFlight && !globalThis.testJam.pending.length);
}
try {
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', headless: true,
    args: ['--no-sandbox', '--autoplay-policy=document-user-activation-required'] });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1100 } });
  page.on('pageerror', error => errors.push(error.message));
  await page.route('**/*', route => route.request().url().startsWith(address) ? route.continue() : route.abort());
  await page.goto(address); await page.waitForSelector('.pad');
  await page.evaluate(async () => { globalThis.testJam = (await import('./app.js')).session; });
  assert.match(await page.title(), /pluggbox/i);
  assert.equal(await page.locator('#pads .pad').count(), 16);
  assert.equal(await page.locator('#play').isDisabled(), true);
  assert.equal(await page.evaluate(() => globalThis.testJam.context), null);
  done('explicit audio activation; local assets; 16 performance pads');

  await page.locator('#audio-start').click();
  await page.waitForFunction(() => !document.getElementById('play').disabled && globalThis.testJam.state?.tempo === 144);
  assert.equal(await page.evaluate(() => globalThis.testJam.context.sampleRate), 44100);
  assert.equal(await page.evaluate(() => globalThis.testJam.state.tracks.find(track => track.track === 1).sound), 'GLASS EP');
  assert.equal(await page.evaluate(() => globalThis.testJam.state.tracks.filter(track => track.track < 3).every(track => track.events === 0)), true);
  done('44.1-kHz production WASM initializes the F# minor Glass palette');

  await page.locator('#demo').click();
  await page.waitForFunction(() => globalThis.testJam.state.demo && globalThis.testJam.state.tracks.filter(track => track.track < 3).every(track => track.events > 0));
  await page.waitForFunction(() => document.getElementById('meter').value > 0.01);
  assert.equal(await page.locator('#demo').getAttribute('aria-pressed'), 'true');
  await page.locator('#demo').click();
  await page.waitForFunction(() => !globalThis.testJam.state.demo && !globalThis.testJam.state.playing);
  assert.equal(await page.evaluate(() => globalThis.testJam.state.tracks.filter(track => track.track < 3).every(track => track.events === 0)), true);
  done('starter jam plays all roles with audible output and restores the empty workspace');

  await page.locator('#record').click();
  await page.waitForFunction(() => globalThis.testJam.state.armed);
  await page.keyboard.down('g'); await page.waitForTimeout(350); await page.keyboard.up('g');
  await page.waitForTimeout(250);
  await page.keyboard.down('h'); await page.waitForTimeout(350); await page.keyboard.up('h');
  await page.locator('#record').click();
  await page.waitForFunction(() => !globalThis.testJam.state.recording && globalThis.testJam.state.tracks.find(track => track.track === 1).events >= 8);
  const chordEvents = await page.evaluate(() => globalThis.testJam.state.tracks.find(track => track.track === 1).events);
  done('computer keyboard records two seventh chords through the firmware recorder');

  await page.getByRole('button', { name: 'Next Chords sound', exact: true }).click();
  await page.waitForFunction(() => globalThis.testJam.state.tracks.find(track => track.track === 1).sound === 'CLOUD BELL');
  assert.equal(await page.evaluate(() => globalThis.testJam.state.tracks.find(track => track.track === 1).events), chordEvents);
  await page.getByRole('button', { name: 'Select Bass', exact: true }).click();
  await page.waitForFunction(() => globalThis.testJam.state.selected === 0);
  await page.locator('#record').click();
  await page.keyboard.down('g'); await page.waitForTimeout(350); await page.keyboard.up('g');
  await page.locator('#record').click();
  await page.waitForFunction(() => globalThis.testJam.state.tracks.find(track => track.track === 0).events > 0);
  assert.equal(await page.evaluate(() => globalThis.testJam.state.tracks.find(track => track.track === 1).events), chordEvents);
  done('sound browsing and bass overdub preserve recorded harmony');

  await page.locator('#demo').click();
  await page.waitForFunction(() => globalThis.testJam.state.demo);
  await page.locator('#demo').click();
  await page.waitForFunction(() => !globalThis.testJam.state.demo && !globalThis.testJam.state.playing);
  assert.equal(await page.evaluate(() => globalThis.testJam.state.tracks.find(track => track.track === 1).events), chordEvents);
  assert.equal(await page.evaluate(() => globalThis.testJam.state.tracks.find(track => track.track === 0).events > 0), true);
  done('audition preserves and restores a user-recorded jam');

  await page.getByRole('button', { name: 'Next Bass sound', exact: true }).click();
  await page.waitForFunction(() => globalThis.testJam.state.tracks.find(track => track.track === 0).sound === 'BLOWN 808');
  await page.locator('[data-knob="0"]').fill('85'); await page.locator('[data-knob="0"]').dispatchEvent('input');
  await page.waitForFunction(() => globalThis.testJam.state.tracks.find(track => track.track === 0).macros[0].value >= 83);
  await page.getByRole('button', { name: 'Mute Bass', exact: true }).click();
  await page.waitForFunction(() => globalThis.testJam.state.tracks.find(track => track.track === 0).muted);
  await page.getByRole('button', { name: 'Mute Bass', exact: true }).click();
  await page.locator('#tempo').fill('150'); await page.locator('#tempo').dispatchEvent('change');
  await page.locator('#swing').fill('18'); await page.locator('#swing').dispatchEvent('input');
  await page.waitForFunction(() => globalThis.testJam.state.tempo === 150 && globalThis.testJam.state.swing === 18);
  done('alternative bass, role-specific macro, mute, tempo and swing control actual state');

  assert.equal(await page.locator('.step').count(), 160, 'five editable drum rows match the active palette');
  assert.equal(await page.locator('.step[data-lane="3"]').count(), 32, 'clap row is visible');
  const step = page.locator('.step[data-lane="7"][data-step="0"]');
  const before = await step.getAttribute('aria-pressed'); await step.click();
  await page.waitForFunction(previous => document.querySelector('.step[data-lane="7"][data-step="0"]').getAttribute('aria-pressed') !== previous, before);
  done('drum grid edits preserve the remaining lane bits');

  // Rapid part changes must target the new part before its worklet acknowledgement.
  await page.evaluate(() => {
    document.querySelector('.part[data-track="1"] .part-select').click();
    const chord = document.getElementById('chord'); chord.value = '1'; chord.dispatchEvent(new Event('change'));
  });
  await page.waitForFunction(() => globalThis.testJam.state.tracks.find(track => track.track === 1).chord === 1);
  assert.equal(await page.evaluate(() => globalThis.testJam.state.tracks.find(track => track.track === 0).chord), 0);
  await settled(page);
  done('rapid part selection cannot send chord edits to bass');

  const pad = page.locator('.pad[data-key="7"]'), box = await pad.boundingBox();
  await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2); await page.mouse.down();
  await page.waitForFunction(() => document.querySelector('.pad[data-key="7"]').classList.contains('down'));
  await page.mouse.move(4, 4); await page.mouse.up();
  assert.equal(await page.locator('.pad.down').count(), 0);
  await page.keyboard.down('g');
  await page.evaluate(() => window.dispatchEvent(new Event('blur'))); await page.keyboard.up('g');
  await page.waitForFunction(() => !globalThis.testJam.state.playing);
  assert.equal(await page.locator('.pad.down').count(), 0);
  done('pointer capture and focus loss release notes without sticking');

  await page.locator('#reset').click();
  await page.waitForFunction(() => globalThis.testJam.state.tempo === 144 && !globalThis.testJam.state.playing && !globalThis.testJam.state.demo && globalThis.testJam.state.tracks.filter(track => track.track < 3).every(track => track.events === 0));
  assert.equal(await page.evaluate(() => globalThis.testJam.state.tracks.find(track => track.track === 1).sound), 'GLASS EP');
  assert.equal(await page.evaluate(() => globalThis.testJam.state.tracks.find(track => track.track === 1).chord), 2);
  done('explicit reset clears edits and restores the initial palette');

  await page.locator('#audio-start').click();
  await page.waitForFunction(() => globalThis.testJam.context.state === 'suspended');
  await page.locator('#audio-start').click();
  await page.waitForFunction(() => globalThis.testJam.context.state === 'running');
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), true);
  await mkdir(evidence, { recursive: true });
  await page.screenshot({ path: resolve(evidence, 'desktop.png'), fullPage: true });
  done('audio suspension/resume and desktop layout');

  const mobile = await browser.newPage({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  mobile.on('pageerror', error => errors.push(error.message));
  await mobile.goto(address);
  await mobile.evaluate(async () => { globalThis.testJam = (await import('./app.js')).session; });
  await mobile.locator('#audio-start').tap();
  await mobile.waitForFunction(() => globalThis.testJam.state?.tempo === 144);
  await mobile.getByRole('button', { name: 'Select Drums', exact: true }).tap();
  await mobile.waitForFunction(() => globalThis.testJam.state.selected === 3);
  await mobile.locator('.pad[data-key="0"]').tap();
  await mobile.locator('#play').tap();
  await mobile.waitForFunction(() => document.getElementById('meter').value > 0.01);
  assert.equal(await mobile.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), true);
  await mobile.locator('#panic').tap();
  await mobile.waitForFunction(() => !globalThis.testJam.state.playing);
  await mobile.screenshot({ path: resolve(evidence, 'mobile.png'), fullPage: true });
  done('mobile touch pads, transport, audible kit and viewport fit');
  assert.deepEqual(errors, [], 'no browser or AudioWorklet exceptions');
  await writeFile(resolve(evidence, 'browser-results.json'), JSON.stringify({ testedAt, status: 'passed', cases: passed.length, passed, errors }, null, 2) + '\n');
  console.log(`Pluggbox browser: ${passed.length} real Chromium cases passed; screenshots in build/pluggbox-evidence.`);
} catch (error) {
  await writeFile(resolve(evidence, 'browser-results.json'), JSON.stringify({ testedAt, status: 'failed', passed, errors, failure: error.message }, null, 2) + '\n');
  throw error;
} finally {
  await browser?.close();
  await new Promise(resolve => server.close(resolve));
}
