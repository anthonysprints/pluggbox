/* SPDX-License-Identifier: GPL-3.0-only */
/* Pluggbox's complete inherited device UI composed with its actual palette.
 * This is a native panel smoke, not a target flash/RAM/timing measurement. */
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include "../firmware/host/plugg_emu.c"

static unsigned checks;
#define CHECK(c) do { assert(c); checks++; } while (0)
static double audio(uint32_t n)
{
    double energy=0;
    while (n--) {
        const float *p=jam_emu_render();
        for (uint32_t i=0; i<CTL*2u; i++) {
            assert(isfinite(p[i]) && fabsf(p[i])<=1.0f);
            energy+=fabsf(p[i]);
        }
    }
    return energy;
}

int main(void)
{
    jam_emu_init();
    CHECK(!strcmp(JAMBOX_NAME,"Pluggbox") && !strcmp(JAMBOX_FAMILY,"PLUGGBOX"));
    CHECK(!strcmp(JAMBOX_APP_ID,"FM-1_701") && !strcmp(JAMBOX_LOADER_ID,"ota-FM-1_701"));
    CHECK(song.g[G_BPM]==144 && !song.playing && song.sel==1);
    CHECK(trk[1].p[P_ROOT]==6 && trk[1].p[P_SCALE]==2 && trk[1].p[P_CHORD]==2);
    CHECK(!strcmp(jam_emu_sound_name(),"GLASS EP"));
    CHECK(jam_sound_is_curated(1) && jam_macro_supported(1));
    CHECK(jam_emu_screen_version()>0 && emu_lcd_errors==0);
    ui.jam_home_view=JAM_HOME_SOUND; go_home(); jam_emu_frame();
    uint32_t before=jam_macro_get(1,1);
    jam_emu_encoder(EN_K2,1);
    CHECK(jam_macro_get(1,1)>before); /* 0..3 range must move on a real detent. */
    jam_emu_encoder(EN_PRESET,1); audio(400);
    CHECK(!strcmp(jam_emu_sound_name(),"CLOUD BELL") && jam_sound_index(1)==1);
    jam_emu_key(7,1);
    CHECK(kb_n[7]==4 && audio(1200)>1);
    jam_emu_key(7,0); audio(100);
    CHECK(kb_kind[7]==KS_NONE);
    jam_emu_encoder(EN_ALGO,1); audio(1);
    CHECK(song.sel==2 && !strcmp(jam_emu_sound_name(),"STAR PLUCK"));
    jam_emu_encoder(EN_ALGO,-3); audio(1); /* Role selector clamps at its ends. */
    CHECK(song.sel==TRK_DRUM && !strcmp(jam_emu_sound_name(),"PLUGG KIT"));
    jam_emu_key(0,1); CHECK(audio(200)>1); jam_emu_key(0,0);
    CHECK(emu_lcd_errors==0);
    jam_emu_panic(); audio(FS*6u/CTL);
    CHECK(!song.playing && !fm1_in.notes && !song.rec && !rec_wait);
    printf("Pluggbox full native panel: %u checks passed; startup identity, LCD, physical knob detents, browsing, chord/drum audio and release.\n",checks);
    return 0;
}
