// SPDX-License-Identifier: GPL-3.0-only
// Production Pluggbox candidate/controller/transport with independent mock
// MIDI packets. Host simulations do not establish physical flash timing.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadTrialBundle, TrialInstaller } from '../web/plugg-install-controller.js';
import { logicalImage, sha256hex } from '../web/fm1pkg.js';
import { MockMIDIAccess, profile, familyFrame, sourceFamilyFrame, frame } from './helpers/plugg_install_simulator.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const directory = process.env.PLUGGBOX_TRIAL_BUNDLE || path.join(root, 'build/pluggbox-device');
const manifestBytes = new Uint8Array(await fs.readFile(path.join(directory, 'manifest.json')));
const manifest = JSON.parse(new TextDecoder().decode(manifestBytes));
const firmware = new Uint8Array(await fs.readFile(path.join(directory, manifest.firmware.file)));
const descriptor = JSON.parse(await fs.readFile(path.join(directory, 'trial.json'), 'utf8'));
const jsonBytes = value => new TextEncoder().encode(JSON.stringify(value));
function files(trial = descriptor, metadata = manifestBytes, image = firmware) {
  return new Map([['trial.json', jsonBytes(trial)], ['manifest.json', metadata], [manifest.firmware.file, image]]);
}
function localFetch(entries = files(), calls = []) {
  return async (url, options) => {
    calls.push({ url, options });
    assert.equal(options.credentials, 'omit'); assert.equal(options.redirect, 'error'); assert.equal(options.cache, 'no-store');
    const filename = new URL(url).pathname.split('/').at(-1), bytes = entries.get(filename);
    return bytes ? new Response(bytes.slice(), { status: 200 }) : new Response('missing', { status: 404 });
  };
}
async function load(options = {}) {
  return loadTrialBundle({ baseURL: 'https://example.test/pluggbox/firmware/', fetchImpl: localFetch(), ...options });
}
const bundle = await load();
function ports(options = {}) {
  const access = new MockMIDIAccess(options);
  access.expectedImage = logicalImage(firmware);
  return access;
}
function closed(access) {
  assert.ok(access.ports.every(port => !port.listeners.size && port.opens === port.closes), 'all test MIDI listeners and ports released');
}
async function fast(run, special = ms => ms) {
  const original = globalThis.setTimeout;
  // Accelerate intentional packet/reboot pacing only, retaining all guard and
  // cancellation paths. Failure-specific overall timeout is explicit below.
  globalThis.setTimeout = (fn, ms, ...args) => original(fn, special([10, 2000, 3000].includes(ms) ? 1 : ms), ...args);
  try { return await run(); } finally { globalThis.setTimeout = original; }
}

test('exact actual Pluggbox candidate and source binding remain experimental', async () => {
  const calls = [], loaded = await load({ fetchImpl: localFetch(files(), calls) });
  assert.equal(loaded.firmwareSHA256, await sha256hex(firmware));
  assert.equal(loaded.firmwareSizeBytes, firmware.length);
  assert.equal(loaded.version, '0.1.0-proto');
  assert.equal(loaded.hardwareValidated, false);
  assert.equal(loaded.manifest.family, 'pluggbox');
  assert.equal(loaded.manifest.release_enabled, false);
  assert.equal(loaded.manifest.hardware_validated, false);
  assert.deepEqual(loaded.manifest.transitions.approved, []);
  assert.deepEqual(loaded.trial.transitions, ['jambox-normal-to-pluggbox']);
  assert.ok(Object.isFrozen(loaded) && Object.isFrozen(loaded.trial) && Object.isFrozen(loaded.manifest.build.flags));
  assert(calls.some(call => new URL(call.url).pathname.endsWith('/manifest.json')));
  assert(calls.some(call => new URL(call.url).pathname.endsWith('/' + manifest.firmware.file)));
});

test('wrong trial descriptors and manifest bindings fail before MIDI', async () => {
  const mutations = [value => value.schema_version = 2, value => value.kind = 'release',
    value => value.hardware_validated = true, value => value.transitions = ['factory-v15-to-pluggbox'],
    value => value.transitions.push('jambox-rescue-to-pluggbox'), value => value.transitions = [],
    value => value.extra = true, value => delete value.manifest_sha256,
    value => value.manifest_sha256 = 'f'.repeat(64), value => value.firmware_sha256 = 'f'.repeat(64)];
  for (const change of mutations) {
    const trial = structuredClone(descriptor); change(trial);
    await assert.rejects(load({ fetchImpl: localFetch(files(trial)) }), error => error.started === false);
  }
  for (const change of [value => value.family = 'jamboxfm', value => value.release_enabled = true,
    value => value.hardware_validated = true, value => value.identities.app = 'FM-1_700',
    value => value.build.flags.JAMBOX_RECOVERY = 1, value => value.build.flags.FELUCCA_PERSIST = 1,
    value => value.firmware.file = '../bad.fwsc']) {
    const metadata = structuredClone(manifest); change(metadata); const bytes = jsonBytes(metadata);
    await assert.rejects(load({ fetchImpl: localFetch(files({ ...descriptor, manifest_sha256: await sha256hex(bytes) }, bytes)) }));
  }
});

test('damaged/truncated firmware and bad downloads never prepare a bundle', async () => {
  const corrupt = firmware.slice(); corrupt[1000] ^= 1;
  await assert.rejects(load({ fetchImpl: localFetch(files(descriptor, manifestBytes, corrupt)) }), /SHA|digest|size/i);
  await assert.rejects(load({ fetchImpl: localFetch(files(descriptor, manifestBytes, firmware.subarray(1))) }), /SHA|digest|size/i);
  await assert.rejects(load({ fetchImpl: localFetch(new Map()) }), /HTTP 404/);
  await assert.rejects(load({ fetchImpl: async () => new Response('x', { headers: { 'content-length': '4097' } }) }), /size/i);
  await assert.rejects(load({ fetchImpl: async () => new Response('not JSON') }), /JSON/i);
  const aborted = new AbortController(); aborted.abort(); let calls = 0;
  await assert.rejects(load({ signal: aborted.signal, fetchImpl: async () => { calls++; throw Error('must not fetch'); } }), { code: 'aborted', started: false });
  assert.equal(calls, 0);
});

test('inspection recognizes only normal Jambox as an eligible starting point and is read-only', async () => {
  for (const [name, eligible] of [['jam', true], ['plugg', false], ['loader', false], ['jambox-loader', false],
    ['rescue', false], ['FM-1_015', false], ['FM-1_900', false]]) {
    const access = ports({ source: profile(name) }), installer = new TrialInstaller(access);
    const observed = await installer.inspect(access.pair());
    assert.equal(observed.eligible, eligible, name); assert.equal(observed.hardwareValidated, false);
    assert.equal(observed.transition, eligible ? 'jambox-normal-to-pluggbox' : null);
    assert.deepEqual(access.upgrades, []); assert.equal(installer.busy, false); assert.equal(installer.started, false);
    closed(access);
  }
});

test('Jambox to Pluggbox transfers every actual candidate byte twice and verifies the new family', async () => fast(async () => {
  const access = ports(), steps = [], log = [];
  const installer = new TrialInstaller(access, { onStep: (stage, detail) => steps.push([stage, detail]), onLog: message => log.push(message) });
  const result = await installer.install(bundle, access.pair());
  assert.deepEqual(access.upgrades, ['app', 'loader']);
  assert.deepEqual(access.transfers.map(stage => [stage.stage, stage.verifiedBytes]),
    [['app', firmware.length - 20], ['loader', firmware.length - 20]]);
  assert.equal(result.identity.text, 'FM-1_701'); assert.equal(result.sourceIdentity.text, 'FM-1_700');
  assert.equal(result.transition, 'jambox-normal-to-pluggbox');
  assert.equal(result.firmwareSHA256, bundle.firmwareSHA256);
  assert.equal(result.hardwareValidated, false); assert.equal(result.experimental, true);
  assert.equal(result.verification, 'reported-family-and-release');
  assert.equal(steps[0][0], 'checking'); assert.equal(steps.at(-1)[0], 'done');
  assert.ok(log.every(item => typeof item === 'string' && !item.includes('mock-')));
  assert.equal(installer.busy, false); assert.equal(installer.started, true); closed(access);
}));

test('unprepared bundle objects cannot reach any update command', async () => {
  const access = ports(), installer = new TrialInstaller(access);
  await assert.rejects(installer.install({ ...bundle }, access.pair()), /verif|load/i);
  assert.deepEqual(access.upgrades, []); assert.equal(installer.busy, false);
});

test('foreign sources, recovery modes and the new target as source refuse before staging', async () => {
  for (const name of ['FM-1_015', 'FM-1_900', 'FM-1_0700', 'rescue', 'loader', 'jambox-loader', 'plugg']) {
    const access = ports({ source: profile(name) }), installer = new TrialInstaller(access);
    await assert.rejects(installer.install(bundle, access.pair()), error => error.started === false);
    assert.deepEqual(access.upgrades, []); assert.equal(installer.started, false); closed(access);
  }
});

test('Jambox source requires exact family, release, schema, mode, capability mask and matching wire identity', async () => {
  const probes = [null, ...[{ family: 'PLUGGBOX' }, { family: 'FOREIGN!' }, { schema: 2 }, { mode: 1 },
    { mask: 0x97 }, { mask: 1 }, { release: '0.1.1' }, { identity: 'FM-1_701' }].map(sourceFamilyFrame)];
  for (const family of probes) {
    const access = ports({ source: profile('jam', { family }) }), installer = new TrialInstaller(access);
    assert.equal((await installer.inspect(access.pair())).eligible, false);
    await assert.rejects(installer.install(bundle, access.pair()), { code: 'identity', started: false });
    assert.deepEqual(access.upgrades, []); closed(access);
  }
});

test('source identity and family are rechecked immediately before staging', async () => {
  for (const mutate of [access => { access.profiles.app = profile('FM-1_015'); },
    access => { access.profiles.app = profile('jam', { family: sourceFamilyFrame({ mask: 1 }) }); }]) {
    const access = ports(), installer = new TrialInstaller(access);
    assert.equal((await installer.inspect(access.pair())).eligible, true); mutate(access);
    await assert.rejects(installer.install(bundle, access.pair()), { code: 'identity', started: false });
    assert.deepEqual(access.upgrades, []); closed(access);
  }
});

test('multiple candidate devices refuse before any staging and during family recheck', async () => {
  for (const duringProbe of [false, true]) {
    const access = ports(), installer = new TrialInstaller(access);
    const add = () => {
      access.inputs.set('other-in', { id: 'other-in', name: 'Other FM-1', state: 'connected' });
      access.outputs.set('other-out', { id: 'other-out', name: 'Other FM-1', state: 'connected' });
    };
    if (duringProbe) {
      const send = access.send.bind(access);
      access.send = packet => { send(packet); if (String(packet) === String(frame(0x12, []))) add(); };
    } else add();
    await assert.rejects(installer.install(bundle, access.pair()), { code: 'ambiguous', started: false });
    assert.deepEqual(access.upgrades, []); closed(access);
  }
});

test('wrong numeric loader or Pluggbox loader family cannot receive the loader write command', async () => fast(async () => {
  const loaders = [profile('jambox-loader'), profile('ota-FM-1_900'),
    profile('loader', { family: familyFrame('loader', { family: 'JAMBOXFM' }) }),
    profile('loader', { family: familyFrame('loader', { release: '0.1.0-dev' }) }),
    profile('loader', { family: familyFrame('loader', { mask: 0x17 }) })];
  for (const loader of loaders) {
    const access = ports({ loader }), steps = [], installer = new TrialInstaller(access, { onStep: stage => steps.push(stage) });
    await assert.rejects(installer.install(bundle, access.pair()), error => error.started === true);
    assert.deepEqual(access.upgrades, ['app']); assert.ok(!steps.includes('done')); closed(access);
  }
}));

test('a foreign final family/release/identity never produces success after writing', async () => fast(async () => {
  for (const final of [profile('jam'), profile('plugg', { family: familyFrame('normal', { family: 'JAMBOXFM' }) }),
    profile('plugg', { family: familyFrame('normal', { release: '0.1.1' }) }),
    profile('plugg', { family: familyFrame('normal', { mask: 0x97 }) })]) {
    const access = ports({ final }), steps = [], installer = new TrialInstaller(access, { onStep: stage => steps.push(stage) });
    await assert.rejects(installer.install(bundle, access.pair()), error => error.started === true);
    assert.deepEqual(access.upgrades, ['app', 'loader']); assert.ok(!steps.includes('done')); closed(access);
  }
}));

test('a second MIDI device on reconnect refuses without scanning or a loader upgrade', async () => fast(async () => {
  const access = ports(), attach = access.attach.bind(access);
  access.attach = stage => {
    attach(stage);
    if (stage === 'loader') {
      access.inputs.set('other-in', { id: 'other-in', name: 'Other FM-1', state: 'connected' });
      access.outputs.set('other-out', { id: 'other-out', name: 'Other FM-1', state: 'connected' });
    }
  };
  const installer = new TrialInstaller(access);
  await assert.rejects(installer.install(bundle, access.pair()), { code: 'ambiguous', started: true });
  assert.deepEqual(access.upgrades, ['app']); closed(access);
}));

test('cancellation before staging prevents writes and concurrent operations refuse', async () => {
  const access = ports(), installer = new TrialInstaller(access), controller = new AbortController();
  let opened;
  const input = access.input, open = input.open.bind(input);
  input.open = async () => { await new Promise(resolve => { opened = resolve; }); await open(); };
  const inspection = installer.inspect(access.pair(), { signal: controller.signal });
  await new Promise(resolve => setTimeout(resolve, 1));
  assert.equal(installer.busy, true);
  await assert.rejects(installer.install(bundle, access.pair()), { code: 'busy' });
  controller.abort(); opened();
  await assert.rejects(inspection, { code: 'aborted', started: false });
  assert.deepEqual(access.upgrades, []); closed(access);
  const aborted = new AbortController(); aborted.abort();
  await assert.rejects(installer.install(bundle, access.pair(), { signal: aborted.signal }), { code: 'aborted', started: false });
  assert.deepEqual(access.upgrades, []);
});

test('UI cancellation after staging and rendering exceptions do not abort a write', async () => fast(async () => {
  const access = ports(), controller = new AbortController();
  const installer = new TrialInstaller(access, { onLog() { throw Error('test renderer'); }, onStep(stage) {
    if (stage === 'start') controller.abort(); throw Error('test progress renderer');
  } });
  const result = await installer.install(bundle, access.pair(), { signal: controller.signal });
  assert.equal(result.identity.text, 'FM-1_701'); assert.deepEqual(access.upgrades, ['app', 'loader']); closed(access);
}));

test('partial transfers and failed completion report possible writes and never retry', async () => fast(async () => {
  for (const fault of [{ stage: 'app', type: 'mid-disconnect' }, { stage: 'loader', type: 'finish-send' }]) {
    const access = ports({ fault }), installer = new TrialInstaller(access);
    await assert.rejects(installer.install(bundle, access.pair()), error => {
      assert.equal(error.started, true); assert.equal(error.transition, 'jambox-normal-to-pluggbox');
      assert.equal(error.sourceIdentity.text, 'FM-1_700'); return true;
    });
    assert.ok(access.upgrades.length <= 2); assert.equal(installer.busy, false); closed(access);
  }
}));

test('the overall write deadline still applies after external cancellation stops being effective', async () => fast(async () => {
  const access = ports(), installer = new TrialInstaller(access);
  await assert.rejects(installer.install(bundle, access.pair()), { code: 'timeout', started: true });
  assert.equal(installer.started, true); assert.equal(installer.busy, false);
  assert.deepEqual(access.upgrades, ['app']); closed(access);
}, ms => ms === 600000 ? 15 : ms));
