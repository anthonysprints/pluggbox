#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-only
# Actual Pluggbox package through unchanged production OTA/loader core tests.
# The inherited handshake fixtures identify as 900: this tests bytes, flash
# boundaries and faults. Pluggbox wire identities are tested separately.
set -eu
cd "$(dirname "$0")/.."
out=build/pluggbox-device-tests
mkdir -p "$out"
export AC79_SDK="${AC79_SDK:-/workspace/deps/ac79-sdk}"
python3 tools/build_pluggbox_device.py --no-build > "$out/target-validation.json"
"${CC:-cc}" -O2 -fwrapv -fno-strict-aliasing -Wno-int-to-pointer-cast \
    -Ifirmware/src -Ifirmware/hal tests/jam_storage_ota.c -o "$out/ota" -lm
"$out/ota" build/felucca.fwsc
python3 - <<'PY'
from pathlib import Path
p=Path('build/pluggbox-device-tests/old-app.bin')
p.write_bytes(Path('build/felucca.bin').read_bytes()[:200000])
PY
python3 tools/fm1pkg_make.py "$out/old-app.bin" build/loader/ota.bin "$out/old-fixture.fwsc"
"${CC:-cc}" -O2 -DJAMBOX_PROTO=1 tests/ldr_test.c -o "$out/loader"
"$out/loader" "$out/old-fixture.fwsc" build/felucca.fwsc
echo 'Actual Pluggbox bytes passed OTA staging/isolation and bounded-loader fault tests.'
