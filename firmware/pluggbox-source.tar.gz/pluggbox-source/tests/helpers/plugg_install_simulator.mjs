// SPDX-License-Identifier: GPL-3.0-only
// Test-only wire fixture derived from the Jambox simulator. It exercises the
// real controller/transport but executes no firmware or flash-writing code.
import assert from 'node:assert/strict';

// Independent whole-integer wire codec, separate from the production stream codec.
export function frame(command, body) {
  const raw = [0, 0x59, command, body.length & 255, (body.length >>> 8) & 255, body.length >>> 16,
    ...body, ~body.reduce((a, b) => a + b, 0) & 255];
  let bits = raw.reduce((n, b, i) => n | BigInt(b) << BigInt(i * 8), 0n);
  return [240, ...Array.from({ length: Math.ceil(raw.length * 8 / 7) }, (_, i) => Number((bits >> BigInt(i * 7)) & 127n)), 247];
}
function unframe(packet) {
  const bits = packet.slice(1, -1).reduce((n, b, i) => n | BigInt(b) << BigInt(i * 7), 0n);
  return Array.from({ length: Math.floor((packet.length - 2) * 7 / 8) }, (_, i) => Number(bits >> BigInt(i * 8) & 255n));
}
export function identity(text) {
  const match = /^(.+)_(\d+)$/.exec(text);
  return { text, model: match?.[1] || '', version: Number(match?.[2] || 0) };
}
export function identityFrame(text) { return frame(0x11, Array.from({ length: 27 }, (_, i) => text.charCodeAt(i) || 0)); }
export function familyFrame(mode = 'normal', changes = {}) {
  const body = new Uint8Array(48), index = ['normal', 'rescue', 'loader'].indexOf(mode);
  body.set(Buffer.from(changes.family ?? 'PLUGGBOX')); body[8] = changes.schema ?? 1; body[9] = changes.mode ?? index;
  const mask = changes.mask ?? [0x17, 0x05, 0x09][index]; body[10] = mask & 255; body[11] = mask >>> 8;
  body.set(Buffer.from(changes.release ?? '0.1.0-proto'), 12);
  body.set(Buffer.from(changes.identity ?? ['FM-1_701', 'FM-1_000', 'ota-FM-1_701'][index]), 32);
  return frame(0x12, [...body]);
}
export function sourceFamilyFrame(changes = {}) {
  return familyFrame('normal', { family: 'JAMBOXFM', release: '0.1.0-dev', identity: 'FM-1_700', ...changes });
}
export function profile(name, changes = {}) {
  if (name === 'jam') return { text: 'FM-1_700', family: sourceFamilyFrame(), ...changes };
  if (name === 'plugg') return { text: 'FM-1_701', family: familyFrame('normal'), ...changes };
  if (name === 'loader') return { text: 'ota-FM-1_701', family: familyFrame('loader'), ...changes };
  if (name === 'rescue') return { text: 'FM-1_000', family: familyFrame('rescue'), ...changes };
  if (name === 'jambox-loader') return { text: 'ota-FM-1_700', family: familyFrame('loader', { family: 'JAMBOXFM', release: '0.1.0-dev', identity: 'ota-FM-1_700' }), ...changes };
  return { text: name, ...changes };
}
function request(address, length = 8) {
  return frame(0x30, [0, address & 255, address >>> 8 & 255, address >>> 16 & 255, address >>> 24,
    length & 255, length >>> 8 & 255, length >>> 16]);
}
const mocks = new WeakSet();
class Port {
  constructor(access, type, stage) {
    this.access = access; this.type = type; this.id = `mock-${stage}-${type}`; this.name = `FM-1 test fixture ${stage}`;
    this.state = 'connected'; this.listeners = new Map(); this.opens = 0; this.closes = 0;
  }
  async open() { this.opens++; }
  async close() { this.closes++; }
  addEventListener(kind, listener) { if (!this.listeners.has(kind)) this.listeners.set(kind, new Set()); this.listeners.get(kind).add(listener); }
  removeEventListener(kind, listener) { const set = this.listeners.get(kind); set?.delete(listener); if (!set?.size) this.listeners.delete(kind); }
  emit(packet) { for (const listener of this.listeners.get('midimessage') || []) listener({ data: Uint8Array.from(packet) }); }
  send(packet) { assert.equal(this.type, 'output'); this.access.send(Array.from(packet)); }
}
export class MockMIDIAccess {
  constructor({ source = profile('jam'), loader = profile('loader'), final = profile('plugg'), fault = null } = {}) {
    this.inputs = new Map(); this.outputs = new Map(); this.transcript = []; this.ports = [];
    this.profiles = { app: source, loader, final }; this.stage = source.text.startsWith('ota-') ? 'loader' : 'app';
    if (this.stage === 'loader') this.profiles.loader = source;
    this.fault = fault; this.upgrades = []; this.responses = []; this.expectedImage = null;
    this.transfers = []; this.transfer = null;
    this.handshakes = 0;
    this.attach(this.stage); mocks.add(this);
  }
  attach(stage) {
    this.stage = stage;
    for (const port of this.ports) port.state = 'disconnected';
    this.input = new Port(this, 'input', stage); this.output = new Port(this, 'output', stage);
    this.ports.push(this.input, this.output); this.inputs.set(this.input.id, this.input); this.outputs.set(this.output.id, this.output);
  }
  pair() { return { inputId: this.input.id, outputId: this.output.id }; }
  requestNext() {
    const t = this.transfer;
    if (t.verifiedBytes === this.expectedImage.length) {
      this.input.emit(request(this.stage === 'app' ? 0xe0000000 : 0xf0000000)); return;
    }
    // This deliberately covers every byte with 512-byte and 481-byte responses.
    // It is a generic host-protocol exercise, not a captured device transcript:
    // the factory app, its loader, and the flash-writing code do not execute.
    t.requestLength = Math.min(t.chunks === 1 ? 481 : 512, this.expectedImage.length - t.verifiedBytes);
    this.input.emit(request(t.verifiedBytes, t.requestLength));
  }
  send(packet) {
    this.transcript.push({ stage: this.stage, packet });
    const current = this.profiles[this.stage];
    if (String(packet) === '240,0,50,69,0,0,0,64,127,247') {
      this.handshakes++;
      if (this.fault?.stage === this.stage && this.fault.type === 'identity-change' && this.handshakes > 1)
        this.profiles[this.stage] = profile(this.fault.nextIdentity || 'FM-1_015');
      if (this.fault?.stage === this.stage && this.fault.type === 'abort-identify') this.fault.controller.abort();
      return this.input.emit(identityFrame(this.profiles[this.stage].text));
    }
    if (String(packet) === String(frame(0x12, []))) { if (current.family) this.input.emit(current.family); return; }
    if (String(packet) === '240,125,70,76,1,247') { if (current.info) this.input.emit(current.info); return; }
    if (String(packet) === '240,34,36,53,127,247') {
      this.upgrades.push(this.stage);
      if (this.fault?.stage === this.stage && this.fault.type === 'silence') { this.fault.onSilence(); return; }
      if (this.fault?.stage === this.stage && this.fault.type === 'abort') { this.fault.controller.abort(); return; }
      if (this.fault?.stage === this.stage && this.fault.type === 'disconnect') { this.input.state = this.output.state = 'disconnected'; return; }
      if (this.fault?.stage === this.stage && this.fault.type === 'bad-request') return this.input.emit(request(this.expectedImage.length, 1));
      this.transfer = { stage: this.stage, verifiedBytes: 0, chunks: 0, requestLength: 0 };
      this.transfers.push(this.transfer); this.requestNext(); return;
    }
    const raw = unframe(packet), body = raw.slice(6, -1);
    assert.equal(raw[2], 0x30, 'Mock rejects any unexpected write command');
    assert.deepEqual(packet, frame(0x30, body), 'Response must have canonical framing/checksum');
    const address = (body[1] | body[2] << 8 | body[3] << 16 | body[4] << 24) >>> 0;
    const length = body[5] | body[6] << 8 | body[7] << 16;
    assert.equal(length, body.length - 8);
    if (address >= 0xe0000000) {
      assert.equal(this.transfer.verifiedBytes, this.expectedImage.length, 'Every image byte must be checked before completion');
      assert.deepEqual(body.slice(8), [...Buffer.from('success\0')]);
      if (this.fault?.stage === this.stage && this.fault.type === 'finish-send') throw new Error('Simulated failed terminal send');
      if (this.fault?.stage === this.stage && this.fault.type === 'missing-after-finish') {
        for (const port of this.ports) port.state = 'disconnected'; return;
      }
      this.attach(this.stage === 'app' ? 'loader' : 'final');
    } else {
      assert.equal(address, this.transfer.verifiedBytes, 'Responses must match the next contiguous request');
      assert.equal(length, this.transfer.requestLength, 'Responses must match the requested length');
      assert.deepEqual(body.slice(8), [...this.expectedImage.subarray(address, address + length)]);
      this.responses.push({ stage: this.stage, address, length });
      this.transfer.verifiedBytes += length; this.transfer.chunks++;
      if (this.fault?.stage === this.stage && this.fault.type === 'mid-disconnect' && this.transfer.verifiedBytes >= 1024) {
        this.input.state = this.output.state = 'disconnected'; return;
      }
      this.requestNext();
    }
  }
}

