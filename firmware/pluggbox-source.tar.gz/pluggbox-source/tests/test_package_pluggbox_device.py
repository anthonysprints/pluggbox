#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Tamper/regression checks over the real verified device bundle, no hardware."""
import copy
import gzip
import io
import json
from pathlib import Path
import sys
import tarfile
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
import package_pluggbox_device as package


def seal(files):
    files['SHA256SUMS'] = ''.join(f'{package.receipt.sha(data)}  {name}\n'
        for name, data in sorted(files.items()) if name != 'SHA256SUMS').encode()
    return files


def edit_json(files, name, change):
    data = json.loads(files[name])
    change(data)
    files[name] = package.receipt.json_bytes(data)


class DevicePackageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.files = package.read_package()

    def test_real_firmware_source_and_record_are_bound(self):
        manifest = package.validate_files(self.files)
        self.assertFalse(manifest['hardware_validated'])
        self.assertFalse(manifest['release_enabled'])
        self.assertEqual(manifest['identities']['app'], 'FM-1_701')
        source = package.source_contents(self.files[package.SOURCE])
        record = json.loads(self.files['build-receipt.json'])
        self.assertGreater(len(record['inputs_sha256']), 20)
        for name, digest in record['inputs_sha256'].items():
            self.assertEqual(package.receipt.sha(source[name]), digest)

    def test_changed_firmware_is_rejected(self):
        files = dict(self.files)
        data = bytearray(files[package.FIRMWARE]); data[1000] ^= 1
        files[package.FIRMWARE] = bytes(data)
        with self.assertRaisesRegex(ValueError, 'checksum'):
            package.validate_files(files)
        seal(files)
        with self.assertRaisesRegex(ValueError, 'descriptor'):
            package.validate_files(files)

    def test_foreign_family_and_false_hardware_claim_rejected_even_with_checksums(self):
        for name, value in [('family', 'jamboxfm'), ('hardware_validated', True), ('release_enabled', True), ('schema_version', True)]:
            files = dict(self.files)
            edit_json(files, 'manifest.json', lambda data: data.update({name: value}))
            with self.assertRaisesRegex(ValueError, 'profile'):
                package.validate_files(seal(files))

    def test_persistence_or_recovery_flags_cannot_be_rebound(self):
        for name in ('FELUCCA_PERSIST', 'JAMBOX_RECOVERY'):
            files = dict(self.files)
            edit_json(files, 'build-receipt.json', lambda data: data['configuration']['app']['flags'].update({name: 1}))
            with self.assertRaisesRegex(ValueError, 'requires'):
                package.validate_files(seal(files))

    def test_failed_memory_gate_rejected_after_metadata_rebinding(self):
        files = dict(self.files)
        edit_json(files, 'memory.json', lambda data: data.update({'ok': False, 'errors': ['overflow']}))
        edit_json(files, 'manifest.json', lambda data: data['build'].update({'memory_report_sha256': package.receipt.sha(files['memory.json'])}))
        with self.assertRaisesRegex(ValueError, 'memory/ELF'):
            package.validate_files(seal(files))

    def test_missing_notice_or_unrelated_payload_rejected(self):
        files = dict(self.files); files.pop('licenses/AC79-SDK-LICENSE.txt')
        with self.assertRaisesRegex(ValueError, 'membership'):
            package.validate_files(files)
        files = dict(self.files); files['other.fwsc'] = b'foreign'
        with self.assertRaisesRegex(ValueError, 'membership'):
            package.validate_files(files)

    def test_trial_bindings_and_transition_are_exact(self):
        for change in (lambda data: data.update({'firmware_sha256': '0' * 64}),
                       lambda data: data.update({'transitions': ['factory-v15-to-pluggbox']})):
            files = dict(self.files); edit_json(files, 'trial.json', change)
            with self.assertRaisesRegex(ValueError, 'Trial metadata'):
                package.validate_files(seal(files))

    def test_source_symlink_is_refused_and_private_paths_are_omitted(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder) / 'source'; root.mkdir()
            for name in package.SOURCE_FILES:
                (root / name).write_text('fixture')
            for name in package.SOURCE_DIRS:
                (root / name).mkdir()
            (root / 'tools/.env').write_text('fixture-private')
            (root / 'tools/keep.py').write_text('print(1)')
            names = [path.relative_to(root).as_posix() for path in package.source_files(root)]
            self.assertNotIn('tools/.env', names)
            self.assertIn('tools/keep.py', names)
            external = Path(folder) / 'external.py'; external.write_text('fixture')
            (root / 'tools/escape.py').symlink_to(external)
            with self.assertRaisesRegex(ValueError, 'Non-regular source'):
                package.source_files(root)

    def test_source_archive_traversal_is_rejected_without_extraction(self):
        output = io.BytesIO()
        with tarfile.open(fileobj=output, mode='w:gz') as archive:
            info = tarfile.TarInfo('pluggbox-source/../escape'); info.size = 1
            archive.addfile(info, io.BytesIO(b'x'))
        with self.assertRaisesRegex(ValueError, 'Unsafe source path'):
            package.source_contents(output.getvalue())


if __name__ == '__main__':
    unittest.main()
