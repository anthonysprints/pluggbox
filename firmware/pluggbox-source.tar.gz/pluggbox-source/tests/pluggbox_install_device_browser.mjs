// SPDX-License-Identifier: GPL-3.0-only
// Actual Chromium against the packaged guided site. The independently encoded
// MIDI fixture derives from Jambox's read-only checker test.
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { resolve, extname, sep } from 'node:path';
import { pathToFileURL } from 'node:url';

const playwright = process.env.PLAYWRIGHT_MODULE ? pathToFileURL(resolve(process.env.PLAYWRIGHT_MODULE)).href : 'playwright-core';
const { chromium } = await import(playwright);
const root = resolve(process.env.PLUGGBOX_SITE_ROOT || 'build/pluggbox-site');
const evidence = resolve('build/pluggbox-install-evidence');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.wasm': 'application/wasm', '.wav': 'audio/wav', '.gz': 'application/gzip' };
const server = createServer(async (request, response) => {
  try {
    const pathname = new URL(request.url, 'http://localhost').pathname;
    const path = resolve(root, '.' + pathname + (pathname.endsWith('/') ? 'index.html' : ''));
    if (!path.startsWith(root + sep)) throw new Error('Outside site');
    const body = await readFile(path);
    response.writeHead(200, { 'Content-Type': mime[extname(path)] || 'application/octet-stream' }); response.end(body);
  } catch { response.writeHead(404); response.end('Not found'); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const address = `http://127.0.0.1:${server.address().port}`;
const allowed = [
  [0xf0, 0, 0x32, 0x45, 0, 0, 0, 0x40, 0x7f, 0xf7],
  [0xf0, 0, 0x32, 0x49, 0, 0, 0, 0x40, 0x7f, 0xf7],
  [0xf0, 0x7d, 0x46, 0x4c, 1, 0xf7],
];

function fakeWebMIDI(config) {
  const handshake = [0xf0, 0, 0x32, 0x45, 0, 0, 0, 0x40, 0x7f, 0xf7];
  const capability = [0xf0, 0, 0x32, 0x49, 0, 0, 0, 0x40, 0x7f, 0xf7];
  const info = [0xf0, 0x7d, 0x46, 0x4c, 1, 0xf7];
  const equal = (a, b) => a.length === b.length && a.every((value, index) => value === b[index]);
  const text = value => Array.from(value, char => char.charCodeAt(0));
  const padded = (value, size) => { const bytes = Array(size).fill(0); bytes.splice(0, value.length, ...text(value)); return bytes; };
  // Fixture encoder is independent of the production module under test.
  function message(command, body) {
    const raw = [0, 0x59, command, body.length, 0, 0, ...body, ~body.reduce((sum, byte) => sum + byte, 0) & 255];
    const packed = []; let bits = 0, count = 0;
    for (const byte of raw) {
      bits |= byte << count; count += 8;
      while (count >= 7) { packed.push(bits & 127); bits >>>= 7; count -= 7; }
    }
    if (count) packed.push(bits & 127);
    return [0xf0, ...packed, 0xf7];
  }
  const access = new EventTarget(); access.inputs = new Map(); access.outputs = new Map(); access.sysexEnabled = true;
  const state = globalThis.fakeMIDI = { requests: [], sent: [], opened: [], closed: [], devices: [], denied: !!config.denied };
  const change = port => { const event = new Event('statechange'); event.port = port; access.dispatchEvent(event); };
  function addDevice(options = {}) {
    const index = state.devices.length;
    const device = { kind: 'jam', mode: 'normal', name: 'JamBoxFM PRIVATE PORT', serial: 'PRIVATE-SERIAL-93810', ...options };
    const id = suffix => `${index}-PRIVATE-${suffix}-ID`;
    class Port extends EventTarget {
      constructor(type) {
        super(); this.type = type; this.name = device.name; this.id = id(type); this.state = 'connected'; this.connection = 'closed'; this.listeners = new Set();
      }
      addEventListener(type, fn, ...rest) { if (type === 'midimessage') this.listeners.add(fn); super.addEventListener(type, fn, ...rest); }
      removeEventListener(type, fn, ...rest) { if (type === 'midimessage') this.listeners.delete(fn); super.removeEventListener(type, fn, ...rest); }
      async open() { state.opened.push(this.id); this.connection = 'open'; change(this); return this; }
      async close() {
        if (device.closeDelay) await new Promise(resolve => setTimeout(resolve, device.closeDelay));
        state.closed.push(this.id); this.connection = 'closed'; change(this); return this;
      }
      send(bytes) {
        const data = Array.from(bytes); state.sent.push({ id: this.id, bytes: data });
        let response = null, delay = device.delay || 0;
        const identity = device.identity || (device.kind === 'sloop' ? 'FM-1_900' : device.mode === 'loader' ? 'ota-FM-1_700' : device.mode === 'rescue' ? 'FM-1_000' : 'FM-1_700');
        if (equal(data, handshake)) {
          response = message(0x11, padded(identity, 27));
          if (device.badIdentity) response[response.length - 2] ^= 1;
          delay = device.identityDelay ?? delay;
        } else if (equal(data, capability) && device.kind === 'jam' && !device.noCapability) {
          response = message(0x12, [...text('JAMBOXFM'), 1, ['normal', 'rescue', 'loader'].indexOf(device.mode),
            { normal: 0x17, rescue: 0x05, loader: 0x09 }[device.mode], 0,
            ...padded('0.1.0-dev', 20), ...padded(identity, 16)]);
          if (device.badCapability) response[response.length - 2] ^= 1;
          delay = device.capabilityDelay ?? delay;
        } else if (equal(data, info) && device.kind === 'sloop') {
          const engines = ['ANALOG', 'DIGITAL', 'PHASE', 'LOFI', 'SAMPLE', 'VOICE', 'TRIO', 'WHEEL', 'GRAIN', 'FM6', 'PHYS', 'NOISE'];
          response = [0xf0, 0x7d, 0x46, 0x4c, 1, ...text('FELUCCA SLOOP 2.6'), 0, 12, 71, 45, 64, 63,
            ...engines.flatMap(name => [...text(name), 0]), 4, 10, 0xf7];
        }
        if (response && !device.silent) setTimeout(() => {
          const event = new Event('midimessage'); event.data = Uint8Array.from(response); device.input.dispatchEvent(event); state.delivered++;
        }, delay);
      }
    }
    device.input = new Port('input'); device.output = new Port('output'); state.devices.push(device);
    access.inputs.set(device.input.id, device.input); access.outputs.set(device.output.id, device.output);
    change(device.input); change(device.output); return index;
  }
  state.delivered = 0;
  state.addDevice = addDevice;
  state.disconnect = index => { const device = state.devices[index]; for (const port of [device.input, device.output]) { port.state = 'disconnected'; change(port); } };
  state.snapshot = () => ({ requests: state.requests, sent: state.sent, opened: state.opened, closed: state.closed,
    listeners: state.devices.map(device => device.input.listeners.size), delivered: state.delivered });
  for (const device of config.devices ?? [{}]) addDevice(device);
  Object.defineProperty(navigator, 'requestMIDIAccess', { configurable: true, value: config.unsupported ? undefined : async options => {
    state.requests.push(options);
    if (state.denied) throw new DOMException('Test permission denial', 'NotAllowedError');
    return access;
  } });
}

const browser = await chromium.launch({executablePath:process.env.CHROMIUM_PATH || '/usr/bin/chromium',headless:true,args:['--no-sandbox']});
try {
  for (const [name,config,eligible] of [['supported Jambox',{},true],['wrong firmware',{devices:[{kind:'sloop'}]},false]]) {
    const page=await browser.newPage(); const errors=[];page.on('pageerror',e=>errors.push(e.message));
    await page.addInitScript(fakeWebMIDI,config);await page.goto(address+'/install/');
    await page.waitForFunction(()=>document.getElementById('release-badge').textContent==='EXPERIMENTAL');
    assert(await page.locator('#install-device').isDisabled());
    await page.locator('#connect-device').click();
    await page.waitForFunction(()=>!document.getElementById('check-device').disabled);
    await page.locator('#check-device').click();await page.locator('#device-result').waitFor({state:'visible'});
    assert(await page.locator('#install-device').isDisabled());
    await page.locator('#trial-ack').check();
    assert.equal(await page.locator('#install-device').isEnabled(),eligible);
    if(eligible){await page.evaluate(()=>fakeMIDI.disconnect(0));assert(await page.locator('#install-device').isDisabled());}
    assert.deepEqual(errors,[]);await page.close();console.log('PASS '+name+' install gating');
  }
  const mobile=await browser.newPage({viewport:{width:390,height:844}});await mobile.goto(address+'/install/');
  await mobile.waitForFunction(()=>document.getElementById('release-badge').textContent==='EXPERIMENTAL');
  assert(await mobile.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
  await mkdir(evidence,{recursive:true});await mobile.screenshot({path:resolve(evidence,'experimental-mobile.png'),fullPage:true});await mobile.close();
  console.log('PASS mobile layout and real firmware loading');
} finally {await browser.close();await new Promise(resolve=>server.close(resolve));}
