#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-only
set -eu
cd "$(dirname "$0")/.."
CC="${CC:-clang}"
command -v "$CC" >/dev/null || { echo 'Source tools/cloud/activate_pluggbox.sh first.' >&2; exit 1; }
python3 tools/build_pluggbox.py
mkdir -p build/pluggbox-evidence
"$CC" -O2 -fwrapv -fno-strict-aliasing -w -Ibuild/pluggbox-gen -Ifirmware/src \
    tests/pluggbox_native.c -o build/pluggbox-evidence/native -lm
build/pluggbox-evidence/native
node tests/pluggbox_wasm.mjs
node tests/pluggbox_browser.mjs
echo 'Pluggbox production C/WASM audio and Chromium workflow passed.'
