#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Publication checks against a local bare repository; never contacts GitHub."""
from pathlib import Path
import hashlib
import io
import json
import subprocess
import sys
import tarfile
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
import publish_pluggbox_site as publish


def encoded(value):
    return (json.dumps(value, sort_keys=True) + '\n').encode()


def rebind(files):
    manifest = {
        'product': 'Pluggbox', 'target': 'guided-browser-and-read-only-device-page',
        'install_available': False, 'firmware_payload_included': False,
        'runtime_wasm_sha256': publish.sha(files['play/pluggbox.wasm']),
        'play_html_download_links_adjusted': True,
        'files': {name: {'sha256': publish.sha(body), 'size_bytes': len(body)}
                  for name, body in files.items() if name not in {'site-manifest.json', 'SHA256SUMS'}},
    }
    files['site-manifest.json'] = encoded(manifest)
    files['SHA256SUMS'] = ''.join(f'{publish.sha(body)}  {name}\n' for name, body in sorted(files.items())
                                 if name != 'SHA256SUMS').encode()
    return files


def fixture():
    required = {'LICENSE', 'LICENSING.md', 'README.md', 'firmware/src/plugg_palette.c',
                'firmware/host/plugg_preview.c', 'tools/build_pluggbox.py', 'tools/package_pluggbox_site.py',
                *('web/plugg/' + n for n in ('index.html', 'style.css', 'app.js', 'worklet.js')),
                *('web/plugg-install/' + n for n in publish.INSTALL_FILES),
                *('web/' + n for n in publish.READ_ONLY_MODULES)}
    source = {name: (ROOT / name).read_bytes() for name in required}
    archive = io.BytesIO()
    with tarfile.open(fileobj=archive, mode='w:gz') as tar:
        for name, body in sorted(source.items()):
            info = tarfile.TarInfo('pluggbox-source/' + name)
            info.size = len(body)
            tar.addfile(info, io.BytesIO(body))
    files = {name: b'fixture\n' for name in publish.EXPECTED_FILES}
    files['.nojekyll'] = b''
    files['play/pluggbox.wasm'] = b'\0asm\x01\0\0\0'
    files['pluggbox-source.tar.gz'] = archive.getvalue()
    files['LICENSE.txt'] = source['LICENSE']
    files['LICENSING.md'] = source['LICENSING.md']
    files['firmware/pluggbox-release.json'] = encoded(publish.RELEASE)
    for name in publish.INSTALL_FILES:
        files['install/' + name] = source['web/plugg-install/' + name]
    for name in publish.READ_ONLY_MODULES:
        files[name] = source['web/' + name]
    for name in ('index.html', 'style.css', 'app.js', 'worklet.js'):
        files['play/' + name] = source['web/plugg/' + name]
    files['play/index.html'] = files['play/index.html'].replace(
        b'href="pluggbox-source.tar.gz"', b'href="../pluggbox-source.tar.gz"').replace(
        b'href="LICENSE.txt"', b'href="../LICENSE.txt"')
    files['play/build-receipt.json'] = encoded({
        'target': 'pluggbox-browser',
        'inputs_sha256': {name: publish.sha(body) for name, body in source.items()},
        'outputs_sha256': {'index.html': publish.sha(source['web/plugg/index.html']),
            **{name: publish.sha(files['play/' + name]) for name in ('style.css', 'app.js', 'worklet.js', 'pluggbox.wasm')}},
    })
    return rebind(files)


class PublicationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.files = fixture()

    def test_valid_snapshot_and_fixed_destination(self):
        publish.validate_snapshot(dict(self.files))
        self.assertEqual(publish.DESTINATION, 'https://github.com/anthonysprints/pluggbox.git')
        self.assertEqual(publish.BRANCH, 'refs/heads/gh-pages')

    def test_forged_available_release_is_refused_even_with_fresh_checksums(self):
        files = dict(self.files)
        release = dict(publish.RELEASE, status='ready', install_available=True)
        files['firmware/pluggbox-release.json'] = encoded(release)
        rebind(files)
        with self.assertRaisesRegex(publish.DeploymentError, 'exact guided-site file set'):
            publish.validate_snapshot(files)

    def test_missing_checksum_cannot_hide_an_output(self):
        files = dict(self.files)
        files['SHA256SUMS'] = b'\n'.join(files['SHA256SUMS'].splitlines()[1:]) + b'\n'
        with self.assertRaisesRegex(publish.DeploymentError, 'every website file'):
            publish.validate_snapshot(files)

    def test_runtime_source_mismatch_is_refused_after_rebinding(self):
        files = dict(self.files)
        files['install/app.js'] += b'// unreviewed edit\n'
        rebind(files)
        with self.assertRaisesRegex(publish.DeploymentError, 'Installer source differs'):
            publish.validate_snapshot(files)

    def test_unexpected_firmware_and_linked_files_are_refused(self):
        files = dict(self.files)
        files['firmware/pretend.fwsc'] = b'bad'
        with self.assertRaises(publish.DeploymentError):
            publish.validate_snapshot(files)
        with tempfile.TemporaryDirectory() as folder:
            base = Path(folder)
            for name, body in self.files.items():
                path = base / name
                path.parent.mkdir(exist_ok=True, parents=True)
                path.write_bytes(body)
            (base / 'README.txt').unlink()
            (base / 'README.txt').symlink_to(base / 'LICENSE.txt')
            with self.assertRaisesRegex(publish.DeploymentError, 'Linked'):
                publish.validate_site(base)

    def test_source_symlink_member_is_refused(self):
        stream = io.BytesIO()
        with tarfile.open(fileobj=stream, mode='w:gz') as tar:
            entry = tarfile.TarInfo('pluggbox-source/README.md')
            entry.type = tarfile.SYMTYPE
            entry.linkname = '/etc/passwd'
            tar.addfile(entry)
        with self.assertRaisesRegex(publish.DeploymentError, 'Unsupported'):
            publish.source_contents(stream.getvalue())

    def test_dry_run_does_not_publish_and_updates_preserve_history(self):
        with tempfile.TemporaryDirectory() as folder:
            remote = Path(folder) / 'remote.git'
            subprocess.run(['git', 'init', '--bare', '--quiet', str(remote)], check=True)
            with publish.prepare_deployment(dict(self.files), str(remote)) as stage:
                self.assertIsNone(stage.parent)
                self.assertEqual(stage.finish()['action'], 'dry-run')
                self.assertEqual(publish.git(remote, 'show-ref', check=False).returncode, 1)
                first = stage.finish(publish=True)['commit']  # Only the local test repository.
            files = dict(self.files)
            files['README.txt'] += b'new local test version\n'
            rebind(files)
            with publish.prepare_deployment(files, str(remote)) as stage:
                self.assertEqual(stage.parent, first)
                self.assertEqual(publish.git(stage.directory, 'rev-parse', stage.commit + '^').stdout.strip(), first)
                self.assertEqual(stage.finish()['action'], 'dry-run')
                self.assertEqual(publish.git(remote, 'rev-parse', publish.BRANCH).stdout.strip(), first)
                second = stage.finish(publish=True)['commit']
            self.assertNotEqual(first, second)
            with publish.prepare_deployment(files, str(remote)) as stage:
                self.assertFalse(stage.changed)
                self.assertEqual(stage.finish()['action'], 'unchanged')

    def test_existing_unrelated_pages_content_is_preserved_by_refusal(self):
        with tempfile.TemporaryDirectory() as folder:
            remote = Path(folder) / 'remote.git'
            subprocess.run(['git', 'init', '--bare', '--quiet', str(remote)], check=True)
            with publish.prepare_deployment(dict(self.files), str(remote)) as stage:
                stage.finish(publish=True)
                (stage.directory / 'other-app.txt').write_text('Existing user page\n')
                publish.git(stage.directory, 'add', 'other-app.txt')
                publish.git(stage.directory, '-c', 'commit.gpgsign=false', 'commit', '--quiet', '-m', 'Local unrelated page')
                publish.git(stage.directory, 'push', '--quiet', 'origin', f'HEAD:{publish.BRANCH}')
            before = publish.git(remote, 'rev-parse', publish.BRANCH).stdout.strip()
            with self.assertRaisesRegex(publish.DeploymentError, 'unrelated'):
                with publish.prepare_deployment(dict(self.files), str(remote)):
                    self.fail('Unrelated existing page must not be replaced')
            self.assertEqual(publish.git(remote, 'rev-parse', publish.BRANCH).stdout.strip(), before)


if __name__ == '__main__':
    unittest.main()
