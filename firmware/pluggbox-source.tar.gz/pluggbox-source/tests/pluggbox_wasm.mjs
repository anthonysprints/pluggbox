// SPDX-License-Identifier: GPL-3.0-only
// Production C + actual WebAssembly/AudioWorklet wrapper contracts.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { JamEngine, CommandQueue } from '../web/plugg/worklet.js';

const module = await WebAssembly.compile(readFileSync('build/pluggbox/pluggbox.wasm'));
assert.deepEqual(WebAssembly.Module.imports(module), [], 'no hidden hardware/runtime imports');
let checks = 0, maxNativeDelta = 0;
function check(condition, message) { checks++; assert(condition, message); }
function render(engine, frames = 8192) {
  const left = new Float32Array(frames), right = new Float32Array(frames);
  engine.render(left, right);
  let energy = 0, peak = 0;
  for (const channel of [left, right]) for (const sample of channel) {
    assert(Number.isFinite(sample) && Math.abs(sample) <= 1, 'finite and bounded audio');
    energy += Math.abs(sample); peak = Math.max(peak, Math.abs(sample));
  }
  return { left, right, energy, peak };
}
function command(engine, type, ...args) { engine.command({ type, args }); }
function events(engine, track) {
  return Array.from({ length: 64 }, (_, step) => Array.from({ length: engine.value(22, track, step) }, (_, n) => engine.value(23, track, step * 4 + n)));
}
{
  const engine = new JamEngine(module), state = engine.snapshot();
  assert.equal(state.tempo, 144); assert.equal(state.playing, false); assert.equal(state.selected, 1);
  assert.equal(state.demo, false);
  assert.deepEqual(state.tracks.map(track => track.track), [3, 0, 1, 2]);
  assert.deepEqual(state.tracks.map(track => track.soundCount), [2, 2, 2, 2]);
  assert.deepEqual(state.tracks.map(track => track.sound), ['PLUGG KIT', 'CLEAN SLIDE', 'GLASS EP', 'STAR PLUCK']);
  check(state.tracks.every(track => track.macros.length === 4), 'four working macros per role');
  check(state.tracks.filter(track => track.track < 3).every(track => track.root === 6 && track.scale === 2 && track.events === 0), 'F# minor; no hidden prerecorded melodies');
  check(state.steps.some(Boolean), 'editable starting drum groove exists');
}
// Each fresh native process starts with the same engine state as each fresh WASM instance.
for (const track of [0, 1, 2, 3]) {
  const nativeSounds = [];
  for (let sound = 0; sound < 2; sound++) {
    const engine = new JamEngine(module), key = track === 3 ? 0 : 7;
    command(engine, 'select', track); command(engine, 'sound', track, sound);
    command(engine, 'key', key, 1); const a = render(engine, 4096);
    command(engine, 'key', key, 0); const b = render(engine, 4096);
    check(a.energy + b.energy > 0.1, `track ${track}, sound ${sound} actually generates audio`);
    const raw = execFileSync('build/pluggbox-evidence/native', ['--audio', String(track), String(sound)]);
    const native = new Float32Array(raw.buffer.slice(raw.byteOffset, raw.byteOffset + raw.byteLength));
    assert.equal(native.length, 8192 * 2);
    const left = [...a.left, ...b.left], right = [...a.right, ...b.right];
    let delta = 0;
    for (let index = 0; index < left.length; index++) delta = Math.max(delta, Math.abs(left[index] - native[2 * index]), Math.abs(right[index] - native[2 * index + 1]));
    maxNativeDelta = Math.max(maxNativeDelta, delta);
    check(delta <= 1 / 32768, `track ${track}, sound ${sound}: native/WASM max delta ${delta}`);
    assert.equal(engine.value(12), 0, 'keys release through the actual firmware path');
    nativeSounds.push(raw);
  }
  check(!nativeSounds[0].equals(nativeSounds[1]), `track ${track}'s alternatives have different audio, not just different labels`);
}
{
  const engine = new JamEngine(module);
  command(engine, 'record', 1); assert.equal(engine.value(20), 1);
  command(engine, 'key', 7, 1); render(engine, 14720); command(engine, 'key', 7, 0); render(engine, 14720);
  command(engine, 'key', 9, 1); render(engine, 14720); command(engine, 'key', 9, 0); command(engine, 'record', 0);
  check(engine.value(21, 1) >= 8, 'record two full seventh chords');
  const chords = events(engine, 1), chordCount = engine.value(21, 1);
  command(engine, 'select', 0); command(engine, 'record', 1); command(engine, 'key', 7, 1);
  render(engine, 14720); command(engine, 'key', 7, 0); command(engine, 'record', 0);
  check(engine.value(21, 0) > 0, 'record bass without replacing harmony');
  assert.deepEqual(events(engine, 1), chords);
  command(engine, 'sound', 1, 1); assert.deepEqual(events(engine, 1), chords, 'browsing preserves take');
  command(engine, 'demo', 1); command(engine, 'demo', 1); render(engine, 44100);
  assert.equal(engine.snapshot().demo, true);
  check([0, 1, 2].every(track => engine.value(21, track) > 0), 'starter jam plays all three melodic roles');
  check(render(engine, 44100).energy > 1, 'starter jam produces real audio');
  command(engine, 'demo', 0); command(engine, 'demo', 0); render(engine, 32);
  assert.equal(engine.snapshot().demo, false); assert.equal(engine.value(1), 0);
  assert.deepEqual(events(engine, 1), chords, 'demo restores original recorded notes');
  assert.equal(engine.value(21, 1), chordCount, 'idempotent demo toggle preserves take');
  command(engine, 'demo', 1); render(engine, 32); command(engine, 'record', 1);
  assert.equal(engine.snapshot().demo, false, 'recording leaves audition before modifying user take');
  check(!!engine.value(19) || !!engine.value(20), 'recording is active or armed after leaving audition');
  assert.deepEqual(events(engine, 1), chords);
  command(engine, 'panic'); render(engine, 44100 * 6);
  check(render(engine, 44100).energy < 0.1, 'panic releases voices and effect tails');
  command(engine, 'reset'); render(engine, 32);
  const state = engine.snapshot();
  assert.equal(state.tempo, 144); assert.equal(state.playing, false); assert.equal(state.demo, false);
  check(state.tracks.filter(track => track.track < 3).every(track => track.events === 0), 'explicit reset restores an empty melodic workspace');
  command(engine, 'record', 1); assert.equal(engine.value(20), 1);
  command(engine, 'demo', 1); render(engine, 32);
  assert.equal(engine.value(20), 0, 'entering demo cancels armed recording');
  assert.equal(engine.value(19), 0, 'demo cannot record into its temporary pattern');
  command(engine, 'demo', 0); render(engine, 32);
  command(engine, 'play', 1); render(engine, 32); command(engine, 'record', 1);
  check(engine.value(19) > 0, 'capture active before audition transition');
  command(engine, 'demo', 1); render(engine, 32);
  assert.equal(engine.value(19), 0, 'entering demo finishes active recording');
  assert.equal(engine.value(20), 0);
  command(engine, 'demo', 0); command(engine, 'reset'); render(engine, 32);
  checks += 2;
}
{
  const engine = new JamEngine(module), before = engine.snapshot().steps[0];
  command(engine, 'step', 0, 7); assert.equal(engine.snapshot().steps[0], before ^ (1 << 7));
  command(engine, 'step', 0, 7); assert.equal(engine.snapshot().steps[0], before);
  for (const track of [0, 1, 2, 3]) for (let sound = 0; sound < 2; sound++) {
    command(engine, 'sound', track, sound);
    for (let knob = 0; knob < 4; knob++) {
      command(engine, 'macro', track, knob, -999);
      assert.equal(engine.snapshot().tracks.find(part => part.track === track).macros[knob].value, 0);
      command(engine, 'macro', track, knob, 999);
      assert.equal(engine.snapshot().tracks.find(part => part.track === track).macros[knob].value, 100);
      command(engine, 'select', track); command(engine, 'key', track === 3 ? 0 : 7, 1); render(engine, 2048);
      command(engine, 'key', track === 3 ? 0 : 7, 0); command(engine, 'sound', track, sound);
      checks++;
    }
  }
  command(engine, 'play', 1); render(engine, 32); command(engine, 'key', 7, 1);
  const queue = new CommandQueue(4);
  assert.equal(queue.add(Array.from({ length: 5 }, () => ({ type: 'tempo', args: [120] }))), false);
  queue.drain(engine); render(engine, 32);
  assert.equal(engine.value(12), 0); assert.equal(engine.value(1), 0, 'overflow stops clock and releases keys');
  queue.add([{ type: 'tempo', args: [150] }, { type: 'swing', args: [18] }]); queue.drain(engine, 1);
  assert.equal(queue.count, 1); assert.equal(engine.value(2), 150); queue.drain(engine, 1); assert.equal(engine.value(3), 18);
  command(engine, 'reset'); render(engine, 32);
  command(engine, 'togglePlay'); command(engine, 'togglePlay'); render(engine, 32);
  assert.equal(engine.value(1), 0, 'rapid double play cancels pending start');
  command(engine, 'soundStep', 0, 1); command(engine, 'soundStep', 0, 1);
  assert.equal(engine.w.jam_sound_index(0), 0, 'two-choice browser wraps in input order');
  command(engine, 'toggleMute', 0); command(engine, 'toggleMute', 0); assert.equal(engine.value(5, 0), 0);
  checks += 5;
}
console.log(`Pluggbox WASM: ${checks} contract groups passed, including all 8 native/WASM sound comparisons (maximum sample delta ${maxNativeDelta}).`);
