/* SPDX-License-Identifier: GPL-3.0-only */
/* Exercise the production C instrument, not a replacement oscillator. */
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define __attribute__(x)
#include "../firmware/host/plugg_preview.c"

static unsigned checks;
#define CHECK(condition) do { checks++; if (!(condition)) { fprintf(stderr, "Pluggbox check failed at %s:%d: %s\n", __FILE__, __LINE__, #condition); return 1; } } while (0)

static double audio(uint32_t frames)
{
    double sum = 0;
    for (uint32_t frame = 0; frame < frames; frame += CTL) {
        float *samples = preview_render();
        for (uint32_t i = 0; i < CTL * 2u; i++) {
            if (!isfinite(samples[i]) || fabsf(samples[i]) > 1.0f) {
                fprintf(stderr, "Non-finite or out-of-range production audio\n"); exit(1);
            }
            sum += fabsf(samples[i]);
        }
    }
    return sum;
}

int main(int argc, char **argv)
{
    jam_preview_init();
    preview_render(); /* Match JamEngine's initial output-buffer priming. */
    if (argc >= 2 && !strcmp(argv[1], "--audio")) {
        uint32_t track = argc >= 3 ? (uint32_t)atoi(argv[2]) : 1u;
        uint32_t sound = argc >= 4 ? (uint32_t)atoi(argv[3]) : 0u;
        if (track >= NTRK || sound >= jam_sound_count(track)) return 2;
        jam_preview_select(track);
        jam_preview_sound(track, sound);
        jam_preview_key(track == TRK_DRUM ? 0u : 7u, 1);
        for (uint32_t frame = 0; frame < 8192u; frame += CTL) {
            if (frame == 4096u) jam_preview_key(track == TRK_DRUM ? 0u : 7u, 0);
            if (fwrite(preview_render(), sizeof output, 1, stdout) != 1) return 1;
        }
        return 0;
    }

    CHECK(!song.playing && song.g[G_BPM] == 144 && song.sel == 1);
    CHECK(!plugg_preview_demo_active());
    static const char *names[4] = {"CLEAN SLIDE", "GLASS EP", "STAR PLUCK", "PLUGG KIT"};
    for (uint32_t track = 0; track < NTRK; track++) {
        CHECK(jam_sound_count(track) == 2);
        CHECK(!strcmp(jam_sound_name(track), names[track]));
        CHECK(trk[track].p[P_SLEN] == 32);
        if (track < NPART) {
            CHECK(trk[track].p[P_ROOT] == 6 && trk[track].p[P_SCALE] == 2);
            CHECK(jam_preview_value(21, track, 0) == 0);
        }
    }
    CHECK(trk[1].p[P_CHORD] == 2);
    CHECK(jam_role_track(0) == TRK_DRUM && jam_role_track(1) == 0);
    jam_preview_key(7, 1);
    CHECK(kb_kind[7] == KS_NOTE && kb_n[7] == 4);
    CHECK(kb_nt[7][0] < kb_nt[7][1] && kb_nt[7][1] < kb_nt[7][2] && kb_nt[7][2] < kb_nt[7][3]);
    CHECK(audio(8192) > 1);
    jam_preview_key(7, 0);
    CHECK(kb_kind[7] == KS_NONE && !fm1_in.notes && !kb_prev);

    /* An overlapping bass key must interpolate pitch rather than jump/retrigger. */
    jam_preview_select(0); jam_preview_key(7, 1); audio(1024);
    int32_t bass_before = (trk[0].v[0].pitch_cur << 8) + trk[0].v[0].pitch_frac;
    jam_preview_key(14, 1);
    int32_t bass_target = trk[0].v[0].pitch16 << 8;
    CHECK(trk[0].nmono == 2 && trk[0].v[0].gate);
    CHECK(bass_target > bass_before && trk[0].v[0].gstep > 0);
    audio(256);
    int32_t bass_during = (trk[0].v[0].pitch_cur << 8) + trk[0].v[0].pitch_frac;
    CHECK(bass_during > bass_before && bass_during < bass_target);
    jam_preview_key(14, 0); jam_preview_key(7, 0);
    CHECK(!trk[0].nmono && !fm1_in.notes);
    jam_preview_select(1);
    jam_preview_record(1);
    CHECK(rec_wait && !song.playing);
    jam_preview_key(7, 1);
    CHECK(song.playing && song.rec == 2 && !rec_wait);
    audio(FS / 3); jam_preview_key(7, 0); audio(FS / 3);
    jam_preview_key(9, 1); audio(FS / 3); jam_preview_key(9, 0);
    jam_preview_record(0);
    CHECK(song.playing && !song.rec && !rec_wait);
    CHECK(jam_preview_value(21, 1, 0) >= 8);
    step_t chord_copy[NSTEP]; memcpy(chord_copy, trk[1].step, sizeof chord_copy);
    uint8_t duration_copy[NSTEP][4]; memcpy(duration_copy, trk[1].note_len, sizeof duration_copy);
    jam_preview_select(0); jam_preview_record(1);
    jam_preview_key(7, 1); audio(FS / 3); jam_preview_key(7, 0); jam_preview_record(0);
    CHECK(jam_preview_value(21, 0, 0) > 0);
    CHECK(!memcmp(chord_copy, trk[1].step, sizeof chord_copy));
    jam_preview_sound(1, 1);
    CHECK(!memcmp(chord_copy, trk[1].step, sizeof chord_copy));
    CHECK(trk[1].p[P_ROOT] == 6 && trk[1].p[P_SCALE] == 2 && trk[1].p[P_CHORD] == 2);
    CHECK(!jam_sound_load(1, 999));
    CHECK(jam_sound_index(1) == 1);
    jam_preview_panic(); audio(FS * 6u);
    CHECK(!song.playing && !fm1_in.notes && !song.rec && !rec_wait);
    CHECK(audio(FS) < 0.1);
    plugg_preview_demo(1); plugg_preview_demo(1); audio(FS);
    CHECK(plugg_preview_demo_active() && song.playing);
    plugg_preview_demo(0); plugg_preview_demo(0); audio(CTL);
    CHECK(!plugg_preview_demo_active() && !song.playing);
    CHECK(!memcmp(chord_copy, trk[1].step, sizeof chord_copy));
    CHECK(!memcmp(duration_copy, trk[1].note_len, sizeof duration_copy));
    plugg_preview_demo(1); audio(CTL); jam_preview_record(1);
    CHECK(!plugg_preview_demo_active());
    CHECK(song.rec || rec_wait);
    CHECK(!memcmp(chord_copy, trk[1].step, sizeof chord_copy));
    jam_preview_panic(); audio(CTL);
    for (uint32_t track = 0; track < NTRK; track++) {
        for (uint32_t sound = 0; sound < jam_sound_count(track); sound++) {
            jam_preview_select(track); jam_preview_sound(track, sound);
            for (uint32_t macro = 0; macro < 4u; macro++) {
                jam_macro_set(track, macro, -100);
                CHECK(jam_macro_get(track, macro) == 0);
                jam_macro_set(track, macro, 999);
                CHECK(jam_macro_get(track, macro) == 100);
                jam_preview_key(track == TRK_DRUM ? 0u : 7u, 1); audio(2048);
                jam_preview_key(track == TRK_DRUM ? 0u : 7u, 0);
                jam_preview_sound(track, sound);
            }
        }
    }
    /* Physical encoder stepping and the deeper engine browser share these
     * palette APIs; absolute browser sliders alone cannot catch a stuck knob. */
    jam_preview_panic(); audio(CTL);
    jam_preview_sound(1,0);
    CHECK(jam_sound_is_curated(1));
    jam_macro_set(1,1,0);
    for (uint32_t expected=1; expected<=3u; expected++) {
        jam_macro_set(1,1,(int32_t)(jam_macro_get(1,1)+jam_macro_step(1,1)));
        CHECK(trk[1].p[P_LD_PIT]==(int32_t)expected);
    }
    jam_sound_invalidate(1);
    CHECK(!jam_sound_is_curated(1));
    CHECK(!strcmp(jam_sound_name(1),"DIGITAL"));
    jam_preview_sound(1,0);
    CHECK(jam_sound_is_curated(1));
    trk[1].eng_req=ENGI_NOISE;
    CHECK(!jam_macro_supported(1));
    CHECK(!jam_sound_is_curated(1));
    CHECK(!strcmp(jam_sound_name(1),"NOISE"));
    int16_t incompatible=trk[1].p[P_E4];
    jam_macro_set(1,0,100);
    CHECK(trk[1].p[P_E4]==incompatible);
    CHECK(jam_macro_step(1,0)==0);
    jam_preview_sound(1,0);
    CHECK(jam_macro_supported(1) && jam_sound_is_curated(1));
    plugg_preview_reset(); audio(CTL);
    CHECK(!song.playing && !plugg_preview_demo_active() && song.g[G_BPM] == 144);
    CHECK(!fm1_in.notes && !song.rec && !rec_wait);
    for (uint32_t track = 0; track < NPART; track++) CHECK(jam_preview_value(21, track, 0) == 0);
    jam_preview_record(1); CHECK(rec_wait);
    plugg_preview_demo(1); audio(FS);
    CHECK(plugg_preview_demo_active() && song.playing);
    CHECK(!rec_wait && !song.rec);
    uint32_t overlapping_bass = 0;
    for (uint32_t step = 0; step < 32u; step++) {
        if (trk[0].step[step].time != ST_NOTE || !trk[0].step[step].n) continue;
        for (uint32_t distance = 1; distance < 32u; distance++) {
            uint32_t next = (step + distance) % 32u;
            if (trk[0].step[next].time == ST_NOTE && trk[0].step[next].n) {
                if (trk[0].note_len[step][0] > distance) overlapping_bass = 1;
                break;
            }
        }
    }
    CHECK(overlapping_bass && trk[0].p[P_VOICE] == V_LEGATO);
    for (uint32_t track = 0; track < NPART; track++) CHECK(jam_preview_value(21, track, 0) > 0);
    CHECK(audio(FS) > 1);
    plugg_preview_demo(0); audio(CTL);
    CHECK(!plugg_preview_demo_active());
    for (uint32_t track = 0; track < NPART; track++) CHECK(jam_preview_value(21, track, 0) == 0);
    jam_preview_play(1); audio(CTL); jam_preview_record(1);
    CHECK(song.rec);
    plugg_preview_demo(1); audio(CTL);
    CHECK(!song.rec && !rec_wait);
    plugg_preview_demo(0);
    plugg_preview_reset(); audio(FS * 6u);
    CHECK(!song.playing && audio(FS) < 0.1);
    printf("Pluggbox native: %u contract checks passed; original-bank audio, macro bounds, record/replay, demo/reset and release exercised.\n", checks);
    return 0;
}
