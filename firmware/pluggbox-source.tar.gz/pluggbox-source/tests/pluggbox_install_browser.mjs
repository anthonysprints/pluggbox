// SPDX-License-Identifier: GPL-3.0-only
// Actual Chromium against the packaged guided site. The independently encoded
// MIDI fixture derives from Jambox's read-only checker test.
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { resolve, extname, sep } from 'node:path';
import { pathToFileURL } from 'node:url';

const playwright = process.env.PLAYWRIGHT_MODULE ? pathToFileURL(resolve(process.env.PLAYWRIGHT_MODULE)).href : 'playwright-core';
const { chromium } = await import(playwright);
const root = resolve(process.env.PLUGGBOX_SITE_ROOT || 'build/pluggbox-site');
const evidence = resolve('build/pluggbox-install-evidence');
const mime = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.wasm': 'application/wasm', '.wav': 'audio/wav', '.gz': 'application/gzip' };
const server = createServer(async (request, response) => {
  try {
    const pathname = new URL(request.url, 'http://localhost').pathname;
    const path = resolve(root, '.' + pathname + (pathname.endsWith('/') ? 'index.html' : ''));
    if (!path.startsWith(root + sep)) throw new Error('Outside site');
    const body = await readFile(path);
    response.writeHead(200, { 'Content-Type': mime[extname(path)] || 'application/octet-stream' }); response.end(body);
  } catch { response.writeHead(404); response.end('Not found'); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const address = `http://127.0.0.1:${server.address().port}`;
const allowed = [
  [0xf0, 0, 0x32, 0x45, 0, 0, 0, 0x40, 0x7f, 0xf7],
  [0xf0, 0, 0x32, 0x49, 0, 0, 0, 0x40, 0x7f, 0xf7],
  [0xf0, 0x7d, 0x46, 0x4c, 1, 0xf7],
];

function fakeWebMIDI(config) {
  const handshake = [0xf0, 0, 0x32, 0x45, 0, 0, 0, 0x40, 0x7f, 0xf7];
  const capability = [0xf0, 0, 0x32, 0x49, 0, 0, 0, 0x40, 0x7f, 0xf7];
  const info = [0xf0, 0x7d, 0x46, 0x4c, 1, 0xf7];
  const equal = (a, b) => a.length === b.length && a.every((value, index) => value === b[index]);
  const text = value => Array.from(value, char => char.charCodeAt(0));
  const padded = (value, size) => { const bytes = Array(size).fill(0); bytes.splice(0, value.length, ...text(value)); return bytes; };
  // Fixture encoder is independent of the production module under test.
  function message(command, body) {
    const raw = [0, 0x59, command, body.length, 0, 0, ...body, ~body.reduce((sum, byte) => sum + byte, 0) & 255];
    const packed = []; let bits = 0, count = 0;
    for (const byte of raw) {
      bits |= byte << count; count += 8;
      while (count >= 7) { packed.push(bits & 127); bits >>>= 7; count -= 7; }
    }
    if (count) packed.push(bits & 127);
    return [0xf0, ...packed, 0xf7];
  }
  const access = new EventTarget(); access.inputs = new Map(); access.outputs = new Map(); access.sysexEnabled = true;
  const state = globalThis.fakeMIDI = { requests: [], sent: [], opened: [], closed: [], devices: [], denied: !!config.denied };
  const change = port => { const event = new Event('statechange'); event.port = port; access.dispatchEvent(event); };
  function addDevice(options = {}) {
    const index = state.devices.length;
    const device = { kind: 'jam', mode: 'normal', name: 'JamBoxFM PRIVATE PORT', serial: 'PRIVATE-SERIAL-93810', ...options };
    const id = suffix => `${index}-PRIVATE-${suffix}-ID`;
    class Port extends EventTarget {
      constructor(type) {
        super(); this.type = type; this.name = device.name; this.id = id(type); this.state = 'connected'; this.connection = 'closed'; this.listeners = new Set();
      }
      addEventListener(type, fn, ...rest) { if (type === 'midimessage') this.listeners.add(fn); super.addEventListener(type, fn, ...rest); }
      removeEventListener(type, fn, ...rest) { if (type === 'midimessage') this.listeners.delete(fn); super.removeEventListener(type, fn, ...rest); }
      async open() { state.opened.push(this.id); this.connection = 'open'; change(this); return this; }
      async close() {
        if (device.closeDelay) await new Promise(resolve => setTimeout(resolve, device.closeDelay));
        state.closed.push(this.id); this.connection = 'closed'; change(this); return this;
      }
      send(bytes) {
        const data = Array.from(bytes); state.sent.push({ id: this.id, bytes: data });
        let response = null, delay = device.delay || 0;
        const identity = device.identity || (device.kind === 'sloop' ? 'FM-1_900' : device.mode === 'loader' ? 'ota-FM-1_700' : device.mode === 'rescue' ? 'FM-1_000' : 'FM-1_700');
        if (equal(data, handshake)) {
          response = message(0x11, padded(identity, 27));
          if (device.badIdentity) response[response.length - 2] ^= 1;
          delay = device.identityDelay ?? delay;
        } else if (equal(data, capability) && device.kind === 'jam' && !device.noCapability) {
          response = message(0x12, [...text('JAMBOXFM'), 1, ['normal', 'rescue', 'loader'].indexOf(device.mode),
            { normal: 0x17, rescue: 0x05, loader: 0x09 }[device.mode], 0,
            ...padded('0.1.0-dev', 20), ...padded(identity, 16)]);
          if (device.badCapability) response[response.length - 2] ^= 1;
          delay = device.capabilityDelay ?? delay;
        } else if (equal(data, info) && device.kind === 'sloop') {
          const engines = ['ANALOG', 'DIGITAL', 'PHASE', 'LOFI', 'SAMPLE', 'VOICE', 'TRIO', 'WHEEL', 'GRAIN', 'FM6', 'PHYS', 'NOISE'];
          response = [0xf0, 0x7d, 0x46, 0x4c, 1, ...text('FELUCCA SLOOP 2.6'), 0, 12, 71, 45, 64, 63,
            ...engines.flatMap(name => [...text(name), 0]), 4, 10, 0xf7];
        }
        if (response && !device.silent) setTimeout(() => {
          const event = new Event('midimessage'); event.data = Uint8Array.from(response); device.input.dispatchEvent(event); state.delivered++;
        }, delay);
      }
    }
    device.input = new Port('input'); device.output = new Port('output'); state.devices.push(device);
    access.inputs.set(device.input.id, device.input); access.outputs.set(device.output.id, device.output);
    change(device.input); change(device.output); return index;
  }
  state.delivered = 0;
  state.addDevice = addDevice;
  state.disconnect = index => { const device = state.devices[index]; for (const port of [device.input, device.output]) { port.state = 'disconnected'; change(port); } };
  state.snapshot = () => ({ requests: state.requests, sent: state.sent, opened: state.opened, closed: state.closed,
    listeners: state.devices.map(device => device.input.listeners.size), delivered: state.delivered });
  for (const device of config.devices ?? [{}]) addDevice(device);
  Object.defineProperty(navigator, 'requestMIDIAccess', { configurable: true, value: config.unsupported ? undefined : async options => {
    state.requests.push(options);
    if (state.denied) throw new DOMException('Test permission denial', 'NotAllowedError');
    return access;
  } });
}

let browser;
const passed = [], errors = [], requests = [];
const testedAt = new Date().toISOString();
await mkdir(evidence, { recursive: true });
await writeFile(resolve(evidence, 'results.json'), JSON.stringify({ testedAt, status: 'running' }) + '\n');
async function runCase(name, config, body, options = {}) {
  const page = await browser.newPage({ viewport: { width: 1280, height: 1060 }, ...options });
  page.on('pageerror', error => errors.push(`${name}: ${error.message}`));
  page.on('request', request => requests.push({ url: request.url(), method: request.method() }));
  try {
    await page.addInitScript(fakeWebMIDI, config);
    await page.goto(`${address}/install/`);
    await page.waitForFunction(() => document.getElementById('release-badge').textContent === 'IN PREPARATION' &&
      !document.getElementById('release-status').textContent.startsWith('Checking'));
    assert.deepEqual(await page.evaluate(() => fakeMIDI.snapshot().requests), [], 'MIDI requires an explicit action');
    assert(await page.locator('#install-device').isDisabled(), 'no install without an actual verified target');
    await body(page);
    const snapshot = await page.evaluate(() => fakeMIDI.snapshot());
    for (const packet of snapshot.sent) assert(allowed.some(bytes => JSON.stringify(bytes) === JSON.stringify(packet.bytes)), `${name}: disallowed MIDI packet ${packet.bytes}`);
    assert(await page.locator('#install-device').isDisabled(), 'identifying a device never enables installation');
    assert.equal(await page.locator('input[type=file]').count(), 0);
    passed.push(name); console.log(`PASS ${name}`);
  } finally { await page.close(); }
}
async function connect(page) {
  await page.locator('#connect-device').click();
  await page.waitForFunction(() => !document.getElementById('port-fields').disabled);
  assert.deepEqual(await page.evaluate(() => fakeMIDI.snapshot().requests), [{ sysex: true }]);
}
async function check(page) {
  await page.locator('#check-device').click();
  await page.locator('#device-result').waitFor({ state: 'visible' });
  await page.waitForFunction(() => document.getElementById('check-device').getAttribute('aria-busy') === 'false');
}
async function noOpenLinks(page) {
  const snapshot = await page.evaluate(() => fakeMIDI.snapshot());
  assert(snapshot.opened.every(id => snapshot.closed.includes(id)), 'all opened ports close');
  assert(snapshot.listeners.every(count => count === 0), 'all input listeners removed');
}

try {
  browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', headless: true,
    args: ['--no-sandbox', '--autoplay-policy=document-user-activation-required'] });
  await runCase('honest release gate and browser listening links', {}, async page => {
    assert.match(await page.locator('#release-status').textContent(), /installer is being prepared/);
    assert.equal(await page.locator('#play-browser').getAttribute('href'), '../play/');
    assert.equal(await page.locator('audio').count(), 2);
    for (const path of ['/audio/glass-starter-jam.wav', '/audio/glass-harder-take.wav']) {
      const response = await page.request.get(address + path); assert.equal(response.status(), 200);
      const bytes = await response.body(); assert.equal(bytes.subarray(0, 4).toString(), 'RIFF');
    }
    for (const path of ['/LICENSE.txt', '/pluggbox-source.tar.gz']) assert.equal((await page.request.get(address + path)).status(), 200);
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    await page.screenshot({ path: resolve(evidence, 'desktop.png'), fullPage: true });
  });
  await runCase('unsupported MIDI browser stays usable for listening', { unsupported: true }, async page => {
    assert(await page.locator('#connect-device').isDisabled());
    assert.match(await page.locator('#connection-status').textContent(), /Chrome or Edge/);
    assert(await page.locator('#play-browser').isVisible());
    assert(await page.locator('#check-device').isDisabled());
  });
  await runCase('denied permission and retry', { denied: true }, async page => {
    await page.locator('#connect-device').click();
    await page.waitForFunction(() => document.getElementById('connection-status').textContent.includes('wasn’t allowed'));
    assert.deepEqual(await page.evaluate(() => fakeMIDI.snapshot().sent), []);
    await page.evaluate(() => { fakeMIDI.denied = false; });
    await page.locator('#connect-device').click();
    await page.waitForFunction(() => !document.getElementById('port-fields').disabled);
    assert.equal((await page.evaluate(() => fakeMIDI.snapshot().requests)).length, 2);
    await check(page); assert.match(await page.locator('#result-title').textContent(), /Jambox identified/);
    await noOpenLinks(page);
  });
  await runCase('no ports and hotplug', { devices: [] }, async page => {
    await connect(page);
    assert.match(await page.locator('#port-hint').textContent(), /No MIDI input\/output pair/);
    assert(await page.locator('#check-device').isDisabled());
    await page.evaluate(() => fakeMIDI.addDevice());
    await page.waitForFunction(() => !document.getElementById('check-device').disabled);
    await check(page); await noOpenLinks(page);
  });
  await runCase('read-only Jambox identification', {}, async page => {
    await connect(page); await check(page);
    assert.equal(await page.locator('#result-title').textContent(), 'Jambox identified.');
    assert.match(await page.locator('#result-detail').textContent(), /FM-1_700.*0\.1\.0-dev/);
    assert.match(await page.locator('#result-detail').textContent(), /nothing was installed/);
    await noOpenLinks(page);
    await page.screenshot({ path: resolve(evidence, 'identified.png'), fullPage: true });
  });
  await runCase('mismatched port names cannot be checked', { devices: [{ name: 'JamBoxFM one' }, { name: 'JamBoxFM two' }] }, async page => {
    await connect(page);
    await page.locator('#midi-input').selectOption('0-PRIVATE-input-ID');
    await page.locator('#midi-output').selectOption('1-PRIVATE-output-ID');
    assert(await page.locator('#check-device').isDisabled());
    assert.deepEqual(await page.evaluate(() => fakeMIDI.snapshot().sent), []);
    await page.locator('#midi-output').selectOption('0-PRIVATE-output-ID'); await check(page); await noOpenLinks(page);
  });
  await runCase('disconnect cancels a pending read', { devices: [{ identityDelay: 500 }] }, async page => {
    await connect(page); await page.locator('#check-device').click();
    await page.waitForFunction(() => fakeMIDI.snapshot().sent.length > 0);
    await page.evaluate(() => fakeMIDI.disconnect(0));
    await page.waitForFunction(() => document.getElementById('check-device').getAttribute('aria-busy') === 'false');
    assert(await page.locator('#device-result').isHidden());
    assert(await page.locator('#check-device').isDisabled());
    await noOpenLinks(page);
  });
  await runCase('forged ready metadata cannot enable installation', {}, async page => {
    await page.route('**/firmware/pluggbox-release.json', route => route.fulfill({ contentType: 'application/json', body: JSON.stringify({ schema_version: 1, family: 'pluggbox', status: 'ready', install_available: true, firmware: 'jambox.fwsc' }) }));
    await page.reload();
    await page.waitForFunction(() => document.getElementById('release-badge').textContent === 'IN PREPARATION');
    await connect(page); await check(page);
    await page.evaluate(() => document.getElementById('install-device').dispatchEvent(new MouseEvent('click')));
    assert(await page.locator('#install-device').isDisabled());
    await noOpenLinks(page);
  });
  await runCase('missing release keeps the installer unavailable', {}, async page => {
    await page.route('**/firmware/pluggbox-release.json', route => route.fulfill({ status: 404, body: 'Not found' }));
    await page.reload();
    await page.waitForFunction(() => document.getElementById('release-status').textContent.includes('installer is being prepared'));
  });
  await runCase('mobile layout and listening controls', { unsupported: true }, async page => {
    assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    assert.equal(await page.locator('audio').count(), 2);
    await page.screenshot({ path: resolve(evidence, 'mobile.png'), fullPage: true });
  }, { viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });

  const page = await browser.newPage({ viewport: { width: 1280, height: 1080 } });
  page.on('pageerror', error => errors.push(`browser audition: ${error.message}`));
  await page.goto(address); await page.waitForURL('**/install/');
  await page.locator('#play-browser').click(); await page.waitForURL('**/play/');
  await page.evaluate(async () => { globalThis.testPlugg = (await import('./app.js')).session; });
  assert(await page.locator('#play').isDisabled());
  await page.locator('#audio-start').click();
  await page.waitForFunction(() => globalThis.testPlugg.state?.tempo === 144);
  await page.locator('#demo').click();
  await page.waitForFunction(() => globalThis.testPlugg.state?.demo && document.getElementById('meter').value > 0.01);
  await page.locator('#panic').click(); await page.waitForFunction(() => !globalThis.testPlugg.state.playing);
  assert.equal(await page.evaluate(() => globalThis.testPlugg.context.sampleRate), 44100);
  for (const link of ['../pluggbox-source.tar.gz', '../LICENSE.txt']) assert.equal((await page.request.get(new URL(link, page.url()).href)).status(), 200);
  await page.close();
  passed.push('guided root link reaches the actual audible browser instrument');
  console.log('PASS guided root link reaches the actual audible browser instrument');
  assert.deepEqual(errors, []);
  assert(!requests.some(request => request.url.endsWith('.fwsc')), 'page never requests firmware');
  assert(requests.every(request => request.method === 'GET'), 'page makes no state-changing network request');
  await writeFile(resolve(evidence, 'results.json'), JSON.stringify({ testedAt, status: 'passed', cases: passed.length, passed, errors }, null, 2) + '\n');
  console.log(`Pluggbox guided site: ${passed.length} real Chromium cases passed.`);
} catch (error) {
  await writeFile(resolve(evidence, 'results.json'), JSON.stringify({ testedAt, status: 'failed', passed, errors, failure: error.message }, null, 2) + '\n');
  throw error;
} finally {
  await browser?.close(); await new Promise(resolve => server.close(resolve));
}
