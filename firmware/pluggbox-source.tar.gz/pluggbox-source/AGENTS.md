# Pluggbox

Pluggbox is a separate pluggnb / rage / underground-rap instrument derived
from the Jambox source pinned in UPSTREAM.json. Use this existing checkout;
cloud tasks are already isolated. Do not create a worktree unless requested.

The first milestone is a browser audition of original sounds sharing the
FM-1 C audio engine. Pluggbox-specific source lives in firmware/src/plugg_palette.c,
firmware/host/plugg_preview.c, web/plugg, and tools/*pluggbox*.
Inherited jam_* files and docs describe Jambox and remain useful references.
Do not run inherited publication tools against Jambox or claim inherited
release evidence validates Pluggbox.

Run bash tools/cloud/setup_pluggbox.sh, source tools/cloud/activate_pluggbox.sh,
then sh tests/run_pluggbox_tests.sh. Package with python3 tools/package_pluggbox.py.
Keep generated files below ignored build/. Retain GPL and asset provenance.
Browser verification does not prove target memory fit or physical audio timing.
Device build/save identity work is a separate milestone; do not bypass the
inherited save-identity checks or distribute an unverified firmware installer.
